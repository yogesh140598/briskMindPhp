<?php
define('BASE_PATH', 'http://localhost/recyvolt/');
// define('BASE_PATH', 'http://localhost:81/recyvolt/');
// define('BASE_PATH', 'https://recyvolt.in/'); //live site
//  $url_path = "http://localhost:81/recyvolt/";
// define("BASE_PATH",$url_path);

?>