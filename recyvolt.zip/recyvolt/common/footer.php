<footer class="">
      <div class="container">
        <div class="row d-flex">
          <div class="col-md-2 mb-20">
            <h3 class="footer-heading">Company</h3>
              <p ><a class="para" href="#">About</a></p>
              <p ><a class="para" href="#">How it works</a></p>
              <p ><a class="para" href="#">Download MObile App</a></p>
              <p ><a class="para" href="#">Terms of USe</a></p>
              <p ><a class="para" href="#">SaaS Agreement</a></p>
              <p ><a class="para" href="#">Team</a></p>
          </div>
          <div class="col-md-2 mb-20">
            <h3 class="footer-heading">Services</h3>
            <p><a href="#" class="para">Battery Material</a></p>
            <p><a href="#" class="para">Refined Products</a></p>
            <p><a href="#" class="para">Solar Material</a></p>
            <p><a href="#" class="para">Optical Media</a></p>
            <p><a href="#" class="para">Trade Finance</a></p>
          </div>
          <div class="col-md-2 mb-20">
            <h3 class="footer-heading">Support</h3>
            <p ><a class="para" href="#">Privacy Policy</a></p>
              <p ><a class="para" href="#">Terms & Conditions</a></p>
              <p ><a class="para" href="#">Software License Agreement</a></p>
              <p ><a class="para" href="#">Shipping Policy</a></p>
              <p ><a class="para" href="#">Return / Refund Policy</a></p>
          </div>
          <div class="col-md-2 mb-20 green_line">

          </div>
          <div class="col-md-4">
            <ul class="footer_desc">
              <li class="footer_logo"><a href="#"><img src="<?php echo BASE_PATH; ?>assets/images/footer_logo.png" width="220" height="auto" alt="logo"></a></li>
              <li><span><img src="<?php echo BASE_PATH; ?>assets/images/phone.png" height="42" width="auto" alt="phone"></span>+91 9899991388</li>
              <li><span><img src="<?php echo BASE_PATH; ?>assets/images/mail.png" height="14" width="auto" alt="mail"></span><a href="mailto:info@recyvolt.com">info@recyvolt.com</a></li>
              <li><span><img src="<?php echo BASE_PATH; ?>assets/images/clock.png" height="14" width="auto" alt="clock"></span>Hours: Mon - Fri, 9 am to 7pm</li>
            </ul>
          </div>
        </div>
      </div>
    </footer>