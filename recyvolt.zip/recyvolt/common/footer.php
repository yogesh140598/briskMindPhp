<footer class="">
      <div class="container">
        <div class="row d-flex">
          <div class="col-12 col-md-2 mb-20">
            <h3 class="footer-heading">Company</h3>
              <p ><a class="para" href="#">About</a></p>
              <p ><a class="para" href="#">How it works</a></p>
              <p ><a class="para" href="#">Download MObile App</a></p>
              <p ><a class="para" href="#">Terms of USe</a></p>
              <p ><a class="para" href="#">SaaS Agreement</a></p>
              <p ><a class="para" href="#">Team</a></p>
          </div>
          <div class="col-12 col-md-2 mb-20">
            <h3 class="footer-heading">Services</h3>
            <p><a href="#" class="para">Battery Material</a></p>
            <p><a href="#" class="para">Refined Products</a></p>
            <p><a href="#" class="para">Solar Material</a></p>
            <p><a href="#" class="para">Optical Media</a></p>
            <p><a href="#" class="para">Trade Finance</a></p>
          </div>
          <div class="col-12 col-md-2 mb-20">
            <h3 class="footer-heading">Support</h3>
            <p ><a class="para" href="#">Privacy Policy</a></p>
              <p ><a class="para" href="#">Terms & Conditions</a></p>
              <p ><a class="para" href="#">Software License Agreement</a></p>
              <p ><a class="para" href="#">Shipping Policy</a></p>
              <p ><a class="para" href="#">Return / Refund Policy</a></p>
          </div>
          <div class="col-12 col-md-2 mb-20 green_line">
          </div>
          <div class="col-12 col-md-4">
            <ul class="footer_desc">
              <li class="footer_logo"><a href="#"><img src="<?php echo BASE_PATH; ?>assets/images/footer_logo.png" width="220" height="auto" alt="logo"></a></li>
              <li class="phone"><span class="me-3"><img src="<?php echo BASE_PATH; ?>assets/images/phone.svg" height="42" width="auto" alt="phone"></span>011- 2344 XXX</li>
              <li class="mail"><span class="me-3"><img src="<?php echo BASE_PATH; ?>assets/images/mail.svg" height="14" width="auto" alt="mail"></span><a href="mailto:info@recyvolt.com">info@recyvolt.com</a></li>
              <li class="clock"><span class="me-3"><img src="<?php echo BASE_PATH; ?>assets/images/clock.svg" height="14" width="auto" alt="clock"></span>Hours: Mon - Fri, 9 am to 7pm</li>
            </ul>
          </div>
        </div>
        <div class="row d-flex">
            <div class="col-12 col-md-6 copyright">
              <p>© 2022 recyvolt.com, All Rights Reserved</p>
            </div>
            <div class="col-12 col-md-6 d-flex justify-content-start justify-content-md-end">
              <div>
                <img src="<?php echo BASE_PATH; ?>assets/images/fb.svg" alt="fb" width="24" height="auto">
              </div>
              <div class="mx-4">
                <img src="<?php echo BASE_PATH; ?>assets/images/twi.svg" alt="twi" width="24" height="auto">
              </div>
              <div>
                <img src="<?php echo BASE_PATH; ?>assets/images/inst.svg" alt="inst" width="24" height="auto">
              </div>
            </div>
        </div>
      </div>
    </footer>