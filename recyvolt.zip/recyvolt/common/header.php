
<header class="header">
      <div class="top_nav w-100">
        <div class="container">
          <div class="row d-flex align-items-center">
            <div class="col-md-12 d-flex align-items-center justify-content-between">
              <ul class="left_menu">
                <li><span><img src="<?php echo BASE_PATH; ?>assets/images/phone.png" height="14" width="auto" alt="phone"></span>+91 9899991388</li>
                <li><span><img src="<?php echo BASE_PATH; ?>assets/images/mail.png" height="14" width="auto" alt="mail"></span><a href="mailto:info@recyvolt.com">info@recyvolt.com</a></li>
                <li><span><img src="<?php echo BASE_PATH; ?>assets/images/clock.png" height="14" width="auto" alt="clock"></span>Hours: Mon - Fri, 9 am to 7pm</li>
              </ul>
              <ul class="right_menu">
                <li class="icons"><a href="#"><img src="<?php echo BASE_PATH; ?>assets/images/Instagram.png" width="20" height="auto" alt="Instagram"></a></li>
                <li class="icons"><a href="#"><img src="<?php echo BASE_PATH; ?>assets/images/Twitter.png" width="20" height="auto" alt="Twitter"></a></li>
                <li class="icons"><a href="#"><img src="<?php echo BASE_PATH; ?>assets/images/Facebook.png" width="20" height="auto" alt="Facebook"></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div class="header_bottom">
        <div class="container w-100">
          <div class="row d-flex align-items-center">
            <nav class="navbar navbar-expand-lg ">
                <div class="col-md-3">
                  <div class="header_logo">
                    <a class="navbar-brand" href="<?php echo BASE_PATH; ?>"><img src="<?php echo BASE_PATH; ?>assets/images/header_logo.png" height="auto" width="130" alt=""></a>
                  </div>
                </div>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon">
                    <img class="img-fluid" src="<?php echo BASE_PATH; ?>assets/images/menu-icon.svg" alt="">
                  </span>
                </button>
                <div class="collapse navbar-collapse col-md-9 justify-content-end" id="navbarSupportedContent">
                  <ul class="navbar-nav header_menu d-flex align-items-center justify-content-between">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo BASE_PATH; ?>">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo BASE_PATH; ?>recycling-services">Recycling Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo BASE_PATH; ?>about">About us</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo BASE_PATH; ?>media">Media</a>
                    </li>
                    <li class="">
                        <a class="nav-link btn-custom text-light" href="<?php echo BASE_PATH; ?>contact">Contact us</a>
                    </li>
                  </ul>
                </div>
            </nav>
          </div>
        </div>
      </div>
    </header>
    <div class="header_gap"></div>