
<header class="header">
      <div class="top_nav w-100">
        <div class="container">
          <div class="row d-flex align-items-center">
            <div class="col-md-12 d-flex align-items-center justify-content-between">
              <ul class="left_menu">
                <li><span><img src="<?php echo BASE_PATH; ?>assets/images/phone.svg" height="14" width="auto" alt="phone"></span>+91 9899991388</li>
                <li><span><img src="<?php echo BASE_PATH; ?>assets/images/mail.svg" height="14" width="auto" alt="mail"></span><a href="mailto:info@recyvolt.com">info@recyvolt.com</a></li>
                <li><span><img src="<?php echo BASE_PATH; ?>assets/images/clock.svg" height="14" width="auto" alt="clock"></span>Hours: Mon - Fri, 9 am to 7pm</li>
              </ul>
              <ul class="right_menu">
                <li class="icons"><a href="#"><img src="<?php echo BASE_PATH; ?>assets/images/Instagram.png" width="12" height="auto" alt="Instagram"></a></li>
                <li class="icons"><a href="#"><img src="<?php echo BASE_PATH; ?>assets/images/Twitter.png" width="12.6" height="auto" alt="Twitter"></a></li>
                <li class="icons"><a href="#"><img src="<?php echo BASE_PATH; ?>assets/images/Facebook.png" width="7" height="auto" alt="Facebook"></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div class="header_bottom">
        <div class="container w-100">
          <div class="row d-flex align-items-center">
            <nav class="navbar navbar-expand-lg ">
                <div class="col-md-3">
                  <div class="header_logo">
                    <a class="navbar-brand" href="<?php echo BASE_PATH; ?>"><img src="<?php echo BASE_PATH; ?>assets/images/header_logo.png" height="auto" width="130" alt=""></a>
                  </div>
                </div>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon">
                    <img class="img-fluid" src="<?php echo BASE_PATH; ?>assets/images/menu-icon.svg" alt="">
                  </span>
                </button>
                <div class="collapse navbar-collapse col-md-9 justify-content-end" id="navbarSupportedContent">
                  <ul class="navbar-nav header_menu d-flex align-items-center justify-content-between">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo BASE_PATH; ?>">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo BASE_PATH; ?>recycling-services">Recycling Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo BASE_PATH; ?>about">About us</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo BASE_PATH; ?>media">Media</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo BASE_PATH; ?>contact">Contact us</a>
                    </li>
                    <li class="">
                        <button class="btn-custom" data-bs-toggle="modal" data-bs-target="#joinPopup">Join us</button>
                    </li>
                  </ul>
                </div>
            </nav>
          </div>
        </div>
      </div>
    </header>
    <div class="header_gap"></div>

    <div class="modal fade" id="joinPopup" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered ">
        <div class="modal-content">
          <div class="row">
            <div class="col-md-4 bg-green p-5 m-hide show">
              <h2 class="heading">Contact Info</h2>
              <div class="content">
                <div class="form-content">
                  <div>
                    <p class="form-label"><span class="form-icon"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person" viewBox="0 0 16 16"> <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z"/> </svg></span>
                    Name</p>
                    <p class="label-con">Yogesh Kandari</p>
                  </div>
                  <div>
                    <p class="form-label"><span class="form-icon"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-envelope-fill" viewBox="0 0 16 16"> <path d="M.05 3.555A2 2 0 0 1 2 2h12a2 2 0 0 1 1.95 1.555L8 8.414.05 3.555ZM0 4.697v7.104l5.803-3.558L0 4.697ZM6.761 8.83l-6.57 4.027A2 2 0 0 0 2 14h12a2 2 0 0 0 1.808-1.144l-6.57-4.027L8 9.586l-1.239-.757Zm3.436-.586L16 11.801V4.697l-5.803 3.546Z"/> </svg></span> Email</p>
                    <p class="label-con">contactname@recyvolt.com</p>
                  </div>
                  <div>
                    <p class="form-label"><span class="form-icon"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-telephone-fill" viewBox="0 0 16 16"> <path fill-rule="evenodd" d="M1.885.511a1.745 1.745 0 0 1 2.61.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.678.678 0 0 0 .178.643l2.457 2.457a.678.678 0 0 0 .644.178l2.189-.547a1.745 1.745 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.634 18.634 0 0 1-7.01-4.42 18.634 18.634 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877L1.885.511z"/> </svg></span> phone</p>
                    <p class="label-con">+91 98711 XXX11</p>
                  </div>
                  <div>
                    <p class="form-label"><span class="form-icon"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-geo-alt-fill" viewBox="0 0 16 16"> <path d="M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10zm0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6z"/> </svg></span> Address</p>
                    <p class="label-con">4286 B Street, Saint Paul, Minnesota MN</p>
                  </div>
                </div>
                <div class="social-icon">
                  <ul class="d-flex ps-0">
                    <li class="px-2"><a href="#"><img src="<?php echo BASE_PATH; ?>assets/images/facebook-p.svg" alt="facebook"></a></li>
                    <li class="px-2"><a href="#"><img src="<?php echo BASE_PATH; ?>assets/images/instagram-p.svg" alt="instagram"></a></li>
                    <li class="px-2"><a href="#"><img src="<?php echo BASE_PATH; ?>assets/images/twitter-p.svg" alt="twitter"></a></li>
                    <li class="px-2"><a href="#"><img src="<?php echo BASE_PATH; ?>assets/images/youtube-p.svg" alt="youtube"></a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-md-8 p-5">
              <form action="<?php echo BASE_PATH; ?>join-mail.php" method="post" class="row">
                <h3 class="sub-heading mb-5">Contact Us</h3>
                <div class="col-12 col-md-12 px-3">
                  <input required name="name" type="text" class="form-control" placeholder="Name" aria-label="Name">
                </div>
                <div class="col-12 col-md-12 px-3">
                    <input required name="email" type="text" class="form-control" placeholder="Official Email" aria-label="Official Email">
                </div>
                <div class="col-12 col-md-12  px-3">
                    <input required name="mobile" type="text" class="form-control" placeholder="Phone" aria-label="Phone" min="10" max="10">
                </div>
                <div class="col-md-12">
                  <textarea required name="message" class="form-control" id="comments" placeholder="Comments" rows="3"></textarea>
                </div>
                <div class="d-flex justify-content-center">
                  <button type="submit" name="submit" class="btn-custom w-100">Submit</button>
                </div>
              </form>
              <button type="button" class="close" data-bs-dismiss="modal">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
                  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
                </svg>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>