<?php include 'common/config.php';?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <link rel="stylesheet" type="text/css" href="<?php echo BASE_PATH; ?>assets/css/owl.carousel.min.css" />
    <?php include 'common/library.php';?>
    <title>About us</title>
  </head>
  <body class="about-page">
    <?php include 'common/header.php';?>
    <section class="about_banner banner_height">
        <div class="container h-100 d-flex align-items-center">
            <div>
                <h2 class="heading">About Us</h2>
            </div>
        </div>
    </section>
    <section class="section bg-blue">
          <div class="container">
            <div class="row d-flex align-items-center">
              <div class="col-12 col-sm-12 col-md-8">
                <h2 class="heading">Company Overview</h2>
                <p>RECYVOLT Battery Recycle India is a leader in providing E2E consulting for the critical material and lithium-ion battery  recycling. The Company is focused on developing collaborations for the circular economy required for the  energy transition by treating spent batteries as a valuable resource, instead of hazardous waste – providing  India with its first premier domestic source of Lithium, Nickel, Cobalt and Manganese.</p>
              </div>
              <div class="col-12 col-sm-12 col-md-4">
                <figure>
                  <img src="<?php echo BASE_PATH; ?>assets/images/overview_image.webp" alt="overview_image" width="400" height="auto">
                </figure>
              </div>
            </div>
          </div>
      </section>
    <section class="section bg-blue">
      <div class="container">
        <div class="row d-flex justify-content-around">
          <div class="col-12 col-sm-12 col-md-4 card_overview">
            <div>
              <figure>
                <img class="mw-100" src="<?php echo BASE_PATH; ?>assets/images/recycling.webp" width="50" height="auto" alt="recycling">
              </figure>
              <h3>Lithium-Ion Battery Recycling</h3>
              <p>Processing spent lithium-ion batteries to recover  and reuse battery metals</p>
            </div>
          </div>
          <div class="col-12 col-sm-12 col-md-4 card_overview">
            <div>
              <figure>
                <img class="mw-100" src="<?php echo BASE_PATH; ?>assets/images/metal-extraction.webp" width="50" height="auto" alt="metal-extraction">
              </figure>
              <h3>Primary Metals Extraction</h3>
              <p>Removing battery metals from primary  resources with new scalable technologies</p>
            </div>
          </div>
          <div class="col-12 col-sm-12 col-md-4 card_overview">
            <div>
              <figure>
                <img class="mw-100" src="<?php echo BASE_PATH; ?>assets/images/resources.webp" width="50" height="auto" alt="resources">
              </figure>
              <h3>Resource Stewardship</h3>
              <p>Gathering mineral resources directly from  miners around the world</p>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="section">
        <div class="container">
            <h2 class="heading text-center">Management Teams</h2>
            <p class="para text-center mb-5">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam gravida eget justo et rutrum. Praesent augue leo, </p>
            <div class="row d-flex justify-content-center text-center">
                <div class="col col-sm-6 col-md-4 mb-5">
                    <img class="mb-4" src="<?php echo BASE_PATH; ?>assets/images/media.webp" alt="" width="205" height="auto">
                    <h2 class="team-title">Yogesh Kandari</h2>
                    <h3 class="team-desc">Managing Director, Recyvolt</h3>
                </div>
                <div class="col col-sm-6 col-md-4 mb-5">
                    <img class="mb-4" src="<?php echo BASE_PATH; ?>assets/images/media.webp" alt="" width="205" height="auto">
                    <h2 class="team-title">Yogesh Kandari</h2>
                    <h3 class="team-desc">Managing Director, Recyvolt</h3>
                </div>
                <div class="col col-sm-6 col-md-4 mb-5">
                    <img class="mb-4" src="<?php echo BASE_PATH; ?>assets/images/media.webp" alt="" width="205" height="auto">
                    <h2 class="team-title">Yogesh Kandari</h2>
                    <h3 class="team-desc">Managing Director, Recyvolt</h3>
                </div>
                <div class="col col-sm-6 col-md-4 mb-5">
                    <img class="mb-4" src="<?php echo BASE_PATH; ?>assets/images/media.webp" alt="" width="205" height="auto">
                    <h2 class="team-title">Yogesh Kandari</h2>
                    <h3 class="team-desc">Managing Director, Recyvolt</h3>
                </div><div class="col col-sm-6 col-md-4 mb-5">
                    <img class="mb-4" src="<?php echo BASE_PATH; ?>assets/images/media.webp" alt="" width="205" height="auto">
                    <h2 class="team-title">Yogesh Kandari</h2>
                    <h3 class="team-desc">Managing Director, Recyvolt</h3>
                </div>
            </div>
        </div>
    </section>
    <section class="section bg-blue">
        <div class="container">
            <h2 class="heading text-center">Our Partners</h2>
            <p class="para text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam gravida eget justo et rutrum. Praesent augue leo, </p>
            <div id="client_slider" class="row d-flex justify-content-center align-item-center owl-carousel">
                <div class="item">
                  <figure>
                    <img src="<?php echo BASE_PATH; ?>assets/images/mint.webp" width="140" height="auto" alt="">
                  </figure>
                </div>
                <div class="item">
                  <figure>
                    <img src="<?php echo BASE_PATH; ?>assets/images/india-today.webp" width="140" height="auto" alt="">
                  </figure>
                </div>
                <div class="item">
                  <figure>
                    <img src="<?php echo BASE_PATH; ?>assets/images/news-18.webp" width="140" height="auto" alt="">
                  </figure>
                </div>
                <div class="item">
                  <figure>
                    <img src="<?php echo BASE_PATH; ?>assets/images/msn.webp" width="140" height="auto" alt="">
                  </figure>
                </div>
                <div class="item">
                  <figure>
                    <img src="<?php echo BASE_PATH; ?>assets/images/dailyhunt.webp" width="140" height="auto" alt="">
                  </figure>
                </div>
                <div class="item">
                  <figure>
                    <img src="<?php echo BASE_PATH; ?>assets/images/google.webp" width="140" height="auto" alt="">
                  </figure>
                </div>
            </div>
        </div>
    </section>
    <section class="section">
    <div class="container ">
      <h2 class="heading text-center">Career</h2>
        <div class="row d-flex justify-content-center">
          <div class="form_box col-md-12">
            <form action="<?php echo BASE_PATH; ?>mail.php" method="post">
              <div class="row d-flex justify-content-around align-items-center">
                <div class="col-md-4">
                  <div class="row d-flex flex-column px-4">
                    <h3 class="text-center mb-70">Being a part of our Organization</h3>
                    <div class="form_card mx-auto">
                      <div class="form_logo">
                        <img src="<?php echo BASE_PATH; ?>assets/images/john-doe.png" width="87" height="auto" alt="">
                      </div>
                      <p class="para"><a href="mailto:info@recyvolt.com">info@recyvolt.com</a></p>
                      <p class="para">+91 9899991388</p>
                    </div>
                  </div>
                </div>
                <div class="col-md-7">
                  <div class="row">
                      <div class="col-md-6 px-3">
                        <label for="name" class="form-label">Name</label>
                        <input required type="text" name="name" class="form-control" placeholder="Name" aria-label="Name">
                      </div>
                      <div class="col-md-6 px-3">
                        <label for="mobile" class="form-label">Mobile</label>
                        <input required type="text" name="mobile" class="form-control" placeholder="Mobile" aria-label="Mobile" min="10" max="10">
                      </div>
                      <div class="col-md-6 px-3">
                        <label for="email" class="form-label">Official Email</label>
                        <input required type="email" name="email" class="form-control" placeholder="Official Email" aria-label="Official Email">
                      </div>
                      <div class="col-md-6 px-3">
                        <label for="position" class="form-label">Apply for Position</label>
                        <input required type="text" name="position" class="form-control" placeholder="Apply for Position" aria-label="position">
                      </div>
                      <div class="col-md-12">
                        <label for="comments" class="form-label">Comments</label>
                        <textarea class="form-control" name="message" id="comments" min="10" max="1500" placeholder="Comments" rows="3"></textarea>
                      </div>
                      <div>
                        <button type="submit" name="submit" class="btn-custom btn-custom-2">Submit</button>
                      </div>
                    </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
    <?php include 'common/footer.php';?>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
      crossorigin="anonymous"
    ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="<?php echo BASE_PATH; ?>assets/js/owl.carousel.min.js" type="text/javascript"></script>
    <script>
        $('#client_slider').owlCarousel({
          margin: 20,
          autoHeight: true,
          nav: false,
          navigation: false,
          loop: true,
          autoplay: true,
          slideBy: 1,
          dotsEach: true,
          dots: true,
          //   autoWidth:true,
          responsive: {
            360: {
              items: 2,
            },
            600: {
              items: 4,
            },
            1120: {
              items: 6,
            },
            1480: {
              items: 8,
            },
            1850: {
              items: 10,
            }
          }
        });
    </script>
    <script src="<?php echo BASE_PATH; ?>assets/js/main.js"></script>
  </body>
</html>
