<?php include 'common/config.php';?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <?php include 'common/library.php';?>
    <title>Recycling Services</title>
  </head>
  <body class="about-page">
    <?php include 'common/header.php';?>
    <section class="service_banner banner_height">
        <div class="container h-100 d-flex align-items-center">
            <div>
                <h2>Consulting & Training for</h2>
                <h2>Recycling Services</h2>
            </div>
        </div>
    </section>
    <section class="section">
        <div class="container">
            <div class="row d-flex align-items-center">
                <div class="col col-md-6">
                    <h2 class="heading">Consulting for Recycling Services</h2>
                    <h3 class="sub-heading">Electric Vehicle Startups making India </h3>
                    <p class="para">The electronic automobile market is increasing at a rapid pace in the whole world and especially in India. The government is encouraging various companies to start producing Lithium-ion batteries, the heart of Electric Cars and Vehicles, in India.</p>
                    <p class="para">At Recyvolt, we look forward to guide the companies that have plans to enter into the manufacturing and recycling of Lithium-ion batteries. We look forward to support the company to set up a lithium-ion plant and train its employees as well.</p>
                    <p class="para">The success of EVs hinges on three main factors: the carbon intensity of the manufacturing process, the carbon intensity of the electricity used to charge the battery as the vehicle is used, and what happens to the battery at the end of its useful “first” life. So recycling has a major purpose. Just don’t let this opportunity slip away and seek guidance to invest in green technology like lithium-ion, which will be in great demand in the near future.</p>
                </div>
                <div class="col col-md-6">
                    <figure>
                        <img src="<?php echo BASE_PATH; ?>assets/images/recycling-services.webp" alt="" width="570" height="auto">
                    </figure>
                </div>
            </div>
        </div>
    </section>
    <section class="section">
        <div class="container">
            <div class="row d-flex align-items-center">
                <div class="col col-md-6">
                    <figure>
                        <img src="<?php echo BASE_PATH; ?>assets/images/recycling-training.webp" alt="" width="570" height="auto">
                    </figure>
                </div>
                <div class="col col-md-6">
                    <h2 class="heading">Training for Battery Recycling</h2>
                    <h3 class="sub-heading">A strategy that will help scale up the sector significantly  </h3>
                    <p class="para">This introduces you to the most effective ways and highly useful tools of designing, simulations, and testing of designs of EV products and components. Simulation engineering plays a key role in ensuring the success of EV products. This covers core specializations in EV technology: Battery Design, EV System Design, Simulation, and is ideal for both engineers and non-engineers who want to enter the EV industry.</p> 
                    <p class="para">It aims to impart evolving concepts in EV technology and equips attendees with skills to design, model, analyze, and test the functionality of components and entire systems. The modules include Electric Vehicle Technology and Operation, Electric Vehicle Battery Design, Electric Vehicle PowerTrain Design.</p>
                    <p class="para">The Electric Vehicle (EV) Industry Is Paving The Way For The Future Of Mobility. The Industry Is Emerging From A Nascent Stage And Is Set To Become A Mainstream Sector. Business and Job Opportunities Are There In All Functions: R&D, Design, Simulation And Analysis, CAM, Maintenance, And So On.</p>
                </div>
            </div>
        </div>
    </section>
    <section class="section">
        <div class="container">
            <h2 class="heading text-center">RECYCLING OF LITHIUM-ION BATTERIES</h2>
            <div class="row">
                <div class="col-sm-12">
                    <figure>
                        <img src="<?php echo BASE_PATH; ?>assets/images/services_roadmap.webp" alt="" width="1160">
                    </figure>
                    <p class="para text-center">More batteries means more waste and EV batteries are notoriously hard to recycle, posing an issue once these vehicles have reached the end of their lifecycle. Currently, once a battery reaches the end of its service life, it is collected, dismantled, and shredded. The material left behind from this process is called black mass. The composition of Black Mass can vary, but it always contains elements which can be repurposed in the production of new batteries in support of a circular economy. India is at the forefront of lithium-ion battery recycling and their government is keen to build on this. </p>
                </div>
            </div>
        </div>
    </section>
    <section class="section">
        <div class="container">
            <div class="row d-flex align-items-center">
                <div class="col col-md-6">
                    <h2 class="heading">EV Sales Growth</h2>
                    <h3 class="sub-heading">Lack of Primary Supply</h3>
                    <p class="para">Growing EV adoption and  infrastructure growth is leading to a  large push towards electrification There is not enough primary supply to  meet the demand for battery materials. Battery recycling is the green, sustainable solution for the battery  materials supply shortage</p>
                </div>
                <div class="col col-md-6">
                   <figure>
                    <img src="<?php echo BASE_PATH; ?>assets/images/ev-growth.webp" alt="" width="570" height="auto">
                   </figure> 
                </div>
            </div>
        </div>
    </section>
    <section class="section">
        <div class="container">
            <div class="row d-flex align-items-center">
                <div class="col col-md-6">
                   <figure>
                    <img src="<?php echo BASE_PATH; ?>assets/images/demand-growth.webp" alt="" width="570" height="auto">
                   </figure> 
                </div>
                <div class="col col-md-6">
                    <h2 class="heading">Demand for Battery Materials</h2>
                    <h3 class="sub-heading">Growing Total Addressable Market</h3>
                    <p class="para">Demand for Battery Metals, especially  copper and aluminum is set to grow almost  600% through 2030, Thermal refiners and traditional  hydrometallurgical processes are primarily  focused on Nickel and Cobalt, missing large  value from other metals The battery recycling process of tomorrow  must be able to recover a wide range of  metals in order to meet global demand</p>
                </div>
            </div>
        </div>
    </section>
    <section class="section">
        <div class="container">
            <div class="heading">Opportunity: Regulatory Incentives</div>
            <p class="para">EV Recycling company to save environment</p>
            <div class="row table">
                <div class="col col-md-6 p-0 dashed-right-line">
                    <div class="table-data">
                        <h3 class="sub-heading mb-0">Regulatory Drivers</h3>
                    </div>
                    <div class="table-data">
                        <span><img src="<?php echo BASE_PATH; ?>assets/images/india.webp" alt="" width="97" height="auto"></span>
                        <p class="para">India does not have adequate legislations; we are providing consulting to shape up the requirements</p>
                    </div>
                    <div class="table-data">
                        <span><img src="<?php echo BASE_PATH; ?>assets/images/america.webp" alt="" width="97" height="auto"></span>
                        <p class="para">90% recycling of consumer electronics, EVs  and grid storage batteries by 2030 Federal policies requires recycled materials in  cell manufacturing by 2030</p>
                    </div>
                    <div class="table-data">
                        <span><img src="<?php echo BASE_PATH; ?>assets/images/china.webp" alt="" width="97" height="auto"></span>
                        <p class="para">Required recovery rates of +80% on battery  metals in effect since 2018 Set to increase required rates to +90% on  Nickel, Cobalt, and Manganese</p>
                    </div>
                    <div class="table-data">
                        <span><img src="<?php echo BASE_PATH; ?>assets/images/eu.webp" alt="" width="97" height="auto"></span>
                        <p class="para">Batteries Directive mandates that all collected  batteries must be recycled, Set to increase minimum recycling efficiency  rate to +75% in 2022</p>
                    </div>
                </div>
                <div class="col col-md-6 p-0">
                    <div class="table-data">
                        <h3 class="sub-heading mb-0">Government Spending</h3>
                    </div>
                    <div class="table-data">
                        <span><img src="<?php echo BASE_PATH; ?>assets/images/recyvolt.webp" alt="" width="130" height="auto"></span>
                        <p class="para">RECYVOLT is securing Funding from  India Govt.</p>
                    </div>
                    <div class="table-data">
                        <span><img src="<?php echo BASE_PATH; ?>assets/images/us-congress.webp" alt="" width="57" height="auto"></span>
                        <span><img src="<?php echo BASE_PATH; ?>assets/images/american-made.webp" alt="" width="57" height="auto"></span>
                        <p class="para">RECYVOLT is securing Funding from  India Govt.</p>
                    </div>
                    <div class="table-data">
                        <span><img src="<?php echo BASE_PATH; ?>assets/images/new-dev-bank.webp" alt="" width="130" height="auto"></span>
                        <p class="para">$+60B spent to support EV  industry, including R&D for  battery recycling</p>
                    </div>
                    <div class="table-data">
                        <span><img src="<?php echo BASE_PATH; ?>assets/images/eu-commision.webp" alt="" width="130" height="auto"></span>
                        <p class="para">$1.1B Battery Alliance project  to boost battery R&D</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="section">
        <div class="container">
            <div class="row d-flex align-items-center">
                <div class="col col-md-6">
                    <h2 class="heading">Total Addressable Market</h2>
                    <h3 class="sub-heading">Spent Lithium-Ion Battery Supply</h3>
                    <p class="para">Total tonnage of lithium-ion batteries available for  recycling worldwide is set to increase 500% to over, 1.2 million tonnes from 2020 to 2030</p>
                    <p class="para">The largest segment of lithium-ion batteries that will  be available in the next decade are within the EV  and transportation verticals</p>
                    <p class="para">RECYVOLT’s goal is to capture feedstock with exclusive  offtake agreements and partnerships with battery  aggregators in order to fill our feedstock capacity</p>
                </div>
                <div class="col col-md-6">
                   <figure>
                    <img src="<?php echo BASE_PATH; ?>assets/images/total-market.webp" alt="" width="570" height="auto">
                   </figure> 
                </div>
            </div>
        </div>
    </section>
    <section class="section">
        <div class="container">
            <div class="row">
                <ul class="problem_card">
                    <li>
                        <img src="<?php echo BASE_PATH; ?>assets/images/exported.svg" alt="" width="116" height="auto">
                        <p class="para">The majority of batteries  currently “recycled” in the  United States are</p>
                        <h3 class="sub-heading">exported</h3>
                        <p class="para">to China, Korea & Japan</p>
                    </li>
                    <li>
                        <img src="<?php echo BASE_PATH; ?>assets/images/melted.svg" alt="" width="116" height="auto"></p>
                        <p class="para">The majority of batteries  currently “recycled” globally are</p>
                        <h3 class="sub-heading">Melted</h3>
                        <p class="para">in blast furnaces</p>
                    </li>
                    <li>
                        <img src="<?php echo BASE_PATH; ?>assets/images/critical-mineral.svg" alt="" width="116" height="auto">
                        <p class="para">Every battery exported to  China exacerbates the Domestic India</p>
                        <h3 class="sub-heading">critical mineral</h3>
                        <p class="para">supply problem</p>
                    </li>
                </ul>
            </div>
        </div>
    </section>
    <section class="section">
        <div class="container">
            <h2 class="heading">Recycling Process</h2>
            <p class="para">EV Recycling company to save environment</p>

            <div class="row">
                <table class="recycling_table">
                    <tbody>
                        <tr>
                            <td class="sub-heading">Process</td>
                            <td>
                                <img src="<?php echo BASE_PATH; ?>assets/images/step-1.webp" alt="" width="240" height="auto">
                            </td>
                            <td>
                                <img src="<?php echo BASE_PATH; ?>assets/images/step-2.webp" alt="" width="240" height="auto">
                            </td>
                            <td>
                                <img src="<?php echo BASE_PATH; ?>assets/images/step-3.webp" alt="" width="240" height="auto">
                            </td>
                            <td>
                                <img src="<?php echo BASE_PATH; ?>assets/images/step-4.webp" alt="" width="240" height="auto">
                            </td>
                        </tr>
                        <tr>
                            <td class="sub-heading">Description</td>
                            <td>
                                <p class="para">Breakdown of integrated  modules into cells by  targeting weak points</p>
                            </td>
                            <td>
                                <p class="para">Automated separation of  individual cells, agnostic  to form factor</p>
                            </td>
                            <td>
                                <p class="para">Material separation of  battery-grade feedstock  from slurry</p>
                            </td>
                            <td>
                                <p class="para">Synthesis of battery-  grade materials to be  sent out to customers</p>
                            </td>
                        </tr>
                        <tr>
                            <td class="sub-heading">Output</td>
                            <td>
                                <p class="para">Al / Plastic</p>
                            </td>
                            <td>
                                <p class="para">Al / Fe / Steel  Scrap Al & Cu Foil</p>
                            </td>
                            <td>
                                <p class="para">Intermediate Product  Li / Ni / Co / Mn</p>
                            </td>
                            <td>
                                <p class="para">Battery-Grade  LiOH / Ni/Co/Mn-SO4</p>
                            </td>
                        </tr>
                        <tr>
                            <td class="sub-heading">Advantage</td>
                            <td>
                                <p class="para">Strategic De-  Manufacturing</p>
                            </td>
                            <td>
                                <p class="para">Agnostic to cell  chemistry or structure</p>
                            </td>
                            <td>
                                <p class="para">High removal of low-  value byproducts</p>
                            </td>
                            <td>
                                <p class="para">No hazardous waste  Zero liquid discharge</p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
    <section class="section">
        <div class="container">
            <h2 class="heading text-center">Leveraging Recyvolt’s strengths</h2>
            <p class="para text-center">Spent batteries are currently treated as waste and not as a valuable domestic resource</p>
            <div class="row">
                <div class="col col-md-6">
                    <div class="row h-100">
                        <div class="col col-md-6">
                            <div class="leavrage_desc">
                                <span><img src="<?php echo BASE_PATH; ?>assets/images/tick.webp" alt="" width="38" height="auto"></span>
                                <h3>Barriers to Entry</h3>
                            </div>
                            <div class="leavrage_desc">
                                <span><img src="<?php echo BASE_PATH; ?>assets/images/tick.webp" alt="" width="38" height="auto"></span>
                                <h3>Global Operations & Integrated Supply Chain</h3>
                            </div>
                            <div class="leavrage_desc">
                                <span><img src="<?php echo BASE_PATH; ?>assets/images/tick.webp" alt="" width="38" height="auto"></span>
                                <h3>Operation Excellence</h3>
                            </div>
                            <div class="leavrage_desc">
                                <span><img src="<?php echo BASE_PATH; ?>assets/images/tick.webp" alt="" width="38" height="auto"></span>
                                <h3>Strong Partnering Capability</h3>
                            </div>
                        </div>
                        <div class="col col-md-6">
                            <div class="leavrage_desc">
                                <span><img src="<?php echo BASE_PATH; ?>assets/images/tick.webp" alt="" width="38" height="auto"></span>
                                <h3>Turnkey Recycling Technology Solutions</h3>
                            </div>
                            <div class="leavrage_desc">
                                <span><img src="<?php echo BASE_PATH; ?>assets/images/tick.webp" alt="" width="38" height="auto"></span>
                                <h3>Robust Management</h3>
                            </div>
                            <div class="leavrage_desc">
                                <span><img src="<?php echo BASE_PATH; ?>assets/images/tick.webp" alt="" width="38" height="auto"></span>
                                <h3>Customised & Value Added Products</h3>
                            </div>
                            <div class="leavrage_desc">
                                <span><img src="<?php echo BASE_PATH; ?>assets/images/tick.webp" alt="" width="38" height="auto"></span>
                                <h3>Risk Mitigation-Back to Back Hedging Mechanism</h3>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col col-md-6 p-0">
                    <figure>
                        <img class="w-100" src="<?php echo BASE_PATH; ?>assets/images/strengths.webp" alt="" width="540" height="auto">
                    </figure>
                </div>
            </div>
        </div>
    </section>
    <section class="section">
        <div class="container">
            <h2 class="heading text-center">Barriers to Entry</h2>
            <p class="para text-center">EV Recycling company to save environment</p>
            <div class="row d-flex">
                <div class="col col-sm-6 col-md-3 col-lg-2">
                    <div class="barrier_card">
                        <img src="<?php echo BASE_PATH; ?>assets/images/tick.webp" alt="" width="38" height="auto">
                        <p class="para">Time & Cost of Entry</p>
                    </div>
                </div>
                <div class="col col-sm-6 col-md-3 col-lg-2">
                    <div class="barrier_card">
                        <img src="<?php echo BASE_PATH; ?>assets/images/tick.webp" alt="" width="38" height="auto">
                        <p class="para">Specialist  Knowledge</p>
                    </div>
                </div>
                <div class="col col-sm-6 col-md-3 col-lg-2">
                    <div class="barrier_card">
                        <img src="<?php echo BASE_PATH; ?>assets/images/tick.webp" alt="" width="38" height="auto">
                        <p class="para">Import License in India</p>
                    </div>
                </div>
                <div class="col col-sm-6 col-md-3 col-lg-2">
                    <div class="barrier_card">
                        <img src="<?php echo BASE_PATH; ?>assets/images/tick.webp" alt="" width="38" height="auto">
                        <p class="para">OEM Approvals</p>
                    </div>
                </div>
                <div class="col col-sm-6 col-md-3 col-lg-2">
                    <div class="barrier_card">
                        <img src="<?php echo BASE_PATH; ?>assets/images/tick.webp" alt="" width="38" height="auto">
                        <p class="para">Multinational  Procurement  Network</p>
                    </div>
                </div>
                <div class="col col-sm-6 col-md-3 col-lg-2">
                    <div class="barrier_card">
                        <img src="<?php echo BASE_PATH; ?>assets/images/tick.webp" alt="" width="38" height="auto">
                        <p class="para">Capability to  Develop Customized  Products</p>
                    </div>
                </div>
            </div>
            <div class="row mx-auto d-flex justify-content-center">
                <div class="circle_box">
                    <img class="mb-3" src="<?php echo BASE_PATH; ?>assets/images/entry-barrier.webp" alt="entry-barrier" width="90" height="auto">
                    <h3 class="sub-heading">India Specific Entry Barrier</h3>
                </div>
            </div>
        </div>
    </section>
    <?php include 'common/footer.php';?>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
      crossorigin="anonymous"
    ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
      AOS.init();
    </script>
    <script src="<?php echo BASE_PATH; ?>assets/js/main.js"></script>
  </body>
</html>
