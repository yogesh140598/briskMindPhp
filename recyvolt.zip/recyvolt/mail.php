<?php

  use PHPMailer\PHPMailer\PHPMailer;
  use PHPMailer\PHPMailer\Exception;
  $output = " ";

  if (isset($_POST['submit'])) {
      
    require 'PHPMailer/src/Exception.php';
    require 'PHPMailer/src/PHPMailer.php';
    require 'PHPMailer/src/SMTP.php';

    $name = $_POST['name'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $position = $_POST['position'];
    $radio = $_POST['radio'];
    $message = $_POST['message'];
    

    $msg_show = "<div><b>User Name-</b> $name</div>";
    $msg_show .= "<div><b>User Email-</b> $email</div>";
    $msg_show .= "<div><b>User Number-</b> $mobile</div>";
    $msg_show .= "<div><b>User Number-</b> $position</div>";
    $msg_show .= "<div><b>Want Solution For-</b> $radio</div>";
    $msg_show .= "<div><b>User Message-</b> $message </div>";

    $subject = 'testing'; 

    $mail = new PHPMailer; 
    $mail->Host = 'smtp.gmail.com';             // Specify main and backup SMTP servers
    $mail->SMTPDebug = 2;
    $mail->SMTPAuth = true;                     // Enable SMTP authentication
    $mail->Username = 'xyzRecyvolt@gmail.com';          // SMTP username
    $mail->Password = 'xyzRecyvolt'; // SMTP password
    $mail->SMTPSecure = 'TLS';                  // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 587;
    $mail->setFrom('xyzRecyvolt@gmail.com', 'Recyvolt');
    $mail->addAddress($email);
    $mail->addBCC('xyzRecyvolt@gmail.com');

    $mail->isHTML(true);  // Set email format to HTML
    $mail->Subject = $subject;
    $mail->Body    = $msg_show;
     
    // echo 'hloo ';

    if($mail->send()) {
        $output = '';
        // echo 'sent';
        //return true;
        // echo 'Mailer Success';
    } 
    else {
    //  echo 'Message could not be sent.';

        // echo 'Mailer Error: ' . $mail->ErrorInfo;

    }
  }
    // $txt = "Name = ". $name . "\r\n Email = " . $email . "\r\n Message = " . $message . "\r\n Mobile number = ". $mobile ;
    // $txt2 = "\r\n organization = ". $radio ;

    // echo $txt;
    // echo $txt2;

//redirect
header("Location:thank-you");
?>