<?php include 'common/config.php';?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <?php include 'common/library.php';?>
    <title>Contact us</title>
  </head>
  <body>
    <?php include 'common/header.php';?>
    <section class="contact_banner banner_height">
        <div class="container h-100 d-flex align-items-center">
            
        </div>
    </section>
    <section class="section">
        <div class="container">
            <div class="row d-flex dashed-line pb-0">
                <div class="col-md-4 mb-5">
                    <figure>
                        <img class="img-fluid m-hide show" src="<?php echo BASE_PATH; ?>assets/images/header_logo.png" width="200" height="auto" alt="">
                        <img class="img-fluid m-show hide" src="<?php echo BASE_PATH; ?>assets/images/header_logo.png" width="150" height="auto" alt="">
                    </figure>
                </div>
                <div class="col-md-4 mb-5 d-flex justify-content-start">
                   <div class="me-4">
                    <img src="<?php echo BASE_PATH; ?>assets/images/contact.svg" width="50" height="auto" alt="">
                   </div>
                    <div>
                        <h4 class="sub-heading">Quick Contact</h4>
                        <p class="mb-0">Phone: +91 9899991388</p>
                        <a class="para" href="mailto:info@recyvolt.com">Email:info@recyvolt.com</a>
                    </div>
                </div>
                <div class="col-md-4 d-flex justify-content-start">
                    <div class="me-4">
                        <img src="<?php echo BASE_PATH; ?>assets/images/location.svg" width="35" height="auto" alt="">
                    </div>
                    <div>
                        <h4 class="sub-heading">Our Location</h4>
                        <p class="para">Plot No. 17 & 18, Anand Industrial Estate, Mohan Nagar, Ghaziabad, Uttar Pradesh 201007</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <form action="<?php echo BASE_PATH; ?>contact-mail.php" class="row" method="post">
                        <div class="col-md-6 px-3">
                          <label class="form-label">FULL NAME*</label>
                          <input required type="text" name="name" class="form-control" placeholder="Name" >
                        </div>
                        <div class="col-md-6 px-3">
                          <label class="form-label">EMAIL*</label>
                          <input required type="email" name="email" class="form-control" placeholder="Email" >
                        </div>
                        <div class="col-md-6 px-3">
                          <label class="form-label">PHONE NUMBER*</label>
                          <input required type="text" name="mobile" class="form-control" placeholder="Phone Number" min="10" max="10">
                        </div>
                        <div class="col-md-6 px-3">
                          <label class="form-label">SUBJECT</label>
                            <select class="form-select form-control" name="option" aria-label="Default select example">
                                <option value="1">One</option>
                                <option value="2">Two</option>
                                <option value="3">Three</option>
                            </select>
                        </div>
                        <div class="col-md-12">
                          <label class="form-label">YOUR MESSAGE</label>
                          <textarea class="form-control" name="comments" id="comments" placeholder="Comments" rows="3"></textarea>
                        </div>
                        <div>
                          <button type="submit" name="submit" class="btn-custom btn-custom-2">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <?php include 'common/footer.php';?>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
      crossorigin="anonymous"
    ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="<?php echo BASE_PATH; ?>assets/js/main.js"></script>
  </body>
</html>
