<?php include 'common/config.php';?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <link rel="stylesheet" type="text/css" href="<?php echo BASE_PATH; ?>assets/css/fancybox.min.css" />
    <?php include 'common/library.php';?>
    <title>Media</title>
  </head>
  <body class="about-page">
    <?php include 'common/header.php';?>
    <section class="media_banner banner_height">
        <div class="container h-100 d-flex align-items-center">
            <div>
                <h2 class="heading">Media</h2>
            </div>
        </div>
    </section>
    <section class="section">
        <div class="container">
            <h2 class="heading text-center">Recyvolt at a glance</h2>
            <p class="para text-center mb-5">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam gravida eget justo et rutrum. Praesent augue leo, ultricies nonLorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
            <div class="row h-100">
                <div class="col-12 col-sm-12 col-md-9 m-mb-30 h-100">
                    <figure class="pos_r">
                        <a class="overflow-hidden" href="https://www.youtube.com/watch?v=u31qwQUeGuM" title="" data-fancybox="">
                            <img class="border-16 play_icon" src="<?php echo BASE_PATH; ?>assets/images/play-button.svg" alt="">
                            <img class="border-16 mw-100 h-100" alt="" title="" src="https://img.youtube.com/vi/u31qwQUeGuM/maxresdefault.jpg" width="auto" height="auto">
                        </a>
                    </figure>
                </div>
                <div class="col-12 col-sm-12 col-md-3">
                    <div class="row d-flex justify-content-center">
                    <div class="mb-5 border-16 col-12 col-sm-6 col-md-12">
                        <figure class="d-flex justify-content-center pos_r">
                            <a class="border-16 overflow-hidden" href="https://www.youtube.com/watch?v=u31qwQUeGuM" title="" data-fancybox="">
                                <img class="play_icon" src="<?php echo BASE_PATH; ?>assets/images/play-button.svg" alt="">
                                <img class="mx-auto" alt="" title="" src="https://img.youtube.com/vi/u31qwQUeGuM/maxresdefault.jpg" width="300" height="auto">
                            </a>
                        </figure>
                    </div>
                    <div class="mb-5 border-16 col-12 col-sm-6 col-md-12">
                        <figure class="d-flex justify-content-center pos_r">
                            <a class="border-16 overflow-hidden" href="https://www.youtube.com/watch?v=u31qwQUeGuM" title="" data-fancybox="">
                                <img class="play_icon" src="<?php echo BASE_PATH; ?>assets/images/play-button.svg" alt="">
                                <img class="mx-auto" alt="" title="" src="https://img.youtube.com/vi/u31qwQUeGuM/maxresdefault.jpg" width="300" height="auto">
                            </a>
                        </figure>
                    </div>
                    <div class="mb-0 border-16 col-12 col-sm-6 col-md-12">
                        <figure class="d-flex justify-content-center pos_r">
                            <a class="border-16 overflow-hidden" href="https://www.youtube.com/watch?v=u31qwQUeGuM" title="" data-fancybox="">
                                <img class="play_icon" src="<?php echo BASE_PATH; ?>assets/images/play-button.svg" alt="">
                                <img class="mx-auto" alt="" title="" src="https://img.youtube.com/vi/u31qwQUeGuM/maxresdefault.jpg" width="300" height="auto">
                            </a>
                        </figure>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="section">
        <div class="container">
            <h2 class="heading text-center">Our Proud Moments</h2>
            <p class="para text-center mb-5">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam gravida eget justo et rutrum. Praesent augue leo, ultricies non</p>
            <div class="row">
                <div class="col-12 col-sm-12 col-md-4 mb-4 d-flex justify-content-center">
                    <a href="<?php echo BASE_PATH; ?>assets/images/media-gallery-1.webp" data-fancybox="images">
                        <img src="<?php echo BASE_PATH; ?>assets/images/media-gallery-1.webp" width="360" height="auto" />
                    </a>
                </div>
                <div class="col-12 col-sm-12 col-md-4 mb-4 d-flex justify-content-center">
                    <a href="<?php echo BASE_PATH; ?>assets/images/media-gallery-2.webp" data-fancybox="images">
                        <img src="<?php echo BASE_PATH; ?>assets/images/media-gallery-2.webp" width="360" height="auto" />
                    </a>
                </div>
                <div class="col-12 col-sm-12 col-md-4 mb-4 d-flex justify-content-center">
                    <a href="<?php echo BASE_PATH; ?>assets/images/media-gallery-3.webp" data-fancybox="images">
                        <img src="<?php echo BASE_PATH; ?>assets/images/media-gallery-3.webp" width="360" height="auto" />
                    </a>
                </div>
                <div class="col-12 col-sm-12 col-md-4 mb-4 d-flex justify-content-center">
                    <a href="<?php echo BASE_PATH; ?>assets/images/media-gallery-4.webp" data-fancybox="images">
                        <img src="<?php echo BASE_PATH; ?>assets/images/media-gallery-4.webp" width="360" height="auto" />
                    </a>
                </div>
                <div class="col-12 col-sm-12 col-md-4 mb-4 d-flex justify-content-center">
                    <a href="<?php echo BASE_PATH; ?>assets/images/media-gallery-5.webp" data-fancybox="images">
                        <img src="<?php echo BASE_PATH; ?>assets/images/media-gallery-5.webp" width="360" height="auto" />
                    </a>
                </div>
                <div class="col-12 col-sm-12 col-md-4 mb-4 d-flex justify-content-center">
                    <a href="<?php echo BASE_PATH; ?>assets/images/media-gallery-6.webp" data-fancybox="images">
                        <img src="<?php echo BASE_PATH; ?>assets/images/media-gallery-6.webp" width="360" height="auto" />
                    </a>
                </div>
                <div class="col-12 col-sm-12 col-md-4 mb-4 d-flex justify-content-center">
                    <a href="<?php echo BASE_PATH; ?>assets/images/media-gallery-7.webp" data-fancybox="images">
                        <img src="<?php echo BASE_PATH; ?>assets/images/media-gallery-7.webp" width="360" height="auto" />
                    </a>
                </div>
                <div class="col-12 col-sm-12 col-md-4 mb-4 d-flex justify-content-center">
                    <a href="<?php echo BASE_PATH; ?>assets/images/media-gallery-8.webp" data-fancybox="images">
                        <img src="<?php echo BASE_PATH; ?>assets/images/media-gallery-8.webp" width="360" height="auto" />
                    </a>
                </div>
                <div class="col-12 col-sm-12 col-md-4 mb-4 d-flex justify-content-center">
                    <a href="<?php echo BASE_PATH; ?>assets/images/media-gallery-9.webp" data-fancybox="images">
                        <img src="<?php echo BASE_PATH; ?>assets/images/media-gallery-9.webp" width="360" height="auto" />
                    </a>
                </div>
            </div>
        </div>
    </section>
    <?php include 'common/footer.php';?>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
      crossorigin="anonymous"
    ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="<?php echo BASE_PATH; ?>assets/js/fancybox.min.js"></script>
    <script src="<?php echo BASE_PATH; ?>assets/js/main.js"></script>
  </body>
</html>
