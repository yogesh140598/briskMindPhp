<?php include 'common/config.php';?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <?php include 'common/library.php';?>
    <title>Thank you</title>
  </head>
  <body class="career-page">
    <?php include 'common/header.php';?>
    <section class="section bg-grey">
        <div class="container">
            <div class="row d-flex align-items-center h-100">
                <div class="col-12 col-sm-12 col-md-6">
                    <figure>
                        <img class="img-fluid mb-5" src="<?php echo BASE_PATH; ?>assets/images/thank-you.webp" alt="thank-you">
                    </figure>
                </div>
                <div class="col-12 col-sm-12 col-md-6">
                    <h2 class="heading mb-3">Thank You! for contacting us.</h2>
                    <h3 class="sub-heading mb-5">We will update u soon...</h3>
                    <a href="<?php echo BASE_PATH; ?>" class="btn-custom">Home</a>
                </div>
            </div>
        </div>
    </section>
    <?php include 'common/footer.php';?>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
      crossorigin="anonymous"
    ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="<?php echo BASE_PATH; ?>assets/js/main.js"></script>
  </body>
</html>
