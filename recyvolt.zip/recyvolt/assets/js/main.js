$(document).ready(function () {
    var url = window.location;
// Will only work if string in href matches with location
    $('li.nav-item a.nav-link[href="' + url + '"]').parent().addClass('active');

    $('li.nav-item a.nav-link').filter(function () {
        return this.href == url;
    }).parent().addClass('active').parent().parent().addClass('active');
});