<?php include 'common/config.php';?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <link rel="stylesheet" type="text/css" href="<?php echo BASE_PATH; ?>assets/css/owl.carousel.min.css" />
    <?php include 'common/library.php';?>
    <title>Recyvolt</title>
  </head>
  <body>
    <?php include 'common/header.php';?>
    <section class="banner banner_height bcg_green">
      <div class="container">
        <div class="row d-flex m-flex-column h-100 align-items-center">
          <div class="banner_tilt_text">
            <div class="">
              <h2>BATTERY</h2>
              <h3>RECYCLING</h3>
            </div>
          </div>
          <div class="d-flex flex-column m-center banner_home_text">
            <div>
              <h3>Unlock hidden value with</br> full-service lithium-ion </h3>
              <h2>Battery Recycling</h2>
            </div>
          </div>
          <div class="d-flex flex-column m-center banner_home_text_mob">
            <div class=" m-show hide">
              <h3>Unlock hidden value with</br> full-service lithium-ion </h3>
              <h2>Battery Recycling</h2>
            </div>
          </div>
        </div>
      </div>
    </section>
    <main class="section_one">
      <section class="section banner_green">
        <div class="container">
          <div class="row pos_r d-flex flex-md-row flex-column-reverse">
            <div class="down-1">
              <img src="<?php echo BASE_PATH; ?>assets/images/down-1-arrow.svg" width="190" height="auto" alt="down-arrow">
            </div>
            <div class="col-12 col-md-7 d-flex">
                <div class="row">
                  <div class="col-12 col-sm-12 col-md-6 d-flex justify-content-start mb-4">
                      <div class="me-4">
                          <img src="<?php echo BASE_PATH; ?>assets/images/contact.svg" width="50" height="auto" alt="">
                      </div>
                      <div>
                          <h4 class="sub-heading">Quick Contact</h4>
                          <p class="mb-0">Phone: +91 9899991388</p>
                          <a class="para" href="mailto:info@recyvolt.com">Email: info@recyvolt.com</a>
                      </div>
                  </div>
                  <div class="col-12 col-sm-12 col-md-6 d-flex justify-content-start mb-4">
                      <div class="me-4">
                          <img src="<?php echo BASE_PATH; ?>assets/images/location.svg" width="35" height="auto" alt="">
                      </div>
                      <div>
                          <h4 class="sub-heading">Our Location</h4>
                          <p class="para">Plot No. 17 & 18, Anand Industrial Estate, Mohan Nagar, Ghaziabad, Uttar Pradesh 201007</p>
                      </div>
                  </div>
                </div>
            </div>
            <div class="col-12 col-md-5">
              <div class="banner_down_con">
                <h3>Batteries made from batteries</h3>
                <p>Recycling No battery lives forever. But being upwards of 97% recyclable, they’re always valuable. Recovering used batteries and recycling them into raw materials for new batteries, we’re lowering the demand for fresh material and moving closer to closing the loop on batteries.</p>
                <a class="btn-custom text-light" href="#">Explore More</a>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section class="section section_two">
          <div class="container">
            <div class="row d-flex align-items-center">
              <div class="col-12 col-sm-12 col-md-8">
                <h2 class="heading">Company Overview</h2>
                <p>RECYVOLT Battery Recycle India is a leader in providing E2E consulting for the critical material and lithium-ion battery  recycling. The Company is focused on developing collaborations for the circular economy required for the  energy transition by treating spent batteries as a valuable resource, instead of hazardous waste – providing  India with its first premier domestic source of Lithium, Nickel, Cobalt and Manganese.</p>
              </div>
              <div class="col-12 col-sm-12 col-md-4">
                <figure>
                  <img src="<?php echo BASE_PATH; ?>assets/images/overview_image.webp" alt="overview_image" width="400" height="auto">
                </figure>
              </div>
            </div>
          </div>
      </section>
    </main>
    
    <section class="section section_3 pos_r">
      <div class="container">
        <div class="row d-flex justify-content-around">
          <div class="col-12 col-sm-12 col-md-4 card_overview">
            <div>
              <figure>
                <img class="mw-100" src="<?php echo BASE_PATH; ?>assets/images/recycling.webp" width="50" height="auto" alt="recycling">
              </figure>
              <h3>Lithium-Ion Battery Recycling</h3>
              <p>Processing spent lithium-ion batteries to recover  and reuse battery metals</p>
            </div>
          </div>
          <div class="col-12 col-sm-12 col-md-4 card_overview">
            <div>
              <figure>
                <img class="mw-100" src="<?php echo BASE_PATH; ?>assets/images/metal-extraction.webp" width="50" height="auto" alt="metal-extraction">
              </figure>
              <h3>Primary Metals Extraction</h3>
              <p>Removing battery metals from primary  resources with new scalable technologies</p>
            </div>
          </div>
          <div class="col-12 col-sm-12 col-md-4 card_overview">
            <div>
              <figure>
                <img class="mw-100" src="<?php echo BASE_PATH; ?>assets/images/resources.webp" width="50" height="auto" alt="resources">
              </figure>
              <h3>Resource Stewardship</h3>
              <p>Gathering mineral resources directly from  miners around the world</p>
            </div>
          </div>
        </div>
        <div class="down-2">
          <img src="<?php echo BASE_PATH; ?>assets/images/down-2-arrow.svg" width="100" height="auto" alt="down-arrow">
        </div>
      </div>
    </section>
    <section class="section blank_section">
    </section>
    <section class="section section_two">
      <div class="container">
        <div class="row mb-5 py-4">
          <div class="col-12 col-md-8">
            <h2 class="heading pt-4 mb-4">RECYVOLT BATTERY TECHNOLOGY INDIA</h2>
            <p>EV Recycling company to save environment</p>
          </div>
          <div class="col-12 col-md-4 amazing">
            <h3>We are on an</h3>
            <h2>AMAZING JOURNEY</h2>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <figure class="d-flex justify-content-center">
              <img class="mw-100  m-hide show mb-4" src="<?php echo BASE_PATH; ?>assets/images/road_map.webp" alt="roadMap" width="1280" height="auto">
            </figure>
            <figure class="d-flex justify-content-center">
              <img class="mw-100 m-show hide" src="<?php echo BASE_PATH; ?>assets/images/road_map_mob.webp" alt="roadMap" width="360" height="auto">
            </figure>
          </div>
          <div class="down-3">
            <img src="<?php echo BASE_PATH; ?>assets/images/down-2-arrow.svg" width="100" height="auto" alt="down-arrow">
          </div>
        </div>
      </div>
    </section>
    <section class="section bcg-green">
      <div class="container">
        <div class="row">
          <div class="col-12 col-sm-12 col-md-5">
            <div class="row text-center text-md-start">
              <div class="col-12 col-sm-6 battery_text">
                <h2>25</h2>
                <h4>Years of experience in Recyling industry </h4>
              </div>
              <div class="col-12 col-sm-6 mb-70 m-mb-30">
                <figure>
                  <img class="mw-100" src="<?php echo BASE_PATH; ?>assets/images/battery.webp" alt="battery" width="169" height="auto">
                </figure>
              </div>
            </div>
          </div>
          <div class="down-4">
              <img src="<?php echo BASE_PATH; ?>assets/images/down-1-arrow.svg" width="190" height="auto" alt="down-arrow">
            </div>
          <div class="col-12 col-sm-12 col-md-7 border-left">
            <h2 class="heading">HOW RECYVOLT’S EV BATTERY RECYCLING IN INDIA IS SUPPORTING A CIRCULAR ECONOMY</h2>
            <p class="para">As the world moves away from petrol and diesel engines, the demand for electric vehicles is increasing. This is a positive move, as Electric Vehicles (EV) are a much more environmentally friendly solution for the automotive industry, and help to reduce the global reliance on fossil fuels. The increase in EV production does however inevitably mean an increase in the consumption of lithium-ion batteries. In fact, the global battery market has actually doubled in size over the last five years alone, and it is only going to get bigger.</p>
          </div>
        </div>
      </div>
    </section>
    <section class="section">
      <div class="container">
        <div class="row d-flex align-items-center">
          <div class="col-12 col-sm-12 col-md-6">
            <h2 class="heading">Advantages of using EV and Pace with which EVs are getting used</h2>
            <figure class="d-flex justify-content-center mb-5">
              <img class="mw-100  m-show hide " src="<?php echo BASE_PATH; ?>assets/images/ev_vehicle.webp" alt="ev_vehicle" width="527" height="auto">
            </figure>
            <p>Electrification of vehicles is a trillion dollar global opportunity and India has the potential to become a leader. As the automotive world is pacing to transform to the electric lane, India is also catching up the race. The concept of clean mobility with renewable power sources is now accepted by market leaders but there are several challenges from infrastructure to the basic question of what happens to EV batteries once their life cycles are over. Recycling EV batteries and extracting the unused metal is looking as an efficient solution to make EVs more affordable. Amidst Covid, Indians got a first-hand experienced of a truly clean air. The populous realized in one month that pollution is solvable, clean air is possible and that electrification is a critical step to transition. We were already seeing a huge interest in EVs pre-Covid and now the momentum is only increasing.</p>
          </div>
          <div class="down-5">
              <img src="<?php echo BASE_PATH; ?>assets/images/down-5-arrow.svg" width="150" height="auto" alt="down-arrow">
          </div>
          <div class="col-12 col-sm-12 col-md-6">
            <figure class="d-flex justify-content-end m-hide show">
              <img class="mw-100 m-hide" src="<?php echo BASE_PATH; ?>assets/images/ev_vehicle.webp" alt="ev_vehicle" width="527" height="auto">
            </figure>
          </div>
        </div>
      </div>
    </section>
    <section class="section section_one">
      <div class="container">
        <div class="row d-flex align-items-center">
          <div class="col-12 col-sm-12 col-md-6">
            <h2 class="heading m-show hide">What’s the challenge towards acceptance</h2>
            <figure class="d-flex justify-content-center justify-content-md-start">
              <img class="mw-100" src="<?php echo BASE_PATH; ?>assets/images/challenges.webp" alt="challenges" width="540" height="auto">
            </figure>
          </div>
          <div class="col-12 col-sm-12 col-md-6">
            <h2 class="heading m-hide show">What’s the challenge towards acceptance</h2>
            <ul class="challenges_list">
                <li class="para pos_r"><span class="coloured_line"></span> Inadequate charging infrastructure</li>
                <li class="para pos_r"><span class="coloured_line"></span> Reliance on battery imports</li>
                <li class="para pos_r"><span class="coloured_line"></span> Reliance on imported components and parts</li>
                <li class="para pos_r"><span class="coloured_line"></span> Incentives linked to local manufacturing</li>
                <li class="para pos_r"><span class="coloured_line"></span> Range anxiety among consumers</li>
                <li class="para pos_r"><span class="coloured_line"></span> High price of EVs currently</li>
                <li class="para pos_r"><span class="coloured_line"></span> Lack of options for high-performance EVs</li>
                <li class="para pos_r"><span class="coloured_line"></span> Inadequate electricity supply in parts of India</li>
                <li class="para pos_r"><span class="coloured_line"></span> Lack of quality maintenance and repair options</li>
                <li class="para pos_r"><span class="coloured_line"></span> Affected by broader automobile industry downturn</li>
            </ul>
          </div>
          <div class="down-7">
            <img src="<?php echo BASE_PATH; ?>assets/images/down-7-arrow.svg" width="210" height="auto" alt="down-arrow">
          </div>
        </div>
      </div>
    </section>
    <section class="section">
      <div class="container">
        <div class="row d-flex align-items-center">
          <div class="col-12 col-sm-12 col-md-6">
            <h2 class="heading">How can we solve the challenge</h2>
            <figure class="d-flex justify-content-center">
              <img class="mw-100 m-show hide" src="<?php echo BASE_PATH; ?>assets/images/battery_car.webp" alt="battery_car" width="540" height="auto">
            </figure>
            <p>As Indian economy is caught up in a slowdown, the future of the automobile industry is pinned on electric vehicles. And EV technology in India is, in turn, highly dependent on innovation and government incentives. At the same time, the government has to tackle the slowdown and invest in future-ready technology at the same time. This has led to a deep dichotomy in the Indian electric vehicles market which has put the future of EV technology in India in a bit of a muddle. </p>
          </div>
          <div class="col-12 col-sm-12 col-md-6">
            <figure class="d-flex justify-content-end">
              <img class="mw-100 m-hide show" src="<?php echo BASE_PATH; ?>assets/images/battery_car.webp" alt="battery_car" width="540" height="auto">
            </figure>
          </div>
        </div>
      </div>
    </section>
    <?php include 'common/footer.php';?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script type="text/javascript">
      document.addEventListener("DOMContentLoaded", function(){
            /////// Prevent closing from click inside dropdown
            document.querySelectorAll('.dropdown-menu').forEach(function(element){
              element.addEventListener('click', function (e) {
                e.stopPropagation();
              });
            })
        }); 
    </script>
    <script src="<?php echo BASE_PATH; ?>assets/js/owl.carousel.min.js" type="text/javascript"></script>
    <script>
        $('#client_slider').owlCarousel({
          margin: 10,
          autoHeight: true,
          nav: false,
          navigation: false,
          loop: true,
          autoplay: true,
          slideBy: 1,
          dotsEach: true,
          dots: true,
          //   autoWidth:true,
          responsive: {
            360: {
              items: 1,
            },
            600: {
              items: 1,
            },
            1120: {
              items: 1,
            },
            1480: {
              items: 1,
            },
            1850: {
              items: 1,
            }
          }
        });
    </script>
    <script src="<?php echo BASE_PATH; ?>assets/js/main.js"></script>
  </body>
</html>
