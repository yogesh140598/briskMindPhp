<?php include 'common/config.php';?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <link rel="stylesheet" type="text/css" href="<?php echo BASE_PATH; ?>assets/css/owl.carousel.min.css" />
    <?php include 'common/library.php';?>
    <title>Brisk Mind</title>
  </head>
  <body>
    <?php include 'common/header.php';?>
    <section class="banner banner_height">
      <div class="container h-100">
        <div class="row d-flex m-flex-column h-100">
          <div class="col-md-7 d-flex justify-content-center flex-column m-center banner_home_text">
            <h2 class="banner_sub">Global Leaders in </h2>
            <div class="banner_heading_box">
              <h1 class="banner_heading">Talent Assessment, Talent Acquisition & Talent Development. </h1>
            </div>
            <p class="banner_para">Conduct Customized Online Assessments on our Powerful Cloud-based Platform, Secured with Best-in-class Proctoring</p>
            <div class="d-flex w-100">
              <a href="" class="btn-custom">Get Started</a>
            </div>
          </div>
          <div class="col-md-3"></div>
        </div>
      </div>
    </section>
    <main class="background_vector">
      <section class="section">
        <div class="container">
            <h2 class="heading text-center">Our Trusted Clients</h2>
            <p class="para text-center">Trusted by the Industry Leaders</p>
            <div id="" class="row d-flex justify-content-center align-item-center">
              <div class="col col-6 col-sm-6 col-md-2" data-aos="flip-left"  data-aos-duration="1000">
                <div class="item">
                  <figure>
                    <img src="<?php echo BASE_PATH; ?>assets/images/steel-sector-log.png" width="180" height="auto" alt="">
                  </figure>
                </div>
              </div>
              <div class="col col-6 col-sm-6 col-md-2" data-aos="flip-left"  data-aos-duration="1000">
                <div class="item">
                  <figure>
                    <img src="<?php echo BASE_PATH; ?>assets/images/mining-sector-logo.png" width="180" height="auto" alt="">
                  </figure>
                </div>
              </div>
              <div class="col col-6 col-sm-6 col-md-2" data-aos="flip-left"  data-aos-duration="1000">
                <div class="item">
                  <figure>
                    <img src="<?php echo BASE_PATH; ?>assets/images/home-sector-logo.png" width="180" height="auto" alt="">
                  </figure>
                </div>
              </div>
              <div class="col col-6 col-sm-6 col-md-2" data-aos="flip-left"  data-aos-duration="1000">
                <div class="item">
                  <figure>
                    <img src="<?php echo BASE_PATH; ?>assets/images/essci-logo.png" width="180" height="auto" alt="">
                  </figure>
                </div>
              </div>
              <div class="col col-6 col-sm-6 col-md-2" data-aos="flip-left"  data-aos-duration="1000">
                <div class="item">
                  <figure>
                    <img src="<?php echo BASE_PATH; ?>assets/images/healthcare-logo.png" width="180" height="auto" alt="">
                  </figure>
                </div>
              </div>
              <div class="col col-6 col-sm-6 col-md-2" data-aos="flip-left"  data-aos-duration="1000">
                <div class="item">
                  <figure>
                    <img src="<?php echo BASE_PATH; ?>assets/images/igtr-logo.png" width="180" height="auto" alt="">
                  </figure>
                </div>
              </div>
            </div>
        </div>
      </section>
      <section class="section">
        <div class="container">
          <div class="row d-flex">
            <div class="col-md-6" data-aos="zoom-out-left" data-aos-duration="1500">
              <img class="mw-100 m-hide show" src="<?php echo BASE_PATH; ?>assets/images/global_leader.webp" width="580" height="auto" alt="">
            </div>
            <div class="col-md-6 d-flex flex-column justify-content-center" data-aos="zoom-out-right" data-aos-duration="1500">
              <h2 class="heading mb-0">Briskmind: </h2>
              <h2 class="heading mb-20">The Global Leader in Talent Assessment</h2>
              <img class="mw-100 m-show hide mb-20" src="<?php echo BASE_PATH; ?>assets/images/global_leader.webp" width="580" height="auto" alt="">
              <p class="para mb-4">Conduct Customized Online Assessments on our Powerful Cloud-based Platform, Secured with Best-in-class Proctoring</p>
              <div class="yellow-line mb-3"></div>
              <div class="d-flex">
                <a href="/talent-assessment.html" class="btn-custom">Get Started</a>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section class="section">
        <div class="container">
          <div class="row d-flex">
            <div class="col-md-6 d-flex flex-column justify-content-center"  data-aos="zoom-out-left" data-aos-duration="1500">
              <h2 class="heading mb-0">Briskmind: </h2>
              <h2 class="heading mb-20">Talent Acquisition</h2>
              <img class="mw-100 m-show hide mb-20" src="<?php echo BASE_PATH; ?>assets/images/talent_aqua.webp" width="580" height="auto" alt="">
              <p class="para mb-4">Hire diverse talent to build a high-performing workforce using our proven acquisition methods</p>
              <div class="yellow-line mb-3"></div>
              <div class="d-flex">
                <a href="/talent-acquisition.html" class="btn-custom">Get Started</a>
              </div>
            </div>
            <div class="col-md-6 d-flex justify-content-end"  data-aos="zoom-out-right" data-aos-duration="1500">
              <img class="mw-100 m-hide show" src="<?php echo BASE_PATH; ?>assets/images/talent_aqua.webp" width="580" height="auto" alt="">
            </div>
          </div>
        </div>
      </section>
      <section class="section">
        <div class="container">
          <div class="row d-flex">
            <div class="col-md-6"  data-aos="zoom-out-left" data-aos-duration="1500">
              <img class="mw-100 m-hide show" src="<?php echo BASE_PATH; ?>assets/images/talent_dev.webp" width="580" height="auto" alt="">
            </div>
            <div class="col-md-6 d-flex flex-column justify-content-center"  data-aos="zoom-out-right" data-aos-duration="1500">
              <h2 class="heading mb-0">Briskmind: </h2>
              <h2 class="heading mb-20">Talent Development</h2>
              <img class="mw-100 m-show hide mb-20" src="<?php echo BASE_PATH; ?>assets/images/talent_dev.webp" width="580" height="auto" alt="">
              <p class="para mb-4">Briskmind is helping the organization to build competencies through customized learning interventions. Our efforts have resulted in more engaged employees and holistic growth of our client. We do Leadership Development, Sales & Services, Personal Effectiveness, Soft skills training, Communication development, Team building etc.</p>
              <div class="yellow-line mb-3"></div>
              <div class="d-flex">
                <a href="/talent-development.html" class="btn-custom">Get Started</a>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section class="section">
        <div class="container">
          <div class="row d-flex">
            <div class="col-md-6 d-flex flex-column justify-content-center"  data-aos="zoom-out-left" data-aos-duration="1500">
              <h2 class="heading mb-0">Briskmind: </h2>
              <h2 class="heading mb-20">Advantages of Industry specific verification approach</h2>
              <img class="mw-100 m-show hide mb-20" src="<?php echo BASE_PATH; ?>assets/images/talent_industry.webp" width="580" height="auto" alt="">
              <p class="para mb-4">Cutting-edge authentication products and alternate data analysis for your business. Building trust through data.</p>
              <div class="yellow-line mb-3"></div>
              <div class="d-flex">
                <a href="/background-verification.html" class="btn-custom">Get Started</a>
              </div>
            </div>
            <div class="col-md-6 d-flex justify-content-end"  data-aos="zoom-out-right" data-aos-duration="1500">
              <img class="mw-100 m-hide show" src="<?php echo BASE_PATH; ?>assets/images/talent_industry.webp" width="580" height="auto" alt="">
            </div>
          </div>
        </div>
      </section>
      <section class="section">
        <div class="container">
          <div class="row d-flex">
            <div class="col-md-6"  data-aos="zoom-out-left" data-aos-duration="1500">
              <img class="mw-100 m-hide show" src="<?php echo BASE_PATH; ?>assets/images/consultancy.webp" width="580" height="auto" alt="">
            </div>
            <div class="col-md-6 d-flex flex-column justify-content-center"  data-aos="zoom-out-right" data-aos-duration="1500">
              <h2 class="heading mb-0">Briskmind: </h2>
              <h2 class="heading mb-20">Consulting</h2>
              <img class="mw-100 m-show hide mb-20" src="<?php echo BASE_PATH; ?>assets/images/consultancy.webp" width="580" height="auto" alt="">
              <p class="para mb-4">Brisk Mind Private Limited will act as the Technical Agency. TA needs to help the IA in not only preparation of DSR and subsequent DPR but also in identification of competent CDA, implementation of SI and HI as per the plan. They are also expected to help IA in framing proper O&M framework for CFC maintenance.</p>
              <div class="yellow-line mb-3"></div>
              <div class="d-flex">
                <a href="/consulting.html" class="btn-custom">Get Started</a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
    <section class="section client_banner">
      <div class="container">
        <div class="row d-flex flex-column">
          <div>
            <h2 class="heading text-center text-light mb-50">We empower some of the biggest </br>organizations to assess their workforce</h2>
          </div>
        </div>
        <div class="row d-flex">
          <div class="col-md-4 d-flex justify-content-center align-items-center flex-column">
            <div class="num heading text-light">200 +</div>
            <p class="para text-light mb-20">Skills Assessed</p>
          </div>
          <div class="col-md-4 d-flex justify-content-center align-items-center flex-column">
            <div class="num heading text-light">1,50,000 +</div>
            <p class="para text-light mb-20">Candidates Assessed</p>
          </div>
          <div class="col-md-4 d-flex justify-content-center align-items-center flex-column">
            <div class="num heading text-light">20 +</div>
            <p class="para text-light mb-20">Languages Supported</p>
          </div>
        </div>
      </div>
    </section>
    <section class="section">
      <div class="container">
        <div class="row">
          <h2 class="heading text-center">Over 600 Clients Globally Trust Us </br>With Their Talent Assessment</h2>
          <p class="para text-center mb-50">Hear what our clients have to say about our virtual talent assessment tools</p>
        </div>
      </div>
      <div class="container">
        <div id="client_slider" class="owl-carousel">
          <div class="card_box">
            <h2 class="text-start sub-heading mb-20">Brisk Mind has been one of our Assessment Partners for the Last 6 Years now. They provide their insights and expertise to us for doing Assessments on a PAN India level </h2>
            <h3 class="text-end">Apparel Made Ups &</br>
              Home Furnishing Sector Skill Council</h3>
          </div>
          <div class="card_box">
            <h2 class="text-start sub-heading mb-20">Brisk Mind has been one of our Assessment Partners for the Last 6 Years now. They provide their insights and expertise to us for doing Assessments on a PAN India level </h2>
            <h3 class="text-end">Apparel Made Ups &</br>
              Home Furnishing Sector Skill Council</h3>
          </div>
          <div class="card_box">
            <h2 class="text-start sub-heading mb-20">Brisk Mind has been one of our Assessment Partners for the Last 6 Years now. They provide their insights and expertise to us for doing Assessments on a PAN India level </h2>
            <h3 class="text-end">Apparel Made Ups &</br>
              Home Furnishing Sector Skill Council</h3>
          </div>
        </div>
      </div>
    </section>
    <?php include 'common/client-form.php';?>
    <?php include 'common/footer.php';?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script type="text/javascript">
      document.addEventListener("DOMContentLoaded", function(){
            /////// Prevent closing from click inside dropdown
            document.querySelectorAll('.dropdown-menu').forEach(function(element){
              element.addEventListener('click', function (e) {
                e.stopPropagation();
              });
            })
        }); 
    </script>
    <script src="<?php echo BASE_PATH; ?>assets/js/owl.carousel.min.js" type="text/javascript"></script>
    <script>
        $('#client_slider').owlCarousel({
          margin: 10,
          autoHeight: true,
          nav: false,
          navigation: true,
          loop: true,
          autoplay: true,
          slideBy: 1,
          dotsEach: true,
          dots: true,
          //   autoWidth:true,
          responsive: {
            360: {
              items: 1,
            },
            600: {
              items: 1,
            },
            1120: {
              items: 1,
            },
            1480: {
              items: 1,
            },
            1850: {
              items: 1,
            }
          }
        });
    </script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
      AOS.init();
    </script>
    <script src="<?php echo BASE_PATH; ?>assets/js/main.js"></script>
  </body>
</html>
