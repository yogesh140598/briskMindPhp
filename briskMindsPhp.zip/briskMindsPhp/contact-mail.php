<?php

$name = $_POST['name'];
$mobile = $_POST['mobile'];
$email = $_POST['email'];
$option = $_POST['option'];
$comments = $_POST['comments'];

$to = $email;
$subject = "Test mail";
$txt = "Name = ". $name . "\r\n Email = " . $email . "\r\n Option = " . $option . "\r\n Mobile number = ". $mobile ;

$headers = "From: yogeshkandari14@gmail.com" . "\r\n" . "CC:somebody@exampe.com";
if($email!=NULL){
    // mail($to,$subject,$txt,$headers);
    ini_set($to,$headers);
}

echo $name;
echo $mobile;
echo $email;
echo $option;
echo $comments;
//redirect
// header("Location:thankyou.php");
?>