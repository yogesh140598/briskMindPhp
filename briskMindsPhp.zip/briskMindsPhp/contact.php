<?php include 'common/config.php';?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <?php include 'common/library.php';?>
    <title>Contact us</title>
  </head>
  <body>
    <?php include 'common/header.php';?>
    <section class="banner_inside">
      <div class="container h-100">
        <div class="row d-flex m-flex-column align-items-center h-100">
          <div class="col-md-6">
            <figure class="m-show hide">
              <img class="img-fluid" width="520" height="auto"  src="<?php echo BASE_PATH; ?>assets/images/contact.webp" alt="contact us">
            </figure>
            <h2 class="heading mb-5">Contact Us</h2>
            <p class="para mb-3">Brisk Mind Private Limited will act as the Technical Agency. TA needs to help the IA in not only preparation of DSR and subsequent DPR but also in identification of competent CDA, implementation of SI and HI as per the plan. They are also expected to help IA in framing proper O&M framework for CFC maintenance.</p>
            <div class="yellow-line mb-5"></div>
            <button class="btn-custom">Get Started</button>
        </div>
          <div class="col-md-6">
            <figure class="d-flex justify-content-end">
                <img class="m-hide show img-fluid" width="600" height="auto"  src="<?php echo BASE_PATH; ?>assets/images/contact.webp" alt="contact us">
            </figure>
          </div>
        </div>
      </div>
    </section>
    <section class="section">
        <div class="container">
            <div class="row d-flex dashed-line pb-0">
                <div class="col-md-4 mb-5">
                    <figure>
                        <img class="img-fluid m-hide show" src="<?php echo BASE_PATH; ?>assets/images/header_logo.png" width="200" height="auto" alt="">
                        <img class="img-fluid m-show hide" src="<?php echo BASE_PATH; ?>assets/images/header_logo.png" width="150" height="auto" alt="">
                    </figure>
                </div>
                <div class="col-md-4 mb-5 d-flex justify-content-start">
                   <div class="me-4">
                    <img src="<?php echo BASE_PATH; ?>assets/images/contact.svg" width="50" height="auto" alt="">
                   </div>
                    <div>
                        <h4 class="sub-heading">Quick Contact</h4>
                        <p>Phone: +91 9899991388</p>
                        <a class="para" href="mailto:operations@briskmind.in">Email: operations@briskmind.in</a>
                    </div>
                </div>
                <div class="col-md-4 d-flex justify-content-start">
                    <div class="me-4">
                        <img src="<?php echo BASE_PATH; ?>assets/images/location.svg" width="35" height="auto" alt="">
                    </div>
                    <div>
                        <h4 class="sub-heading">Our Location</h4>
                        <p class="para">Plot No. 17 & 18, Anand Industrial Estate, Mohan Nagar, Ghaziabad, Uttar Pradesh 201007</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <form action="<?php echo BASE_PATH; ?>contact-mail.php" class="row" method="post">
                        <div class="col-md-6 px-3">
                          <label class="form-label">FULL NAME*</label>
                          <input required type="text" name="name" class="form-control" placeholder="Name" >
                        </div>
                        <div class="col-md-6 px-3">
                          <label class="form-label">EMAIL*</label>
                          <input required type="email" name="email" class="form-control" placeholder="Email" >
                        </div>
                        <div class="col-md-6 px-3">
                          <label class="form-label">PHONE NUMBER*</label>
                          <input required type="text" name="mobile" class="form-control" placeholder="Phone Number" >
                        </div>
                        <div class="col-md-6 px-3">
                          <label class="form-label">SUBJECT</label>
                            <select class="form-select form-control" name="option" aria-label="Default select example">
                                <option value="1">One</option>
                                <option value="2">Two</option>
                                <option value="3">Three</option>
                            </select>
                        </div>
                        <div class="col-md-12">
                          <label class="form-label">YOUR MESSAGE</label>
                          <textarea class="form-control" name="comments" id="comments" placeholder="Comments" rows="3"></textarea>
                        </div>
                        <div>
                          <button type="submit" name="submit" class="btn-custom">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <?php include 'common/footer.php';?>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
      crossorigin="anonymous"
    ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
      AOS.init();
    </script>
    <script src="<?php echo BASE_PATH; ?>assets/js/main.js"></script>
  </body>
</html>
