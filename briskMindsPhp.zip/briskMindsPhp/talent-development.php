<?php include 'common/config.php';?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <?php include 'common/library.php';?>
    <title>Talent Development</title>
  </head>
  <body class="talent-dev">
    <?php include 'common/header.php';?>
    <main class="background_vector">
      <section class="banner_inside">
        <div class="container h-100">
          <div class="row d-flex m-flex-column align-items-center h-100">
            <div class="col-md-6">
              <figure class="m-show hide">
                <img class="img-fluid" src="<?php echo BASE_PATH; ?>assets/images/talent_dev.webp" width="520" height="auto" alt="Global Leader">
              </figure>
              <h2 class="heading">Briskmind:</h2>
              <h2 class="heading mb-5">Talent Development</h2>
              <p class="para mb-3">Hire Briskmind is helping the organization to build competencies through customized learning interventions. Our efforts have resulted in more engaged employees and holistic growth of our client. We do Leadership Development, Sales & Services, Personal Effectiveness, Soft skills training, Communication development, Team building etc.</p>
              <div class="yellow-line mb-5"></div>
              <button class="btn-custom">Get Started</button>
            </div>
            <div class="col-md-6">
              <figure class="d-flex justify-content-end ">
                  <img class="m-hide show img-fluid" src="<?php echo BASE_PATH; ?>assets/images/talent_dev.webp" width="600" height="auto" alt="Global Leader">
              </figure>
            </div>
          </div>
        </div>
      </section>
      <section class="section">
          <div class="container">
              <div class="row">
                  <div class="col-md-10 text-center mx-auto">
                      <h2 class="heading">Our Solutions</h2>
                      <p class="para mb-50">Whatever the Development program you are looking for, Briskmind has the right solution to help you make wise Talent Development decisions </p>                
                  </div>
                  <div class="col-md-12">
                      <div class="solution_list">
                          <ul class="">
                              <li class="solution_list_box" data-aos="flip-left"  data-aos-duration="1000">
                                  <div class="mb-5">
                                      <img src="<?php echo BASE_PATH; ?>assets/images/leadership-dev.svg" alt="">
                                  </div>
                                  <h3 class="sub-heading">LEADERSHIP DEVELOPMENT</h3>
                              </li>
                              <li class="solution_list_box" data-aos="flip-right"  data-aos-duration="1000">
                                  <div class="mb-5">
                                      <img src="<?php echo BASE_PATH; ?>assets/images/communication-dev.svg" alt="">
                                  </div>
                                  <h3 class="sub-heading">COMMUNICATION DEVELOPMENT</h3>
                              </li>
                              <li class="solution_list_box" data-aos="flip-left"  data-aos-duration="1000">
                                  <div class="mb-5">
                                      <img src="<?php echo BASE_PATH; ?>assets/images/sales-service.svg" alt="">
                                  </div>
                                  <h3 class="sub-heading">SALES & SERVICES</h3>
                              </li>
                              <li class="solution_list_box" data-aos="flip-right"  data-aos-duration="1000">
                                  <div class="mb-5">
                                      <img src="<?php echo BASE_PATH; ?>assets/images/personal-effictive.svg" alt="">
                                  </div>
                                  <h3 class="sub-heading">PERSONAL EFFECTIVENESS</h3>
                              </li>
                              <li class="solution_list_box" data-aos="flip-left"  data-aos-duration="1000">
                                  <div class="mb-5">
                                      <img src="<?php echo BASE_PATH; ?>assets/images/team-building.svg" alt="">
                                  </div>
                                  <h3 class="sub-heading">TEAM BUILDING & OUTBOUND</h3>
                              </li>
                          </ul>
                      </div>
                  </div>
              </div>
          </div>
      </section>
      <section class="section">
        <div class="container">
          <h2 class="heading text-center">PROGRAMS</h2>
          <p class="para text-center mb-3 px-md-5">Our solutions over the years have delivered exponential results in the area of building strong leadership, identifying talent, nurturing talent, developing talent, engaging employees and crafting culture.</p>
          <p class="para text-center mb-5 px-md-5">The insight gained by working across various industries has helped Step Learning offer relevant customized solutions to our clients. Find our signature programs towards organizational efficiency.</p>
          <div class="row">
            <div class="col col-sm-6 col-md-6 mb-5" data-aos="flip-right"  data-aos-duration="1000">
              <div class="offering_card">
                <div >
                  <img  class="w-100" src="<?php echo BASE_PATH; ?>assets/images/leadership-program.webp" alt="Leadership Development">
                </div>
                <div class="offering_card_content">
                  <div>
                    <h3 class="sub-heading">Leadership Development</h3>
                    <p class="para">Great leaders are the bridge between organization and people. Strong leadership results in great results. Employees’ perception of an organization is limited to his perspective towards leaders. Strong leadership is the key enabler of organizational growth. </p>
                  </div>
                  <div>
                    <button class="btn-custom btn-custom-2-light">
                    Learn More
                  </button>
                  </div>
                </div>
              </div>
            </div>
            <div class="col col-sm-6 col-md-6 mb-5" data-aos="flip-left"  data-aos-duration="1000">
              <div class="offering_card">
                <div >
                  <img  class="w-100" src="<?php echo BASE_PATH; ?>assets/images/sales-program.webp" alt="Sales & Service">
                </div>
                <div class="offering_card_content">
                  <div>
                    <h3 class="sub-heading">Sales & Service</h3>
                    <p class="para">While the core of selling remains the same the buying process has changed over the years. With the newer process we need to renew skill sets. We unify the best of both worlds to raise the sales performance.</p>
                  </div>
                  <div>
                    <button class="btn-custom btn-custom-2-light">
                    Learn More
                  </button>
                  </div>
                </div>
              </div>
            </div>
            <div class="col col-sm-6 col-md-6 mb-5" data-aos="flip-right"  data-aos-duration="1000">
              <div class="offering_card">
                <div >
                  <img  class="w-100" src="<?php echo BASE_PATH; ?>assets/images/team-program.webp" alt="TEAM BUILDING & OUTBOUD">
                </div>
                <div class="offering_card_content">
                  <div>
                    <h3 class="sub-heading">TEAM BUILDING & OUTBOUD</h3>
                    <p class="para">Briskmindis committed to increasing the engagement levels of the employee through its signature experiential Team Building & Outbound Workshops. Our programs help individuals realize the power in collaboration and replicate the same in the workplace. </p>
                  </div>
                  <div>
                    <button class="btn-custom btn-custom-2-light">
                    Learn More
                  </button>
                  </div>
                </div>
              </div>
            </div>
            <div class="col col-sm-6 col-md-6 mb-5" data-aos="flip-left"  data-aos-duration="1000">
              <div class="offering_card">
                <div >
                  <img  class="w-100" src="<?php echo BASE_PATH; ?>assets/images/communication-program.webp" alt="Communication Development Training">
                </div>
                <div class="offering_card_content">
                  <div>
                    <h3 class="sub-heading">Communication Development Training</h3>
                    <p class="para">The greatest part of our success depends on how we interact at the workplace. Ability to communicate is a direct catalyst to individual and organizational success. In this program, participants will learn effective ways to communicate in every situation. </p>
                  </div>
                  <div>
                    <button class="btn-custom btn-custom-2-light">
                    Learn More
                  </button>
                  </div>
                </div>
              </div>
            </div>
            <div class="col col-sm-6 col-md-6 mb-5" data-aos="flip-right"  data-aos-duration="1000">
              <div class="offering_card">
                <div >
                  <img  class="w-100" src="<?php echo BASE_PATH; ?>assets/images/personal-program.webp" alt="Personal Effectiveness Training">
                </div>
                <div class="offering_card_content">
                  <div>
                    <h3 class="sub-heading">Personal Effectiveness Training</h3>
                    <p class="para">An organization is as good as their employees. Do more with the available resource. Between the growing technologies, its very important to preserve human values. The journey of organizational growth starts with growth in human capital. </p>
                  </div>
                  <div>
                    <button class="btn-custom btn-custom-2-light">
                    Learn More
                  </button>
                  </div>
                </div>
              </div>
            </div>
            <div class="col col-sm-6 col-md-6 mb-5" data-aos="flip-left"  data-aos-duration="1000">
              <div class="offering_card justify-content-start">
                <div >
                  <img class="w-100" src="<?php echo BASE_PATH; ?>assets/images/blur-program.webp" alt="lot more to come">
                </div>
                <div class=" offering_card_content justify-content-center align-items-center">
                  <div>
                    <h3 class="blur-text">Lot More to Come</h3>
                  </div>
                  <div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <?php include 'common/client-form.php';?>
    </main>
    <?php include 'common/footer.php';?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
      AOS.init();
    </script>
    <script src="<?php echo BASE_PATH; ?>assets/js/main.js"></script>
  </body>
</html>
