<?php

  use PHPMailer\PHPMailer\PHPMailer;
  use PHPMailer\PHPMailer\Exception;
  $output = " ";

  if (isset($_POST['submit'])) {
      
    require 'PHPMailer/src/Exception.php';
    require 'PHPMailer/src/PHPMailer.php';
    require 'PHPMailer/src/SMTP.php';

    $name = $_POST['name'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $company = $_POST['company'];
    $radio = $_POST['radio'];
    $message = $_POST['message'];
    $redirect_url = $_POST['redirecgt_url'];
    

    $msg_show = "<div><b>User Name-</b> $name</div>";
    $msg_show .= "<div><b>User Email-</b> $email</div>";
    $msg_show .= "<div><b>User Number-</b> $mobile</div>";
    $msg_show .= "<div><b>User Number-</b> $company</div>";
    $msg_show .= "<div><b>Want Solution For-</b> $radio</div>";
    $msg_show .= "<div><b>User Message-</b> $message </div>";

    $subject = 'testing'; 

    $mail = new PHPMailer; 
    $mail->Host = 'smtp.gmail.com';             // Specify main and backup SMTP servers
    $mail->SMTPDebug = 2;
    $mail->SMTPAuth = true;                     // Enable SMTP authentication
    $mail->Username = 'yogeshkandari1405@gmail.com';          // SMTP username
    $mail->Password = 'hsegoygmail@12'; // SMTP password
    $mail->SMTPSecure = 'TLS';                  // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 587;
    $mail->setFrom('yogeshkandari1405@gmail.com', 'Yogesh');
    $mail->addAddress($email);
    $mail->addBCC('yogeshkandari1405@gmail.com');

    $mail->isHTML(true);  // Set email format to HTML
    $mail->Subject = $subject;
    $mail->Body    = $msg_show;
     
    echo 'hloo ';

    if($mail->send()) {
        $output = '';
        // echo 'sent';
        //return true;
          header('index.php?msg=1');
    } 
    else {
    //  echo 'Message could not be sent.';

        $url = "$redirect_url?msg=0";
        header("Location: $url");
        echo 'Mailer Error: ' . $mail->ErrorInfo;

    }
  }else{
      $redirect_url += '?msg=0';
      header("Location:$redirect_url");
  }
    $txt = "Name = ". $name . "\r\n Email = " . $email . "\r\n Message = " . $message . "\r\n Mobile number = ". $mobile ;
    $txt2 = "\r\n organization = ". $radio ;

    echo $txt;
    echo $txt2;

//redirect
//header("Location:thankyou.php");
?>