<?php include 'common/config.php';?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <?php include 'common/library.php';?>
    <title>Career</title>
  </head>
  <body class="career-page">
    <?php include 'common/header.php';?>
    <main class="background_vector">
      <section class="banner_inside">
        <div class="container h-100">
          <div class="row d-flex m-flex-column align-items-center h-100">
            <div class="col-md-6">
              <figure class="m-show hide">
                <img class="img-fluid"  width="500" height="auto" src="<?php echo BASE_PATH; ?>assets/images/career.webp" alt="Career">
              </figure>
              <h2 class="heading mb-5">Career</h2>
              <p class="para mb-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam gravida eget justo et rutrum. Praesent augue leo, ultricies nonLorem ipsum dolor sit amet, consectetur adipiscing elit. Nam gravida eget justo et rutrum. </p>
              <div class="yellow-line mb-5"></div>
            </div>
            <div class="col-md-6">
              <figure class="d-flex justify-content-end ">
                  <img class="m-hide show img-fluid" width="600" height="auto"  src="<?php echo BASE_PATH; ?>assets/images/career.webp" alt="Career">
              </figure>
            </div>
          </div>
        </div>
      </section>
      <section class="section">
          <div class="accordion container" id="accordionExample">
              <div class="row d-flex job-form accordian-item">
                  <div class="col-md-4 separator m-hide show">
                      <div class="job-list">
                          <ul>
                              <li class="accordion-header" id="headingOne">
                                  <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    <h3 class="job-heading">Web Developer</h3>
                                    <p class="para mb-0">Noida , Gurgaon</p>
                                  </button>
                              </li>
                              <li class="accordion-header" id="headingTwo">
                                  <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                                    <h3 class="job-heading">Front-end Developer</h3>
                                    <p class="para mb-0">Noida , Gurgaon</p>
                                  </button>
                              </li>
                              <li class="accordion-header" id="headingThree">
                                  <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
                                    <h3 class="job-heading">Angular developer</h3>
                                    <p class="para mb-0">Noida , Gurgaon</p>
                                  </button>
                              </li>
                              <li class="accordion-header" id="headingFour">
                                  <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="true" aria-controls="collapseFour">
                                    <h3 class="job-heading">React Developer</h3>
                                    <p class="para mb-0">Noida , Gurgaon</p>
                                  </button>
                              </li>
                              <li class="accordion-header" id="headingFive">
                                  <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="true" aria-controls="collapseFive">
                                    <h3 class="job-heading">Javascript Developer</h3>
                                    <p class="para mb-0">Noida , Gurgaon</p>
                                  </button>
                              </li>
                              <li class="accordion-header" id="headingSix">
                                  <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSix" aria-expanded="true" aria-controls="collapseSix">
                                    <h3 class="job-heading">MEAN Stack Developer</h3>
                                    <p class="para mb-0">Noida , Gurgaon</p>
                                  </button>
                              </li>
                              <li class="accordion-header" id="headingSeven">
                                  <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSeven" aria-expanded="true" aria-controls="collapseSeven">
                                    <h3 class="job-heading">MERN Stack Developer</h3>
                                    <p class="para mb-0">Noida , Gurgaon</p>
                                  </button>
                              </li>
                          </ul>
                      </div>
                  </div>
                  <div class="col-md-8">
                    <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                            <form action="<?php echo BASE_PATH; ?>career-mail.php" method="post" class="row">
                                <h3 class="sub-heading mb-5">Apply Job</h3>
                                <div class="col-md-12 px-3">
                                    <label for="name" class="form-label">Name</label>
                                    <input type="text" class="form-control" name="name" placeholder="Name" aria-label="Name">
                                </div>
                                <div class="col-md-6 px-3">
                                    <label for="email" class="form-label">Official Email</label>
                                    <input type="text" class="form-control" name="email" placeholder="Official Email" aria-label="Official Email">
                                </div>
                                <div class="col-md-6 px-3">
                                    <label for="phone" class="form-label">Phone</label> 
                                    <input type="text" class="form-control" name="mobile" placeholder="Phone" aria-label="Phone">
                                </div>
                                <div class="col-md-12 px-3">
                                    <label for="post" class="form-label">Post Applying for</label> 
                                    <select class="form-select form-control" name="option" aria-label="Default select example">
                                        <option value="web" selected>Web Developer</option>
                                        <option value="front-end">Front-end Developer</option>
                                        <option value="angular">Angular Developer</option>
                                        <option value="react">React Developer</option>
                                        <option value="javascript">Javascript Developer</option>
                                        <option value="mean-stack">Mean-Stack Developer</option>
                                        <option value="mern-stack">Mern-Stack Developer</option>
                                    </select>
                                </div>
                                <div class="col-md-12 px-3 upload_file">
                                    <label for="cv" class="form-label">Upload CV</label> 
                                    <span class="upload_icon"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-upload" viewBox="0 0 16 16"> <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"/> <path d="M7.646 1.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8.5 2.707V11.5a.5.5 0 0 1-1 0V2.707L5.354 4.854a.5.5 0 1 1-.708-.708l3-3z"/> </svg></span>
                                    <input type="text"  class="form-control" placeholder="Please Upload PNG, JPEG, PDF only (File Size : Max 5 MB)">
                                    <input type="file" id="myfile" name="myfile" class="form-control" placeholder="Company" aria-label="Company">
                                </div>
                                <div class="col-md-12">
                                    <label for="message" class="form-label">Message</label> 
                                    <textarea class="form-control" name="message" id="comments" placeholder="Comments" rows="3"></textarea>
                                </div>
                                <div class="d-flex justify-content-center">
                                    <button type="submit" name="submit" class="btn-custom">Apply Now</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                            <form action="<?php echo BASE_PATH; ?>career-mail.php" method="post" class="row">
                                <h3 class="sub-heading mb-5">Apply Job</h3>
                                <div class="col-md-12 px-3">
                                    <label for="name" class="form-label">Name</label>
                                    <input type="text" class="form-control" name="name" placeholder="Name" aria-label="Name">
                                </div>
                                <div class="col-md-6 px-3">
                                    <label for="email" class="form-label">Official Email</label>
                                    <input type="text" class="form-control" name="email" placeholder="Official Email" aria-label="Official Email">
                                </div>
                                <div class="col-md-6 px-3">
                                    <label for="phone" class="form-label">Phone</label> 
                                    <input type="text" class="form-control" name="mobile" placeholder="Phone" aria-label="Phone">
                                </div>
                                <div class="col-md-12 px-3">
                                    <label for="post" class="form-label">Post Applying for</label> 
                                    <select class="form-select form-control" name="option" aria-label="Default select example">
                                        <option value="web" selected>Web Developer</option>
                                        <option value="front-end" selected>Front-end Developer</option>
                                        <option value="angular">Angular Developer</option>
                                        <option value="react">React Developer</option>
                                        <option value="javascript">Javascript Developer</option>
                                        <option value="mean-stack">Mean-Stack Developer</option>
                                        <option value="mern-stack">Mern-Stack Developer</option>
                                    </select>
                                </div>
                                <div class="col-md-12 px-3 upload_file">
                                    <label for="cv" class="form-label">Upload CV</label> 
                                    <span class="upload_icon"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-upload" viewBox="0 0 16 16"> <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"/> <path d="M7.646 1.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8.5 2.707V11.5a.5.5 0 0 1-1 0V2.707L5.354 4.854a.5.5 0 1 1-.708-.708l3-3z"/> </svg></span>
                                    <input type="text"  class="form-control" placeholder="Please Upload PNG, JPEG, PDF only (File Size : Max 5 MB)">
                                    <input type="file" id="myfile" name="myfile" class="form-control" placeholder="Company" aria-label="Company">
                                </div>
                                <div class="col-md-12">
                                    <label for="message" class="form-label">Message</label> 
                                    <textarea class="form-control" name="message" id="comments" placeholder="Comments" rows="3"></textarea>
                                </div>
                                <div class="d-flex justify-content-center">
                                    <button type="submit" name="submit" class="btn-custom">Apply Now</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                            <form action="<?php echo BASE_PATH; ?>career-mail.php" method="post" class="row">
                                <h3 class="sub-heading mb-5">Apply Job</h3>
                                <div class="col-md-12 px-3">
                                    <label for="name" class="form-label">Name</label>
                                    <input type="text" class="form-control" name="name" placeholder="Name" aria-label="Name">
                                </div>
                                <div class="col-md-6 px-3">
                                    <label for="email" class="form-label">Official Email</label>
                                    <input type="text" class="form-control" name="email" placeholder="Official Email" aria-label="Official Email">
                                </div>
                                <div class="col-md-6 px-3">
                                    <label for="phone" class="form-label">Phone</label> 
                                    <input type="text" class="form-control" name="mobile" placeholder="Phone" aria-label="Phone">
                                </div>
                                <div class="col-md-12 px-3">
                                    <label for="post" class="form-label">Post Applying for</label> 
                                    <select class="form-select form-control" name="option" aria-label="Default select example">
                                        <option value="web" selected>Web Developer</option>
                                        <option value="front-end">Front-end Developer</option>
                                        <option value="angular" selected>Angular Developer</option>
                                        <option value="react">React Developer</option>
                                        <option value="javascript">Javascript Developer</option>
                                        <option value="mean-stack">Mean-Stack Developer</option>
                                        <option value="mern-stack">Mern-Stack Developer</option>
                                    </select>
                                </div>
                                <div class="col-md-12 px-3 upload_file">
                                    <label for="cv" class="form-label">Upload CV</label> 
                                    <span class="upload_icon"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-upload" viewBox="0 0 16 16"> <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"/> <path d="M7.646 1.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8.5 2.707V11.5a.5.5 0 0 1-1 0V2.707L5.354 4.854a.5.5 0 1 1-.708-.708l3-3z"/> </svg></span>
                                    <input type="text"  class="form-control" placeholder="Please Upload PNG, JPEG, PDF only (File Size : Max 5 MB)">
                                    <input type="file" id="myfile" name="myfile" class="form-control" placeholder="Company" aria-label="Company">
                                </div>
                                <div class="col-md-12">
                                    <label for="message" class="form-label">Message</label> 
                                    <textarea class="form-control" name="message" id="comments" placeholder="Comments" rows="3"></textarea>
                                </div>
                                <div class="d-flex justify-content-center">
                                    <button type="submit" name="submit" class="btn-custom">Apply Now</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                            <form action="<?php echo BASE_PATH; ?>career-mail.php" method="post" class="row">
                                <h3 class="sub-heading mb-5">Apply Job</h3>
                                <div class="col-md-12 px-3">
                                    <label for="name" class="form-label">Name</label>
                                    <input type="text" class="form-control" name="name" placeholder="Name" aria-label="Name">
                                </div>
                                <div class="col-md-6 px-3">
                                    <label for="email" class="form-label">Official Email</label>
                                    <input type="text" class="form-control" name="email" placeholder="Official Email" aria-label="Official Email">
                                </div>
                                <div class="col-md-6 px-3">
                                    <label for="phone" class="form-label">Phone</label> 
                                    <input type="text" class="form-control" name="mobile" placeholder="Phone" aria-label="Phone">
                                </div>
                                <div class="col-md-12 px-3">
                                    <label for="post" class="form-label">Post Applying for</label> 
                                    <select class="form-select form-control" name="option" aria-label="Default select example">
                                        <option value="web" selected>Web Developer</option>
                                        <option value="front-end">Front-end Developer</option>
                                        <option value="angular">Angular Developer</option>
                                        <option value="react" selected>React Developer</option>
                                        <option value="javascript">Javascript Developer</option>
                                        <option value="mean-stack">Mean-Stack Developer</option>
                                        <option value="mern-stack">Mern-Stack Developer</option>
                                    </select>
                                </div>
                                <div class="col-md-12 px-3 upload_file">
                                    <label for="cv" class="form-label">Upload CV</label> 
                                    <span class="upload_icon"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-upload" viewBox="0 0 16 16"> <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"/> <path d="M7.646 1.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8.5 2.707V11.5a.5.5 0 0 1-1 0V2.707L5.354 4.854a.5.5 0 1 1-.708-.708l3-3z"/> </svg></span>
                                    <input type="text"  class="form-control" placeholder="Please Upload PNG, JPEG, PDF only (File Size : Max 5 MB)">
                                    <input type="file" id="myfile" name="myfile" class="form-control" placeholder="Company" aria-label="Company">
                                </div>
                                <div class="col-md-12">
                                    <label for="message" class="form-label">Message</label> 
                                    <textarea class="form-control" name="message" id="comments" placeholder="Comments" rows="3"></textarea>
                                </div>
                                <div class="d-flex justify-content-center">
                                    <button type="submit" name="submit" class="btn-custom">Apply Now</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFive" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                            <form action="<?php echo BASE_PATH; ?>career-mail.php" method="post" class="row">
                                <h3 class="sub-heading mb-5">Apply Job</h3>
                                <div class="col-md-12 px-3">
                                    <label for="name" class="form-label">Name</label>
                                    <input type="text" class="form-control" name="name" placeholder="Name" aria-label="Name">
                                </div>
                                <div class="col-md-6 px-3">
                                    <label for="email" class="form-label">Official Email</label>
                                    <input type="text" class="form-control" name="email" placeholder="Official Email" aria-label="Official Email">
                                </div>
                                <div class="col-md-6 px-3">
                                    <label for="phone" class="form-label">Phone</label> 
                                    <input type="text" class="form-control" name="mobile" placeholder="Phone" aria-label="Phone">
                                </div>
                                <div class="col-md-12 px-3">
                                    <label for="post" class="form-label">Post Applying for</label> 
                                    <select class="form-select form-control" name="option" aria-label="Default select example">
                                        <option value="web" selected>Web Developer</option>
                                        <option value="front-end">Front-end Developer</option>
                                        <option value="angular">Angular Developer</option>
                                        <option value="react">React Developer</option>
                                        <option value="javascript" selected>Javascript Developer</option>
                                        <option value="mean-stack">Mean-Stack Developer</option>
                                        <option value="mern-stack">Mern-Stack Developer</option>
                                    </select>
                                </div>
                                <div class="col-md-12 px-3 upload_file">
                                    <label for="cv" class="form-label">Upload CV</label> 
                                    <span class="upload_icon"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-upload" viewBox="0 0 16 16"> <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"/> <path d="M7.646 1.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8.5 2.707V11.5a.5.5 0 0 1-1 0V2.707L5.354 4.854a.5.5 0 1 1-.708-.708l3-3z"/> </svg></span>
                                    <input type="text"  class="form-control" placeholder="Please Upload PNG, JPEG, PDF only (File Size : Max 5 MB)">
                                    <input type="file" id="myfile" name="myfile" class="form-control" placeholder="Company" aria-label="Company">
                                </div>
                                <div class="col-md-12">
                                    <label for="message" class="form-label">Message</label> 
                                    <textarea class="form-control" name="message" id="comments" placeholder="Comments" rows="3"></textarea>
                                </div>
                                <div class="d-flex justify-content-center">
                                    <button type="submit" name="submit" class="btn-custom">Apply Now</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div id="collapseSix" class="accordion-collapse collapse" aria-labelledby="headingSix" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                            <form action="<?php echo BASE_PATH; ?>career-mail.php" method="post" class="row">
                                <h3 class="sub-heading mb-5">Apply Job</h3>
                                <div class="col-md-12 px-3">
                                    <label for="name" class="form-label">Name</label>
                                    <input type="text" class="form-control" name="name" placeholder="Name" aria-label="Name">
                                </div>
                                <div class="col-md-6 px-3">
                                    <label for="email" class="form-label">Official Email</label>
                                    <input type="text" class="form-control" name="email" placeholder="Official Email" aria-label="Official Email">
                                </div>
                                <div class="col-md-6 px-3">
                                    <label for="phone" class="form-label">Phone</label> 
                                    <input type="text" class="form-control" name="mobile" placeholder="Phone" aria-label="Phone">
                                </div>
                                <div class="col-md-12 px-3">
                                    <label for="post" class="form-label">Post Applying for</label> 
                                    <select class="form-select form-control" name="option" aria-label="Default select example">
                                        <option value="web" selected>Web Developer</option>
                                        <option value="front-end">Front-end Developer</option>
                                        <option value="angular">Angular Developer</option>
                                        <option value="react">React Developer</option>
                                        <option value="javascript">Javascript Developer</option>
                                        <option value="mean-stack" selected>Mean-Stack Developer</option>
                                        <option value="mern-stack">Mern-Stack Developer</option>
                                    </select>
                                </div>
                                <div class="col-md-12 px-3 upload_file">
                                    <label for="cv" class="form-label">Upload CV</label> 
                                    <span class="upload_icon"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-upload" viewBox="0 0 16 16"> <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"/> <path d="M7.646 1.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8.5 2.707V11.5a.5.5 0 0 1-1 0V2.707L5.354 4.854a.5.5 0 1 1-.708-.708l3-3z"/> </svg></span>
                                    <input type="text"  class="form-control" placeholder="Please Upload PNG, JPEG, PDF only (File Size : Max 5 MB)">
                                    <input type="file" id="myfile" name="myfile" class="form-control" placeholder="Company" aria-label="Company">
                                </div>
                                <div class="col-md-12">
                                    <label for="message" class="form-label">Message</label> 
                                    <textarea class="form-control" name="message" id="comments" placeholder="Comments" rows="3"></textarea>
                                </div>
                                <div class="d-flex justify-content-center">
                                    <button type="submit" name="submit" class="btn-custom">Apply Now</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div id="collapseSeven" class="accordion-collapse collapse" aria-labelledby="headingSeven" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                            <form action="<?php echo BASE_PATH; ?>career-mail.php" method="post" class="row">
                                <h3 class="sub-heading mb-5">Apply Job</h3>
                                <div class="col-md-12 px-3">
                                    <label for="name" class="form-label">Name</label>
                                    <input type="text" class="form-control" name="name" placeholder="Name" aria-label="Name">
                                </div>
                                <div class="col-md-6 px-3">
                                    <label for="email" class="form-label">Official Email</label>
                                    <input type="text" class="form-control" name="email" placeholder="Official Email" aria-label="Official Email">
                                </div>
                                <div class="col-md-6 px-3">
                                    <label for="phone" class="form-label">Phone</label> 
                                    <input type="text" class="form-control" name="mobile" placeholder="Phone" aria-label="Phone">
                                </div>
                                <div class="col-md-12 px-3">
                                    <label for="post" class="form-label">Post Applying for</label> 
                                    <select class="form-select form-control" name="option" aria-label="Default select example">
                                        <option value="web" selected>Web Developer</option>
                                        <option value="front-end">Front-end Developer</option>
                                        <option value="angular">Angular Developer</option>
                                        <option value="react">React Developer</option>
                                        <option value="javascript">Javascript Developer</option>
                                        <option value="mean-stack">Mean-Stack Developer</option>
                                        <option value="mern-stack" selected>Mern-Stack Developer</option>
                                    </select>
                                </div>
                                <div class="col-md-12 px-3 upload_file">
                                    <label for="cv" class="form-label">Upload CV</label> 
                                    <span class="upload_icon"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-upload" viewBox="0 0 16 16"> <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"/> <path d="M7.646 1.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8.5 2.707V11.5a.5.5 0 0 1-1 0V2.707L5.354 4.854a.5.5 0 1 1-.708-.708l3-3z"/> </svg></span>
                                    <input type="text"  class="form-control" placeholder="Please Upload PNG, JPEG, PDF only (File Size : Max 5 MB)">
                                    <input type="file" id="myfile" name="myfile" class="form-control" placeholder="Company" aria-label="Company">
                                </div>
                                <div class="col-md-12">
                                    <label for="message" class="form-label">Message</label> 
                                    <textarea class="form-control" name="message" id="comments" placeholder="Comments" rows="3"></textarea>
                                </div>
                                <div class="d-flex justify-content-center">
                                    <button type="submit" name="submit" class="btn-custom">Apply Now</button>
                                </div>
                            </form>
                        </div>
                    </div>
                  </div>
              </div>
          </div>
      </section>
    </main>
    <?php include 'common/footer.php';?>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
      crossorigin="anonymous"
    ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
      AOS.init();
    </script>
    <script src="<?php echo BASE_PATH; ?>assets/js/main.js"></script>
  </body>
</html>
