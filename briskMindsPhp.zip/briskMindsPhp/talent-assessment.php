<?php include 'common/config.php';?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <link rel="stylesheet" type="text/css" href="<?php echo BASE_PATH; ?>assets/css/owl.carousel.min.css" />
    <?php include 'common/library.php';?>
    <title>Talent Assessment</title>
  </head>
  <body class="talent-assesment">
    <?php include 'common/header.php';?>
    <section class="banner_inside">
        <div class="container h-100">
          <div class="row d-flex m-flex-column align-items-center h-100">
            <div class="col-md-6">
              <figure class="m-show hide">
                <img class="img-fluid" src="<?php echo BASE_PATH; ?>assets/images/global_leader.webp" width="500" height="auto" alt="Global Leader">
              </figure>
              <h2 class="heading">Briskmind:</h2>
              <h2 class="heading mb-5">The Global Leader in Talent Assessment</h2>
              <p class="para mb-3">Conduct Customized Online Assessments on our Powerful Cloud-based Platform, Secured with Best-in-class Proctoring</p>
              <div class="yellow-line mb-5"></div>
              <button class="btn-custom mb-5">Get Started</button>
            </div>
            <div class="col-md-6">
              <figure class="d-flex justify-content-end ">
                  <img class="img-fluid m-hide show" src="<?php echo BASE_PATH; ?>assets/images/global_leader.webp" width="550" height="auto" alt="Global Leader">
              </figure>
            </div>
          </div>
        </div>
    </section>
    <main class="background_vector">
      <section class="section">
        <div class="container">
            <h2 class="heading text-center">Our Trusted Clients</h2>
            <p class="para text-center">Trusted by the Industry Leaders</p>
            <div id="" class="row d-flex justify-content-center align-item-center">
              <div class="col col-6 col-sm-6 col-md-2" data-aos="flip-left"  data-aos-duration="1000">
                <div class="item">
                  <figure>
                    <img src="<?php echo BASE_PATH; ?>assets/images/steel-sector-log.png" width="180" height="auto" alt="">
                  </figure>
                </div>
              </div>
              <div class="col col-6 col-sm-6 col-md-2" data-aos="flip-left"  data-aos-duration="1000">
                <div class="item">
                  <figure>
                    <img src="<?php echo BASE_PATH; ?>assets/images/mining-sector-logo.png" width="180" height="auto" alt="">
                  </figure>
                </div>
              </div>
              <div class="col col-6 col-sm-6 col-md-2" data-aos="flip-left"  data-aos-duration="1000">
                <div class="item">
                  <figure>
                    <img src="<?php echo BASE_PATH; ?>assets/images/home-sector-logo.png" width="180" height="auto" alt="">
                  </figure>
                </div>
              </div>
              <div class="col col-6 col-sm-6 col-md-2" data-aos="flip-left"  data-aos-duration="1000">
                <div class="item">
                  <figure>
                    <img src="<?php echo BASE_PATH; ?>assets/images/essci-logo.png" width="180" height="auto" alt="">
                  </figure>
                </div>
              </div>
              <div class="col col-6 col-sm-6 col-md-2" data-aos="flip-left"  data-aos-duration="1000">
                <div class="item">
                  <figure>
                    <img src="<?php echo BASE_PATH; ?>assets/images/healthcare-logo.png" width="180" height="auto" alt="">
                  </figure>
                </div>
              </div>
              <div class="col col-6 col-sm-6 col-md-2" data-aos="flip-left"  data-aos-duration="1000">
                <div class="item">
                  <figure>
                    <img src="<?php echo BASE_PATH; ?>assets/images/igtr-logo.png" width="180" height="auto" alt="">
                  </figure>
                </div>
              </div>
            </div>
        </div>
      </section>
      <section class="section">
        <div class="container">
            <div class="">
                <h2 class="heading text-center">Holistic Online Assessment Tools for <span class="text-purple">Academic Institutes</span> and <span class="text-bright-blue">Corporates</span></h2>
                <p class="para text-center mb-50">Conduct Online Exams | Conduct Virtual Assessments | Hire and Develop Talent</p>
            </div>
            <div class="row d-flex justify-content-between">
                <div class="col-md-4 mb-5" data-aos="flip-right"  data-aos-duration="1000">
                    <div class="card_assesment">
                        <div>
                            <figure>
                                <img class="w-100 img-fluid" src="<?php echo BASE_PATH; ?>assets/images/skill-assessment.webp" alt="">
                            </figure>
                        </div>
                        <div class="p-5">
                            <h3 class="sub-heading">Skill Assessment Solutions</h3>
                            <p class="para mb-3">NSFQ Complaint Assessment</p>
                            <p class="para mb-0">Electronics Sector</p>
                            <p class="para mb-0">Apparel Made Ups & Home furnishing Sector
                            <p class="para mb-0">Healthcare Sector</p>
                            <p class="para mb-0">Mining Sector</p>
                            <p class="para mb-0">Iron & Steel Sector</p>
                            <p class="para mb-3">Green Jobs</p>
                            <button class="btn-custom btn-custom-2-light">Learn More</button>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-5" data-aos="flip-right"  data-aos-duration="1000">
                    <div class="card_assesment">
                        <div>
                            <figure>
                                <img class="w-100 img-fluid" src="<?php echo BASE_PATH; ?>assets/images/talent-assesment.webp" alt="">
                            </figure>
                        </div>
                        <div class="p-5">
                            <h3 class="sub-heading">Talent Assessment Solutions</h3>
                            <p class="para mb-3"> A suite of scientific assessment tools</p>
                            <p class="para mb-0">Psychometric assessments</p>
                            <p class="para mb-0"> Behavioral assessments</p>
                            <p class="para mb-0">Aptitude assessments</p>
                            <p class="para mb-0">Healthcare Sector</p>
                            <p class="para mb-0">Technical assessments</p>
                            <p class="para mb-3">Communication skills assessments</p>
                            
                            <button class="btn-custom btn-custom-2-light">Learn More</button>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-5" data-aos="flip-right"  data-aos-duration="1000">
                    <div class="card_assesment">
                        <div>
                            <figure>
                                <img class="w-100 img-fluid" src="<?php echo BASE_PATH; ?>assets/images/online-examination.webp" alt="">
                            </figure>
                        </div>
                        <div class="p-5">
                            <h3 class="sub-heading">Online Examination Solution</h3>
                            <p class="para mb-3">Conduct online exams at scale using our suite of digital tools</p>
                            <p class="para mb-0">Robust examination platform</p>
                            <p class="para mb-0">A suite of proctoring tools</p>
                            <p class="para mb-0">Evaluation management system</p>
                            <p class="para mb-3">Online certification platform</p>
                            
                            <button class="btn-custom btn-custom-2-light">Learn More</button>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-5" data-aos="flip-left"  data-aos-duration="1000">
                    <div class="card_assesment">
                        <div>
                            <figure>
                                <img class="w-100 img-fluid" src="<?php echo BASE_PATH; ?>assets/images/hiring-solution.webp" alt="">
                            </figure>
                        </div>
                        <div class="p-5">
                            <h3 class="sub-heading">Hiring Solutions</h3>
                            <p class="para mb-3">Assess talent holistically and automate your hiring using our digital tools</p>
                            <p class="para mb-0">Talent screening assessments</p>
                            <p class="para mb-0">Online interview tool</p>
                            <p class="para mb-3">Online hackathon and ideathon platform</p>
                            <button class="btn-custom btn-custom-2-light">Learn More</button>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-5" data-aos="flip-left"  data-aos-duration="1000">
                    <div class="card_assesment">
                        <div>
                            <figure>
                                <img class="w-100 img-fluid" src="<?php echo BASE_PATH; ?>assets/images/ld-solution.webp" alt="">
                            </figure>
                        </div>
                        <div class="p-5">
                            <h3 class="sub-heading">L&D Solutions</h3>
                            <p class="para mb-3">Automate your L&D processes using our digital tools</p>
                            <p class="para mb-0">High-potential identification</p>
                            <p class="para mb-0">Succession planning</p>
                            <p class="para mb-0">Leadership assessments</p>
                            <p class="para mb-0">Assessment & development centers</p>
                            <p class="para mb-0">360-degree feedback platform</p>
                            <p class="para mb-3">Green Jobs</p>
                            <button class="btn-custom btn-custom-2-light">Learn More</button>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-5" data-aos="flip-left"  data-aos-duration="1000">
                    <div class="card_assesment">
                        <div>
                            <figure>
                                <img class="w-100 img-fluid" src="<?php echo BASE_PATH; ?>assets/images/remote.webp" alt="">
                            </figure>
                        </div>
                        <div class="p-5">
                            <h3 class="sub-heading">Remote Proctoring Tools</h3>
                            <p class="para mb-3">Ensure cheating-free online exams using our suite of proctoring tools</p>
                            <p class="para mb-0"> AI-based remote proctoring</p>
                            <p class="para mb-0">Live and recorded proctoring</p>
                            <p class="para mb-3">Available with our platform or as a service on your LMS</p>

                            <button class="btn-custom btn-custom-2-light">Learn More</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </section>
      <section class="section client_banner">
        <div class="container">
          <div class="row d-flex flex-column">
            <div>
              <h2 class="heading text-center text-light mb-50">We empower some of the biggest </br>organizations to assess their workforce</h2>
            </div>
          </div>
          <div class="row d-flex">
            <div class="col-md-4 d-flex justify-content-center align-items-center flex-column">
              <div class="num heading text-light">200 +</div>
              <p class="para text-light mb-20 text-center">Skills Assessed</p>
            </div>
            <div class="col-md-4 d-flex justify-content-center align-items-center flex-column">
              <div class="num heading text-light">1,50,000 +</div>
              <p class="para text-light mb-20 text-center">Candidates Assessed</p>
            </div>
            <div class="col-md-4 d-flex justify-content-center align-items-center flex-column">
              <div class="num heading text-light">20 +</div>
              <p class="para text-light mb-20 text-center">Languages Supported</p>
            </div>
          </div>
        </div>
      </section>
      <section class="section">
        <div class="container">
          <div class="row">
            <h2 class="heading text-center">Over 600 Clients Globally Trust Us </br>With Their Talent Assessment</h2>
            <p class="para text-center mb-50">Hear what our clients have to say about our virtual talent assessment tools</p>
          </div>
        </div>
        <div class="container">
          <div id="client_slider" class="owl-carousel">
            <div class="card_box">
              <h2 class="text-start sub-heading mb-20">Brisk Mind has been one of our Assessment Partners for the Last 6 Years now. They provide their insights and expertise to us for doing Assessments on a PAN India level </h2>
              <h3 class="text-end">Apparel Made Ups &</br>
                Home Furnishing Sector Skill Council</h3>
            </div>
            <div class="card_box">
              <h2 class="text-start sub-heading mb-20">Brisk Mind has been one of our Assessment Partners for the Last 6 Years now. They provide their insights and expertise to us for doing Assessments on a PAN India level </h2>
              <h3 class="text-end">Apparel Made Ups &</br>
                Home Furnishing Sector Skill Council</h3>
            </div>
            <div class="card_box">
              <h2 class="text-start sub-heading mb-20">Brisk Mind has been one of our Assessment Partners for the Last 6 Years now. They provide their insights and expertise to us for doing Assessments on a PAN India level </h2>
              <h3 class="text-end">Apparel Made Ups &</br>
                Home Furnishing Sector Skill Council</h3>
            </div>
          </div>
        </div>
      </section>
      <section class="section">
          <div class="container">
              <h2 class="heading text-center mb-5">We Offer Impeccable Data Security Standards</h2>
              <div class="d-flex justify-content-center">
                  <div class="data-box me-5" data-aos="flip-right"  data-aos-duration="1000">
                      <div>
                          <img class="img-fluid" src="<?php echo BASE_PATH; ?>assets/images/iso-logo.png" alt="Iso" class="logo-sec">
                      </div>
                      <div>
                          <p class="para">ISO 9001 CERTIFIED</p>
                      </div>
                  </div>
                  <div class="data-box" data-aos="flip-right"  data-aos-duration="1000">
                      <div>
                          <img class="img-fluid" src="<?php echo BASE_PATH; ?>assets/images/b-logo.png" alt="Brisk" class="logo-sec">
                      </div>
                      <div>
                          <p class="para">BriskMind Skill Assessment Platform </p>
                      </div>
                  </div>
              </div>
          </div>
      </section>
      <section class="section">
          <div class="container">
              <h2 class="heading text-center">Test your Skills</h2>
              <p class="para text-center mb-5">Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, </p>
              <div class="row d-flex">
                  <div class="col-md-3 skill-box" data-aos="zoom-in"  data-aos-duration="1000">
                      <div>
                          <img src="<?php echo BASE_PATH; ?>assets/images/aptitude.webp" alt="">
                      </div>
                      <div class="skill-box-content">
                          <h3 class="sub-heading">Apptitude Test</h3>
                          <p class="para">Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, </p>
                          <a class="para text-bright-blue" href="#">Take Assessment<span></span></a>
                      </div>
                  </div>
                  <div class="col-md-3 skill-box" data-aos="zoom-in"  data-aos-duration="1000">
                      <div>
                          <img src="<?php echo BASE_PATH; ?>assets/images/psycometric.webp" alt="">
                      </div>
                      <div class="skill-box-content">
                          <h3 class="sub-heading">Psychometric Test</h3>
                          <p class="para">Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, </p>
                          <a class="para text-bright-blue" href="#">Take Assessment<span></span></a>
                      </div>
                  </div>
                  <div class="col-md-3 skill-box" data-aos="zoom-in"  data-aos-duration="1000">
                      <div>
                          <img src="<?php echo BASE_PATH; ?>assets/images/programing.webp" alt="">
                      </div>
                      <div class="skill-box-content">
                          <h3 class="sub-heading">Programming Test</h3>
                          <p class="para">Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, </p>
                          <a class="para text-bright-blue" href="#">Take Assessment<span></span></a>
                      </div>
                  </div>
                  <div class="col-md-3 skill-box" data-aos="zoom-in"  data-aos-duration="1000">
                      <div>
                          <img src="<?php echo BASE_PATH; ?>assets/images/vocational.webp" alt="">
                      </div>
                      <div class="skill-box-content">
                          <h3 class="sub-heading">Vocational Test</h3>
                          <p class="para">Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, </p>
                          <a class="para text-bright-blue" href="#">Take Assessment<span></span></a>
                      </div>
                  </div>
              </div>
          </div>
      </section>
      <section class="section">
          <div class="container">
              <h2 class="heading text-center">Why Choose Briskmind Talent Assessments</h2>
              <p class="para text-center mb-50">Hear what our clients have to say about our virtual talent assessment tools</p>
              <div class="row">
                  <div class="col-md-3 d-flex flex-column justify-content-start align-items-center" data-aos="zoom-out"  data-aos-duration="1000">
                      <div  class="dashed-circle">
                          <img src="<?php echo BASE_PATH; ?>assets/images/customizable.svg" width="110" height="110" alt="">
                      </div>
                      <div class="text-center">
                          <h4 class="sub-heading text-purple ">Customizable Solutions</h4>
                          <p class="para mb-5">We design our solutions to suit your unique requirements.</p>
                      </div>
                  </div>
                  <div class="col-md-3 d-flex flex-column justify-content-start align-items-center" data-aos="zoom-out"  data-aos-duration="1000">
                      <div  class="dashed-circle">
                          <img src="<?php echo BASE_PATH; ?>assets/images/scalable.svg" width="110" height="110" alt="">
                      </div>
                      <div class="text-center">
                          <h4 class="sub-heading text-purple ">Scalable Solutions</h4>
                          <p class="para mb-5">We conduct 200,000+ proctored assessments in a day.</p>
                      </div>
                  </div>
                  <div class="col-md-3 d-flex flex-column justify-content-start align-items-center" data-aos="zoom-out"  data-aos-duration="1000">
                      <div  class="dashed-circle">
                          <img src="<?php echo BASE_PATH; ?>assets/images/support.svg" width="110" height="110" alt="">
                      </div>
                      <div class="text-center">
                          <h4 class="sub-heading text-purple ">24*7 Support</h4>
                          <p class="para mb-5">We have your back, always.</p>
                      </div>
                  </div>
                  <div class="col-md-3 d-flex flex-column justify-content-start align-items-center" data-aos="zoom-out"  data-aos-duration="1000">
                      <div  class="dashed-circle">
                          <img src="<?php echo BASE_PATH; ?>assets/images/ai-tech.svg" width="110" height="110" alt="">
                      </div>
                      <div class="text-center">
                          <h4 class="sub-heading text-purple ">Best-in-class AI-based Proctoring</h4>
                          <p class="para mb-5"> Leading AI-based remote proctoring technology.</p>
                      </div>
                  </div>
              </div>
          </div>
      </section>
      <?php include 'common/client-form.php';?>
    </main>
    <?php include 'common/footer.php';?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="<?php echo BASE_PATH; ?>assets/js/owl.carousel.min.js" type="text/javascript"></script>
    <script>
        $('#client_slider').owlCarousel({
          margin: 10,
          autoHeight: true,
          nav: false,
          navigation: true,
          loop: true,
          autoplay: true,
          slideBy: 1,
          dotsEach: true,
          dots: true,
          //   autoWidth:true,
          responsive: {
            360: {
              items: 1,
            },
            600: {
              items: 1,
            },
            1120: {
              items: 1,
            },
            1480: {
              items: 1,
            },
            1850: {
              items: 1,
            }
          }
        });
    </script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
      AOS.init();
    </script>
    <script src="<?php echo BASE_PATH; ?>assets/js/main.js"></script>
  </body>
</html>
