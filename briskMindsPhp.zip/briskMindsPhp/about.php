<?php include 'common/config.php';?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <?php include 'common/library.php';?>
    <title>About us</title>
  </head>
  <body class="about-page">
    <?php include 'common/header.php';?>
    <main class="background_vector">
      <section class="banner_inside">
        <div class="container h-100">
          <div class="row d-flex m-flex-column align-items-center h-100">
            <div class="col-md-6">
              <figure class="m-show hide">
                <img class="img-fluid"src="<?php echo BASE_PATH; ?>assets/images/about-us.webp" alt="about-us">
              </figure>
              <h2 class="heading mb-3">About Us</h2>
              <div class="yellow-line mb-5"></div>
              <p class="para mb-20">Pvt.Ltd. has been founded by alumni of IIT and NRIs. Mr. AshwaniKumar in July 2016 with rich experience in the field of education, assessment as well as technology. He has worked as a senior consultant with Samsung and currently a Technical Advisor for Facebook, California, USA.</p>
              <p class="para mb-20">Mr. Ankit Kumar is Managing Director of the company have vast experience in field of Skilling and Other Industries as he owns multiple companies comprises Manufacturing Units, consulting firms and many other wings directly linked to Government projects.</p>
              <p class="para mb-20">Brisk Mind has a comprehensive suite of assessment and learning products, solutions for educational institutions, training organizations and corporate, and has a dedicated team for occupational assessments which comprises of subject matter experts, content creator, Assessments Designer and Field Experts. All the assessors possess considerable hands on experience and domain knowledge.</p>
            </div>
            <div class="col-md-6">
              <figure class="d-flex justify-content-end">
                  <img class="img-fluid m-hide show" width="600" height ="auto" src="<?php echo BASE_PATH; ?>assets/images/about-us.webp" alt="about-us">
              </figure>
            </div>
          </div>
        </div>
      </section>
      <section class="section">
          <div class="container">
              <h2 class="heading mb-20 text-center">
                  WHAT WE DO?
              </h2>
              <div class="row d-flex justify-content-between align-items-center">
                  <div class="col-md-5" data-aos="zoom-out-left" data-aos-duration="1500">
                      <figure class="d-flex justify-content-start">
                          <img src="<?php echo BASE_PATH; ?>assets/images/target.webp" alt="" class="mb-5 img-fluid" >
                      </figure>
                  </div>
                  <div class="col-md-7 px-4" data-aos="zoom-out-right" data-aos-duration="1500">
                      <p class="para pos_r"> <span class="coloured_line line-1"></span> We are an Assessing Agency with a PAN India presence and are operational in the field of Skill Assessments under various Government, Semi-government and Industry Endorsed projects in 72 vocational trades. We have Assessments of aptitudes, abilities, skills, behaviours, competencies, knowledge, morale, attitude and work values. These are Multilingual Assessments making it easier for candidates across India to take part.</p>
                      <p class="para pos_r"> <span class="coloured_line line-2"></span> We are also working as a Recruitment Partner with a number of private companies. We hire the candidates for our partners and help them build the foundation for success through best talents across India.</p>
                      <p class="para pos_r"> <span class="coloured_line line-3"></span> We are also a Technical Consultant in various MSME Projects.</p>
                  </div>
              </div>
          </div>
      </section>
      <section class="section">
          <div class="container">
              <div class="row d-flex">
                  <div class="col-md-6"  data-aos="flip-left"  data-aos-duration="1000"> 
                      <div class="mv-box" >
                          <div class="mv-box-up">
                              <h2 class="heading m-0">Mission</h2>
                          </div>
                          <div class="p-3">
                              <p class="para m-0 text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam gravida eget justo et rutrum. Praesent augue leo, ultricies nonLorem ipsum dolor sit amet, consectetur adipiscing elit. Nam gravida eget justo et rutrum. Praesent augue leo, ultricies nonLorem ipsum dolor sit amet,</p>
                          </div>
                      </div>
                  </div>
                  <div class="col-md-6"  data-aos="flip-left"  data-aos-duration="1000"> 
                      <div class="mv-box">
                          <div class="mv-box-up">
                              <h2 class="heading m-0">Vision</h2>
                          </div>
                          <div class="p-3">
                              <p class="para m-0 text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam gravida eget justo et rutrum. Praesent augue leo, ultricies nonLorem ipsum dolor sit amet, consectetur adipiscing elit. Nam gravida eget justo et rutrum. Praesent augue leo, ultricies nonLorem ipsum dolor sit amet,</p>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </section>
      <section class="section">
          <div class="container">
              <h2 class="heading text-center">Team</h2>
              <p class="para text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam gravida eget justo et rutrum. Praesent augue leo, ultricies nonLorem ipsum dolor sit amet, consectetur </p>
              <div class="row d-flex justify-content-center align-items-center">
                  <div class="col-md-6" data-aos="zoom-out-left" data-aos-duration="1500">
                      <figure>
                          <img class="img-fluid" src="<?php echo BASE_PATH; ?>assets/images/about-team.webp" alt="">
                      </figure>
                  </div>
                  <div class="col-md-1"></div>
                  <div class="col-md-5" data-aos="zoom-out-right" data-aos-duration="1500">
                      <div class="row d-flex">
                          <div class="col col-sm-6 col-md-4">
                              <div class="team-box">    
                                  <figure>
                                      <img src="<?php echo BASE_PATH; ?>assets/images/team.webp" width="112" height="auto" alt="">
                                  </figure>
                                  <h4>Yogesh Kandari</h4>
                                  <p>Sr. Software Dev</p>
                              </div>
                          </div>
                          <div class="col col-sm-6 col-md-4">
                              <div class="team-box">    
                                  <figure>
                                      <img src="<?php echo BASE_PATH; ?>assets/images/team.webp" width="112" height="auto" alt="">
                                  </figure>
                                  <h4>Yogesh Kandari</h4>
                                  <p>Sr. Software Dev</p>
                              </div>
                          </div>
                          <div class="col col-sm-6 col-md-4">
                              <div class="team-box">    
                                  <figure>
                                      <img src="<?php echo BASE_PATH; ?>assets/images/team.webp" width="112" height="auto" alt="">
                                  </figure>
                                  <h4>Yogesh Kandari</h4>
                                  <p>Sr. Software Dev</p>
                              </div>
                          </div>
                          <div class="col col-sm-6 col-md-4">
                              <div class="team-box">    
                                  <figure>
                                      <img src="<?php echo BASE_PATH; ?>assets/images/team.webp" width="112" height="auto" alt="">
                                  </figure>
                                  <h4>Yogesh Kandari</h4>
                                  <p>Sr. Software Dev</p>
                              </div>
                          </div>
                          <div class="col col-sm-6 col-md-4">
                              <div class="team-box">    
                                  <figure>
                                      <img src="<?php echo BASE_PATH; ?>assets/images/team.webp" width="112" height="auto" alt="">
                                  </figure>
                                  <h4>Yogesh Kandari</h4>
                                  <p>Sr. Software Dev</p>
                              </div>
                          </div>
                          <div class="col col-sm-6 col-md-4">
                              <div class="team-box">    
                                  <figure>
                                      <img src="<?php echo BASE_PATH; ?>assets/images/team.webp" width="112" height="auto" alt="">
                                  </figure>
                                  <h4>Yogesh Kandari</h4>
                                  <p>Sr. Software Dev</p>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </section>
    </main>
    <?php include 'common/footer.php';?>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
      crossorigin="anonymous"
    ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
      AOS.init();
    </script>
    <script src="<?php echo BASE_PATH; ?>assets/js/main.js"></script>
  </body>
</html>
