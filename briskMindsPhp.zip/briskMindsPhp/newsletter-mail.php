<?php
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

    if (isset($_POST['submit'])) {
        
    require 'PHPMailer/src/Exception.php';
    require 'PHPMailer/src/PHPMailer.php';
    require 'PHPMailer/src/SMTP.php';

    $email = $_POST['email'];

    $msg_show = "<div><b>Your newsletter Email-id-</b> $email</div>";

    $subject = 'testing'; 

    $mail = new PHPMailer; 
    $mail->Host = 'smtp.gmail.com';             
    $mail->SMTPDebug = 2;
    $mail->SMTPAuth = true;                     // Enable SMTP authentication
    $mail->Username = 'yogeshkandari1405@gmail.com';          // SMTP username
    $mail->Password = 'hsegoygmail@12'; // SMTP password
    $mail->SMTPSecure = 'TLS';                  // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 587;
    $mail->setFrom('yogeshkandari1405@gmail.com', 'yogesh');
    $mail->addAddress('yogeshkandari1405@gmail.com');
    //$mail->addBCC('xyz@gmail.com');

    $mail->isHTML(true);  // Set email format to HTML
    $mail->Subject = $subject;
    $mail->Body    = $msg_show;
    
    echo 'mailer enter';

    if($mail->send()) {
        $output = '<div class="alertt-success">
                    <h5>Thankyou! for contacting us, We\'ll get back to you soon!</h5>
                </div>'; 
    } 
    else {
            $output = '<div class="alertt-danger">
                    <h5>Thankyou! for contacting us, We\'ll get back to you soon!</h5>';
        echo 'Mailer Error: ' . $mail->ErrorInfo;
    }
    }else{
    echo 'mailer is not working';
    }
  // header("Location:thank-you.php");

?>