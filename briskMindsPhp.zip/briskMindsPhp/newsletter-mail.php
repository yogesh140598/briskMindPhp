<?php

$email = $_POST['email'];


$to = $email;
$subject = "Test mail";
$txt = "email = ". $email;
// $txt2 = "organization = ". $organization . "\r\n myself = " . $myself;


$headers = "From: yogeshkandari14@gmail.com" . "\r\n" . "CC:somebody@exampe.com";
if($email!=NULL){
    // mail($to,$subject,$txt,$headers);
    ini_set($to,$headers);
}

echo $email;
?>