<?php

$name = $_POST['name'];
$mobile = $_POST['mobile'];
$email = $_POST['email'];
$option = $_POST['option'];
$message = $_POST['message'];
$myfile = $_POST['myfile'];
$to = $email;
$subject = "Test mail";
$txt = "Name = ". $name . "\r\n Email = " . $email . "\r\n Message = " . $message . "\r\n Mobile number = ". $mobile ;
// $txt2 = "organization = ". $organization . "\r\n myself = " . $myself;

$headers = "From: yogeshkandari14@gmail.com" . "\r\n" . "CC:somebody@exampe.com";
if($email!=NULL){
    // mail($to,$subject,$txt,$headers);
    ini_set($to,$headers);
}
echo $name;
echo $mobile;
echo $email;
echo $message;
echo $option;
echo $myfile;

//redirect
// header("Location:thankyou.php");
?>