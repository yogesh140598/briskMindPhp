<?php

  use PHPMailer\PHPMailer\PHPMailer;
  use PHPMailer\PHPMailer\Exception;
  $output = " "; 

  if (isset($_POST['submit'])) {
      
    require 'PHPMailer/src/Exception.php';
    require 'PHPMailer/src/PHPMailer.php';
    require 'PHPMailer/src/SMTP.php';

    $name = $_POST['name'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $option = $_POST['option'];
    $message = $_POST['message'];
    $myfile = $_POST['myfile'];
    $candidate = $_POST['candidate'];
    $employee = $_POST['employee'];


    $msg_show = "<div><b>User Name-</b> $name</div>";
    $msg_show .= "<div><b>User Email-</b> $email</div>";
    $msg_show .= "<div><b>User Number-</b> $mobile</div>";
    $msg_show .= "<div><b>Resume file-</b> $myfile</div>";
    $msg_show .= "<div><b>Want Solution For-</b> $option</div>";
    $msg_show .= "<div><b>User Message-</b> $message </div>";

    $subject = 'testing'; 

    $mail = new PHPMailer; 
    $mail->Host = 'smtp.gmail.com';             
    $mail->SMTPDebug = 2;
    $mail->SMTPAuth = true;                     // Enable SMTP authentication
    $mail->Username = 'yogeshkandari1405@gmail.com';          // SMTP username
    $mail->Password = 'hsegoygmail@12'; // SMTP password
    $mail->SMTPSecure = 'TLS';                  // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 587;
    $mail->setFrom('yogeshkandari1405@gmail.com', 'Yogesh');
    $mail->addAddress($email);
    $mail->addBCC('yogeshkandari1405@gmail.com');

    $mail->isHTML(true);  // Set email format to HTML
    $mail->Subject = $subject;
    $mail->Body    = $msg_show;
     
    // echo 'mailer enter';

    if($mail->send()) {
        // $output = '<div class="alertt-success">
        //           <h5>Thankyou! for contacting us, We\'ll get back to you soon!</h5>
        //         </div>'; 
    } 
    else {
        //     $output = '<div class="alertt-danger">
        //           <h5>Thankyou! for contacting us, We\'ll get back to you soon!</h5>';
        // echo 'Mailer Error: ' . $mail->ErrorInfo;
    }
  }
  header("Location:service/talent-acquisition");

?>