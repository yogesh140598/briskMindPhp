// $(document).ready(function () {
//     $('.nav-item .nav-link').click(function(e) {

//         $('.nav-item nav-link.active').removeClass('active');

//         var $parent = $(this).parent();
//         $parent.addClass('active');
//         // e.preventDefault();
//     });
// });
$(document).ready(function () {
    var url = window.location;
// Will only work if string in href matches with location
    $('li.nav-item a.nav-link[href="' + url + '"]').parent().addClass('active');

// Will also work for relative and absolute hrefs
    $('li.nav-item a.nav-link').filter(function () {
        return this.href == url;
    }).parent().addClass('active').parent().parent().addClass('active');
});