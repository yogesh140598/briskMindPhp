<?php

  use PHPMailer\PHPMailer\PHPMailer;
  use PHPMailer\PHPMailer\Exception;

  $output = " ";
  if (isset($_POST['submit'])) {
      
    require 'PHPMailer/src/Exception.php';
    require 'PHPMailer/src/PHPMailer.php';
    require 'PHPMailer/src/SMTP.php';

    $name = $_POST['name'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $company = $_POST['company'];
    $radio = $_POST['radio'];
    $message = $_POST['message'];

    $msg_show = "<div><b>User Name-</b> $name</div>";
    $msg_show .= "<div><b>User Email-</b> $email</div>";
    $msg_show .= "<div><b>User Number-</b> $mobile</div>";
    $msg_show .= "<div><b>User Number-</b> $company</div>";
    $msg_show .= "<div><b>Want Solution For-</b> $radio</div>";
    $msg_show .= "<div><b>User Message-</b> $message </div>";

    $subject = 'testing'; 

    $mail = new PHPMailer; 
    $mail->Host = 'smtp.gmail.com';             // Specify main and backup SMTP servers
    $mail->SMTPDebug = 2;
    $mail->SMTPAuth = true;                     // Enable SMTP authentication
    $mail->Username = 'yogeshkandari1405@gmail.com';          // SMTP username
    $mail->Password = 'hsegoygmail@12'; // SMTP password
    $mail->SMTPSecure = 'TLS';                  // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 587;
    $mail->setFrom('yogeshkandari1405@gmail.com', 'yogesh');
    $mail->addAddress('yogeshkandari1405@gmail.com');
    //$mail->addBCC('xyz@gmail.com');

    $mail->isHTML(true);  // Set email format to HTML
    $mail->Subject = $subject;
    $mail->Body    = $msg_show;
     
    echo 'hlooooooooo';

    if($mail->send()) {
        $output = '<div class="alertt-success">
                  <h5>Thankyou! for contacting us, We\'ll get back to you soon!</h5>
                </div>';
        // echo 'sent';
        //return true;    
    } 
    else {
            $output = '<div class="alertt-danger">
                  <h5>Thankyou! for contacting us, We\'ll get back to you soon!</h5>';
    //  echo 'Message could not be sent.';
        echo 'Mailer Error: ' . $mail->ErrorInfo;
    }
  }else{
    echo 'hlooooooooo';
  }
    $txt = "Name = ". $name . "\r\n Email = " . $email . "\r\n Message = " . $message . "\r\n Mobile number = ". $mobile ;
    $txt2 = "\r\n organization = ". $radio ;

    echo $txt;
    echo $txt2;
    // $to = $email;
    // $subject = "Test mail";
    // $txt = "Name = ". $name . "\r\n Email = " . $email . "\r\n Message = " . $message . "\r\n Mobile number = ". $mobile ;
// $txt2 = "organization = ". $organization . "\r\n myself = " . $myself;


    // $headers = "From: yogeshkandari14@gmail.com" . "\r\n" . "CC:somebody@exampe.com";
    // if($email!=NULL){
    //     // mail($to,$subject,$txt,$headers);
    //     ini_set($to,$headers);
    // }
    // if (isset($_POST['submit'])) {
    //     if(isset($_POST['radio']))
    //     {
    //     echo "You have selected :".$_POST['radio'];  //  Displaying Selected Value
    //     }
    // }

    // echo $name;
    // echo $mobile;
    // echo $email;
    // echo $company;
    // echo $message;
    // echo $_POST['radio'];
// echo $organization;
// echo $myself;

// echo $txt;
// echo $txt2;

//redirect
// header("Location:thankyou.php");
?>