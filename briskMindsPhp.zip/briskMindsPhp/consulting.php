<?php include 'common/config.php';?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <?php include 'common/library.php';?>
    <title>Consulting</title>
  </head>
  <body class="consulting line_active">
    <?php include 'common/header.php';?>
    <main class="background_vector">
      <section class="banner_inside">
          <div class="container h-100">
            <div class="row d-flex m-flex-column align-items-center h-100">
              <div class="col-md-6">
                <figure class="m-show hide">
                  <img class="img-fluid" src="<?php echo BASE_PATH; ?>assets/images/consultancy.webp" width="520" height="auto" alt="Global Leader">
                </figure>
                <h2 class="heading mb-5">Briskmind: Consulting</h2>
                <!-- <h2 class="heading mb-5">Consulting</h2> -->
                <p class="para mb-3">Brisk Mind Private Limited will act as the Technical Agency. TA needs to help the IA in not only preparation of DSR and subsequent DPR but also in identification of competent CDA, implementation of SI and HI as per the plan. They are also expected to help IA in framing proper O&M framework for CFC maintenance.</p>
                <div class="yellow-line mb-5"></div>
                <button class="btn-custom">Get Started</button>
              </div>
              <div class="col-md-6">
                <figure class="d-flex justify-content-end ">
                    <img class="m-hide show img-fluid" src="<?php echo BASE_PATH; ?>assets/images/consultancy.webp" width="600" height="auto" alt="Global Leader">
                </figure>
              </div>
            </div>
          </div>
      </section>
      <section class="section">
          <div class="container">
              <div class="row d-flex justify-content-between">
                  <div class="col-md-10 mx-auto text-center">
                      <h2 class="heading text-center">Our Offerings</h2>
                      <p class="para text-center mb-50">Conduct Online Exams | Conduct Virtual Assessments | Hire and Develop Talent</p>
                  </div>
                  <div class="col-md-4" data-aos="flip-right"  data-aos-duration="1000" >
                      <div class="card_assesment">
                          <div>
                              <figure>
                                  <img class="img-fluid w-100" src="<?php echo BASE_PATH; ?>assets/images/government-sector.webp" alt="Government Sector">
                              </figure>
                          </div>
                          <div class="p-5">
                              <h2 class="sub-heding">Government Sector</h2>
                              <p class="para">Briskmind is a global management consulting firm and the world’s leading advisor on business strategy. We partner with clients from the private, public, and not-for-profit sectors in all regions to identify their highest-value opportunities, address their most critical challenges, and transform their enterprises.</p>
                              <button class="btn-custom btn-custom-2-light">Learn More</button>
                          </div>
                      </div>
                  </div>
                  <div class="col-md-4" data-aos="flip-left"  data-aos-duration="1000" >
                      <div class="card_assesment">
                          <div>
                              <figure>
                                  <img class="img-fluid w-100" src="<?php echo BASE_PATH; ?>assets/images/private-sector.webp" alt="Private Sector">
                              </figure>
                          </div>
                          <div class="p-5">
                              <h2 class="sub-heding">Private Sector</h2>
                              <p class="para">Briskmind is a global management consulting firm and the world’s leading advisor on business strategy. We partner with clients from the private, public, and not-for-profit sectors in all regions to identify their highest-value opportunities, address their most critical challenges, and transform their enterprises.</p>
                              <button class="btn-custom btn-custom-2-light">Learn More</button>
                          </div>
                      </div>
                  </div>
                  <div class="col-md-4" data-aos="flip-right"  data-aos-duration="1000" >
                      <div class="card_assesment">
                          <div>
                              <figure>
                                  <img class="img-fluid w-100" src="<?php echo BASE_PATH; ?>assets/images/msme.webp" alt="MSME Schemes">
                              </figure>
                          </div>
                          <div class="p-5">
                              <h2 class="sub-heding">MSME Schemes</h2>
                              <p class="para">Briskmind is a global management consulting firm and the world’s leading advisor on business strategy. We partner with clients from the private, public, and not-for-profit sectors in all regions to identify their highest-value opportunities, address their most critical challenges, and transform their enterprises.</p>
                              <button class="btn-custom btn-custom-2-light">Learn More</button>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
        </section>
        <section class="section talent_acq_bg">
          <div class="container">
            <div class="row d-flex flex-column">
              <div>
                <h2 class="heading text-center text-light mb-50">Make Wise Decisions Using Our Talent</br> Acquisition Solutions</h2>
              </div>
            </div>
            <div class="row d-flex">
              <div class="col-md-4 d-flex justify-content-center align-items-center flex-column">
                <div class="num heading text-light">
                  <span class="counter-value">943</span>
                </div>
                <p class="para text-light mb-20 text-center">Insights: thoughts, ideas and views of consultancies</p>
              </div>
              <div class="col-md-4 d-flex justify-content-center align-items-center flex-column">
                <div class="num heading text-light">
                  <span class="counter-value">209</span>
                </div>
                <p class="para text-light mb-20 text-center">Projects: engagements delivered by leading consulting firms</p>
              </div>
              <div class="col-md-4 d-flex justify-content-center align-items-center flex-column">
                <div class="num heading text-light">
                  <span class="counter-value">71</span>
                </div>
                <p class="para text-light mb-20 text-center">Research: trends and reports that provide detailed insights</p>
              </div>
            </div>
          </div>
        </section>
      <section class="section">
        <div class="container">
          <div class="row">
            <div class="col-md-3 mb-5" data-aos="flip-left"  data-aos-duration="1000">
              <div class="consult_card">
                <div class="consult_card_img">
                  <img src="<?php echo BASE_PATH; ?>assets/images/strategy.png" class="img-fluid" width="400" alt="">
                </div>
                <div class="consult_card_content">
                  <h3 class="sub-heading mb-3">Strategy Consulting</h3>
                  <p class="para">Strategy consultants advise C-suit and executives on their most pressing boardroom challenges.</p>
                </div>
              </div>
            </div>
            <div class="col-md-3 mb-5" data-aos="flip-right"  data-aos-duration="1000">
              <div class="consult_card">
                <div class="consult_card_img">
                  <img src="<?php echo BASE_PATH; ?>assets/images/management.png" class="img-fluid" width="400" alt="">
                </div>
                <div class="consult_card_content">
                  <h3 class="sub-heading mb-3">Management Consulting</h3>
                  <p class="para">Management consultants support their clients with all asppects of management and operations.</p>
                </div>
              </div>
            </div>
            <div class="col-md-3 mb-5" data-aos="flip-left"  data-aos-duration="1000">
              <div class="consult_card">
                <div class="consult_card_img">
                  <img src="<?php echo BASE_PATH; ?>assets/images/digital.png" class="img-fluid" width="400" alt="">
                </div>
                <div class="consult_card_content">
                  <h3 class="sub-heading mb-3">Digital Consulting</h3>
                  <p class="para">Digital consultants specialise in digital strategies, automation and technology implements. </p>
                </div>
              </div>
            </div>
            <div class="col-md-3 mb-5" data-aos="flip-right"  data-aos-duration="1000">
              <div class="consult_card">
                <div class="consult_card_img">
                  <img src="<?php echo BASE_PATH; ?>assets/images/hr-con.png" class="img-fluid" width="400" alt="">
                </div>
                <div class="consult_card_content">
                  <h3 class="sub-heading mb-3">HR Consulting</h3>
                  <p class="para">HR consultants support their clients with all aspects of human capiital and the delivery of HR services. </p>
                </div>
              </div>
            </div>
            <h3 class="sub-heading mb-5">Popular industries for consulting services</h3>
            <div class="col-md-3 mb-5" data-aos="flip-left"  data-aos-duration="1000">
              <div class="consult_card">
                <div class="consult_card_img">
                  <img src="<?php echo BASE_PATH; ?>assets/images/financial-services.png" class="img-fluid" width="400" alt="">
                </div>
                <div class="consult_card_content">
                  <h3 class="sub-heading mb-3">Financial Services</h3>
                  <p class="para">Explore consulting services delivered to banks, insurers, asset manager, pension funds, and more.</p>
                </div>
              </div>
            </div>
            <div class="col-md-3 mb-5" data-aos="flip-right"  data-aos-duration="1000">
              <div class="consult_card">
                <div class="consult_card_img">
                  <img src="<?php echo BASE_PATH; ?>assets/images/public-sector.png" class="img-fluid" width="400" alt="">
                </div>
                <div class="consult_card_content">
                  <h3 class="sub-heading mb-3">Public Sector</h3>
                  <p class="para">The public sector spans central and local government sectors, as well as broader public services.</p>
                </div>
              </div>
            </div>
            <div class="col-md-3 mb-5" data-aos="flip-left"  data-aos-duration="1000">
              <div class="consult_card">
                <div class="consult_card_img">
                  <img src="<?php echo BASE_PATH; ?>assets/images/energy-sector.png" class="img-fluid" width="400" alt="">
                </div>
                <div class="consult_card_content">
                  <h3 class="sub-heading mb-3">Energy</h3>
                  <p class="para">Consulting services  for the full energy lifecycle, from generation and distribution to energy retail.</p>
                </div>
              </div>
            </div>
            <div class="col-md-3 mb-5" data-aos="flip-right"  data-aos-duration="1000">
              <div class="consult_card">
                <div class="consult_card_img">
                  <img src="<?php echo BASE_PATH; ?>assets/images/healthcare-sector.png" class="img-fluid" width="400" alt="">
                </div>
                <div class="consult_card_content">
                  <h3 class="sub-heading mb-3">Healthcare</h3>
                  <p class="para">An overview of consulting services delivered to hospitals, care, cure and other health institutes.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <?php include 'common/client-form.php';?>
    </main>
    <?php include 'common/footer.php';?>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
      crossorigin="anonymous"
    ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
      AOS.init();
    </script>
    <script src="<?php echo BASE_PATH; ?>assets/js/main.js"></script>
  </body>
</html>
