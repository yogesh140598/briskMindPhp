<?php include 'common/config.php';?>
<!DOCTYPE html>
<html lang="en">
  <head>
  <link rel="stylesheet" type="text/css" href="<?php echo BASE_PATH; ?>assets/css/owl.carousel.min.css" />
    <?php include 'common/library.php';?>
    <title>Talent Acquisition</title>
  </head>
  <body class="talent-acquisition">
    <?php include 'common/header.php';?>
    <main class="background_vector">
      <section class="banner_inside">
        <div class="container h-100">
          <div class="row d-flex m-flex-column align-items-center h-100">
            <div class="col-md-6">
              <figure class="m-show hide">
                <img class="img-fluid" src="<?php echo BASE_PATH; ?>assets/images/talent_aqua.webp" width="520" height="auto" alt="Global Leader">
              </figure>
              <h2 class="heading">Briskmind:</h2>
              <h2 class="heading mb-5">Talent Acquisition</h2>
              <p class="para mb-3">Hire diverse talent to build a high-performing workforce using our proven acquisition methods</p>
              <div class="yellow-line mb-5"></div>
              <button class="btn-custom">Get Started</button>
            </div>
            <div class="col-md-6">
              <figure class="d-flex justify-content-end ">
                  <img class="m-hide show img-fluid" src="<?php echo BASE_PATH; ?>assets/images/talent_aqua.webp" width="600" height="auto" alt="Global Leader">
              </figure>
            </div>
          </div>
        </div>
      </section>
      <section class="section">
        <div class="container">
          <h2 class="heading text-center">Our Offerings</h2>
          <p class="para text-center mb-50">Whatever the role you are hiring, Briskmind has the right solution to help you make wise hiring decisions.</p>
          <div class="row">
            
            <div class="col col-sm-6 col-md-6 mb-5" data-aos="flip-left"  data-aos-duration="1000">
              <div class="offering_card">
                <div class="">
                  <img class="w-100" src="<?php echo BASE_PATH; ?>assets/images/bulk-hiring.webp" alt="bulk hiring">
                </div>
                <div class="offering_card_content">
                  <div>
                    <h3 class="sub-heading">Bulk Hiring</h3>
                    <p class="para">Secure top performers at scale across high-volume roles like support and retail staff</p>
                  </div>
                  <div>
                    <button class="btn-custom btn-custom-2-light">
                    Learn More
                  </button>
                  </div>
                </div>
              </div>
            </div>
            <div class="col col-sm-6 col-md-6 mb-5" data-aos="flip-right"  data-aos-duration="1000">
              <div class="offering_card">
                <div class="">
                  <img class="w-100" src="<?php echo BASE_PATH; ?>assets/images/management-hiring.webp" alt="Management Hiring">
                </div>
                <div class="offering_card_content">
                  <div>
                    <h3 class="sub-heading">Management Hiring</h3>
                    <p class="para">Streamline managerial selection and boost effectiveness from the very beginnings using our insights.</p>
                  </div>
                  <div>
                    <button class="btn-custom btn-custom-2-light">
                    Learn More
                  </button>
                  </div>
                </div>
              </div>
            </div>
            <div class="col col-sm-6 col-md-6 mb-5" data-aos="flip-left"  data-aos-duration="1000">
              <div class="offering_card">
                <div class="">
                  <img class="w-100" src="<?php echo BASE_PATH; ?>assets/images/payroll-management.webp" alt="payroll management">
                </div>
                <div class="offering_card_content">
                  <div>
                    <h3 class="sub-heading">Payroll Management</h3>
                    <p class="para">Brisk Mind offers HR and payroll services that can help improve efficiency of traditionally complex & time consuming tasks</p>
                  </div>
                  <div>
                    <button class="btn-custom btn-custom-2-light">
                    Learn More
                  </button>
                  </div>
                </div>
              </div>
            </div>
            <div class="col col-sm-6 col-md-6 mb-5" data-aos="flip-right"  data-aos-duration="1000">
              <div class="offering_card">
                <div class="">
                  <img class="w-100" src="<?php echo BASE_PATH; ?>assets/images/compliance-management.webp" alt="compliance management">
                </div>
                <div class="offering_card_content">
                  <div>
                    <h3 class="sub-heading">Compliance Management</h3>
                    <p class="para">Adheres to all compliances during the hiring journey relying on popular assessment tools for assessment and verification.</p>
                  </div>
                  <div>
                    <button class="btn-custom btn-custom-2-light">
                    Learn More
                  </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section class="section">
        <div class="container">
          <div class="row">
            <h2 class="heading text-center">
              Transform The Hiring Process
            </h2>
            <p class="para text-center mb-70">
              With more than a year of extensive research, Briskmind brings you six shifts that will transform the candidate experience, plus an actionable roadmap to help you turn every applicant into a brand advocate.
            </p>
            <div class="col-md-6" data-aos="zoom-in-right"  data-aos-duration="1000">
              <div class="form_card mx-auto double-quote">
                <div class="form_logo light-circle-border mb-5">
                  <img src="<?php echo BASE_PATH; ?>assets/images/ishan-logo.webp" width="87" height="auto" alt="">
                </div>
                <p class="para text-center mb-5">I think Briskmind Services gave me an opportunity to look inside myself. I came for the first assessment for a specific skill in my mind but I realised that there’s so much I haven’t addressed yet and probably…</p>
                <h3 class="sub-heading mb-5">Ishan Netsol Pvt Ltd</h3>
              </div>
            </div>
            <div class="col-md-1"></div>
            <div class="col-md-5" data-aos="zoom-in-left"  data-aos-duration="1000">
              <div class="row">
                <div class="col col-sm-6 col-md-3">
                  <div class="hiring_logo">
                    <img class="img-fluid light-circle-border" src="<?php echo BASE_PATH; ?>assets/images/ishan-logo.webp" alt="">
                    <p class="para">Ishan Netsol Pvt Ltd</p>
                  </div>
                </div>
                <div class="col col-sm-6 col-md-3">
                  <div class="hiring_logo">
                    <img class="img-fluid light-circle-border" src="<?php echo BASE_PATH; ?>assets/images/ishan-logo.webp" alt="">
                    <p class="para">Ishan Netsol Pvt Ltd</p>
                  </div>
                </div>
                <div class="col col-sm-6 col-md-3">
                  <div class="hiring_logo">
                    <img class="img-fluid light-circle-border" src="<?php echo BASE_PATH; ?>assets/images/ishan-logo.webp" alt="">
                    <p class="para">Ishan Netsol Pvt Ltd</p>
                  </div>
                </div>
                <div class="col col-sm-6 col-md-3">
                  <div class="hiring_logo">
                    <img class="img-fluid light-circle-border" src="<?php echo BASE_PATH; ?>assets/images/ishan-logo.webp" alt="">
                    <p class="para">Ishan Netsol Pvt Ltd</p>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col col-sm-6 col-md-3">
                  <div class="hiring_logo">
                    <img class="img-fluid light-circle-border" src="<?php echo BASE_PATH; ?>assets/images/ishan-logo.webp" alt="">
                    <p class="para">Ishan Netsol Pvt Ltd</p>
                  </div>
                </div>
                <div class="col col-sm-6 col-md-3">
                  <div class="hiring_logo">
                    <img class="img-fluid light-circle-border" src="<?php echo BASE_PATH; ?>assets/images/ishan-logo.webp" alt="">
                    <p class="para">Ishan Netsol Pvt Ltd</p>
                  </div>
                </div>
                <div class="col col-sm-6 col-md-3">
                  <div class="hiring_logo">
                    <img class="img-fluid light-circle-border" src="<?php echo BASE_PATH; ?>assets/images/ishan-logo.webp" alt="">
                    <p class="para">Ishan Netsol Pvt Ltd</p>
                  </div>
                </div>
                <div class="col col-sm-6 col-md-3">
                  <div class="hiring_logo">
                    <img class="img-fluid light-circle-border" src="<?php echo BASE_PATH; ?>assets/images/ishan-logo.webp" alt="">
                    <p class="para">Ishan Netsol Pvt Ltd</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section class="section talent_acq_bg">
        <div class="container">
          <div class="row d-flex flex-column">
            <div>
              <h2 class="heading text-center text-light mb-50">Make Wise Decisions Using Our Talent</br> Acquisition Solutions</h2>
            </div>
          </div>
          <div class="row d-flex">
            <div class="col-md-4 d-flex justify-content-center align-items-center flex-column">
              <div class="num heading text-light">30%</div>
              <p class="para text-light mb-20 text-center">female applicant pool available for hiring at brisk mind</p>
            </div>
            <div class="col-md-4 d-flex justify-content-center align-items-center flex-column">
              <div class="num heading text-light">88%</div>
              <p class="para text-light mb-20 text-center">of candidates naming Briskmind’s education client their #1 choice after taking our branded assessments.</p>
            </div>
            <div class="col-md-4 d-flex justify-content-center align-items-center flex-column">
              <div class="num heading text-light">50%</div>
              <p class="para text-light mb-20 text-center">Reduced time-to-hire for a global technology giant utilizing Briskmind’s AI-powered virtual hiring tools.</p>
            </div>
          </div>
        </div>
      </section>
      <section class="section">
        <div class="container">
          <div class="row dashed-line">
            <div class="col-md-4 mb-20" >
              <h2 class="heading">I am a Candidate</h2>
              <p class="para mb-5">Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur,</p>
              <button class="btn-custom" data-bs-toggle="modal" data-bs-target="#candiatePopup">Get Started</button>
              <div class="modal fade" id="candiatePopup" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered ">
                  <div class="modal-content">
                    <div class="row">
                      <div class="col-md-4 bg-blue p-5 m-hide show">
                        <h2 class="heading">Contact Info</h2>
                        <div class="content">
                          <div class="form-content">
                              <div>
                                <p class="form-label"><span class="form-icon"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person" viewBox="0 0 16 16"> <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z"/> </svg></span>
                                Name</p>
                                <p class="label-con">Yogesh Kandari</p>
                              </div>
                              <div>
                                <p class="form-label"><span class="form-icon"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-envelope-fill" viewBox="0 0 16 16"> <path d="M.05 3.555A2 2 0 0 1 2 2h12a2 2 0 0 1 1.95 1.555L8 8.414.05 3.555ZM0 4.697v7.104l5.803-3.558L0 4.697ZM6.761 8.83l-6.57 4.027A2 2 0 0 0 2 14h12a2 2 0 0 0 1.808-1.144l-6.57-4.027L8 9.586l-1.239-.757Zm3.436-.586L16 11.801V4.697l-5.803 3.546Z"/> </svg></span> Email</p>
                                <p class="label-con">operations@briskmind.in</p>
                              </div>
                              <div>
                                <p class="form-label"><span class="form-icon"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-telephone-fill" viewBox="0 0 16 16"> <path fill-rule="evenodd" d="M1.885.511a1.745 1.745 0 0 1 2.61.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.678.678 0 0 0 .178.643l2.457 2.457a.678.678 0 0 0 .644.178l2.189-.547a1.745 1.745 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.634 18.634 0 0 1-7.01-4.42 18.634 18.634 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877L1.885.511z"/> </svg></span> phone</p>
                                <p class="label-con">+91 98711 XXX11</p>
                              </div>
                              <div>
                                <p class="form-label"><span class="form-icon"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-geo-alt-fill" viewBox="0 0 16 16"> <path d="M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10zm0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6z"/> </svg></span> Address</p>
                                <p class="label-con">Plot No. 17 & 18, Anand Industrial Estate, Mohan Nagar, Ghaziabad, Uttar Pradesh 201007</p>
                              </div>
                            </div>
                            <div class="social-icon">
                              <ul class="d-flex ps-0">
                                <li class="px-2"><a href="#"><img src="<?php echo BASE_PATH; ?>assets/images/Facebook_social.png" alt=""></a></li>
                                <li class="px-2"><a href="#"><img src="<?php echo BASE_PATH; ?>assets/images/insta_social.png" alt=""></a></li>
                                <li class="px-2"><a href="#"><img src="<?php echo BASE_PATH; ?>assets/images/twitter_social.png" alt=""></a></li>
                                <li class="px-2"><a href="#"><img src="<?php echo BASE_PATH; ?>assets/images/twitter_social.png" alt=""></a></li>
                              </ul>
                            </div>
                          </div>
                      </div>
                      <div class="col-md-8 p-5">
                        <form action="../job-mail.php" method="post" class="row">
                          <h3 class="sub-heading mb-5">Apply for a Job</h3>
                          <div class="col-md-12 px-3">
                            <input required name="name" type="text" class="form-control" placeholder="Name" aria-label="Name">
                          </div>
                          <div class="col-md-6 px-3">
                              <input required name="email" type="text" class="form-control" placeholder="Official Email" aria-label="Official Email">
                          </div>
                          <div class="col-md-6 px-3">
                              <input required name="mobile" type="text" class="form-control" placeholder="Phone" aria-label="Phone">
                          </div>
                          <div class="col-md-12 px-3">
                              <select name="option" class="form-select form-control" placeholder="Post Applying for" aria-label="Default select example">
                                  <option value="1">One</option>
                                  <option value="2">Two</option>
                                  <option value="3">Three</option>
                                </select>
                          </div>
                          <div class="col-md-12 px-3 upload_file ">
                            <span class="upload_icon"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-upload" viewBox="0 0 16 16"> <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"/> <path d="M7.646 1.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8.5 2.707V11.5a.5.5 0 0 1-1 0V2.707L5.354 4.854a.5.5 0 1 1-.708-.708l3-3z"/> </svg></span>
                            <input type="text"  class="form-control" placeholder="Please Upload PNG, JPEG, PDF only (File Size : Max 5 MB)">
                            <input required type="file" id="myfile" name="myfile" class="form-control" placeholder="Company" aria-label="Company">
                          </div>
                          <div class="col-md-12">
                            <textarea required name="message" class="form-control" id="comments" placeholder="Comments" rows="3"></textarea>
                          </div>
                          <div class="d-flex justify-content-center">
                            <button type="submit" class="btn-custom">Submit</button>
                          </div>
                        </form>
                        <button type="button" class="close" data-bs-dismiss="modal">
                          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
                            <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                            <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
                          </svg>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-1"></div>
            <div class="col-md-7">
              <div class="row">
                <div class="col col-sm-6 col-md-3 mb-20" data-aos="flip-left"  data-aos-duration="1000">
                  <div class="job-post box-shadow-blue">
                    <div class="job-logo">
                      <img src="<?php echo BASE_PATH; ?>assets/images/candidate.svg" alt="">
                    </div>
                    <div>
                      <h3 class="sub-heading text-dark-grey font-600">Candidate</h3>
                    </div>
                  </div>
                </div>
                <div class="col col-sm-6 col-md-3 mb-20" data-aos="flip-right"  data-aos-duration="1000">
                  <div class="job-post box-shadow-blue">
                    <div class="job-logo">
                      <img src="<?php echo BASE_PATH; ?>assets/images/brisk-job.png" alt="">
                    </div>
                    <div>
                      <h3 class="sub-heading">Get Assessed by <span class="text-bright-blue font-600">Briskmind </span>Test</h3>
                    </div>
                  </div>
                </div>
                <div class="col col-sm-6 col-md-3 mb-20" data-aos="flip-left"  data-aos-duration="1000">
                  <div class="job-post box-shadow-blue">
                    <div class="job-logo">
                      <img src="<?php echo BASE_PATH; ?>assets/images/job-list.svg" alt="">
                    </div>
                    <div>
                      <h3 class="sub-heading">Apply from <span class="text-dark-grey font-600">List of jobs</span></h3>
                    </div>
                  </div>
                </div>
                <div class="col col-sm-6 col-md-3 mb-20" data-aos="flip-right"  data-aos-duration="1000">
                  <div class="job-post box-shadow-blue">
                    <div class="job-logo">
                      <img src="<?php echo BASE_PATH; ?>assets/images/get-hired.svg" alt="">
                    </div>
                    <div>
                      <h3 class="sub-heading">Get <span class="text-dark-grey font-600">Hired</span></h3>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-7">
              <div class="row">
                <div class="col col-sm-6 col-md-3 mb-20" data-aos="flip-left"  data-aos-duration="1000">
                  <div class="job-post box-shadow-purple">
                    <div class="job-logo">
                      <img src="<?php echo BASE_PATH; ?>assets/images/companies.svg" alt="">
                    </div>
                    <div>
                      <h3 class="sub-heading text-dark-grey font-600">Companies</h3>
                    </div>
                  </div>
                </div>
                <div class="col col-sm-6 col-md-3 mb-20" data-aos="flip-right"  data-aos-duration="1000">
                  <div class="job-post box-shadow-purple">
                    <div class="job-logo">
                      <img src="<?php echo BASE_PATH; ?>assets/images/post-job.svg" alt="">
                    </div>
                    <div>
                      <h3 class="sub-heading">Post<span class="text-dark-grey font-600"> Job</span></h3>
                    </div>
                  </div>
                </div>
                <div class="col col-sm-6 col-md-3 mb-20" data-aos="flip-left"  data-aos-duration="1000">
                  <div class="job-post box-shadow-purple">
                    <div class="job-logo">
                      <img src="<?php echo BASE_PATH; ?>assets/images/brisk-job.png" alt="">
                    </div>
                    <div>
                      <h3 class="sub-heading">View Assessed <span class="text-dark-grey font-600">Candidates</span></h3>
                    </div>
                  </div>
                </div>
                <div class="col col-sm-6 col-md-3 mb-20" data-aos="flip-right"  data-aos-duration="1000">
                  <div class="job-post box-shadow-purple">
                    <div class="job-logo">
                      <img src="<?php echo BASE_PATH; ?>assets/images/emp-job.svg" alt="">
                    </div>
                    <div>
                      <h3 class="sub-heading">Get the right <span class="text-dark-grey font-600">Employee</span></h3>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col md-1"></div>
            <div class="col-md-4">
              <h2 class="heading">I am an Employer</h2>
              <p class="para mb-5">Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur,</p>
              <button class="btn-custom btn-custom-2" data-bs-toggle="modal" data-bs-target="#employeePopup">Get Started</button>
              <div class="modal fade" id="employeePopup" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered ">
                  <div class="modal-content">
                    <div class="row">
                      <div class="col-md-4 bg-purple p-5 m-hide show">
                        <h2 class="heading">Contact Info</h2>
                        <div class="content">
                          <div class="form-content">
                            <div>
                              <p class="form-label"><span class="form-icon"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person" viewBox="0 0 16 16"> <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z"/> </svg></span>
                              Name</p>
                              <p class="label-con">Yogesh Kandari</p>
                            </div>
                            <div>
                              <p class="form-label"><span class="form-icon"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-envelope-fill" viewBox="0 0 16 16"> <path d="M.05 3.555A2 2 0 0 1 2 2h12a2 2 0 0 1 1.95 1.555L8 8.414.05 3.555ZM0 4.697v7.104l5.803-3.558L0 4.697ZM6.761 8.83l-6.57 4.027A2 2 0 0 0 2 14h12a2 2 0 0 0 1.808-1.144l-6.57-4.027L8 9.586l-1.239-.757Zm3.436-.586L16 11.801V4.697l-5.803 3.546Z"/> </svg></span> Email</p>
                              <p class="label-con">operations@briskmind.in</p>
                            </div>
                            <div>
                              <p class="form-label"><span class="form-icon"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-telephone-fill" viewBox="0 0 16 16"> <path fill-rule="evenodd" d="M1.885.511a1.745 1.745 0 0 1 2.61.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.678.678 0 0 0 .178.643l2.457 2.457a.678.678 0 0 0 .644.178l2.189-.547a1.745 1.745 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.634 18.634 0 0 1-7.01-4.42 18.634 18.634 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877L1.885.511z"/> </svg></span> phone</p>
                              <p class="label-con">+91 98711 XXX11</p>
                            </div>
                            <div>
                              <p class="form-label"><span class="form-icon"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-geo-alt-fill" viewBox="0 0 16 16"> <path d="M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10zm0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6z"/> </svg></span> Address</p>
                              <p class="label-con">Plot No. 17 & 18, Anand Industrial Estate, Mohan Nagar, Ghaziabad, Uttar Pradesh 201007</p>
                            </div>
                          </div>
                          <div class="social-icon">
                            <ul class="d-flex ps-0">
                              <li class="px-2"><a href="#"><img src="<?php echo BASE_PATH; ?>assets/images/Facebook_social.png" alt=""></a></li>
                              <li class="px-2"><a href="#"><img src="<?php echo BASE_PATH; ?>assets/images/insta_social.png" alt=""></a></li>
                              <li class="px-2"><a href="#"><img src="<?php echo BASE_PATH; ?>assets/images/twitter_social.png" alt=""></a></li>
                              <li class="px-2"><a href="#"><img src="<?php echo BASE_PATH; ?>assets/images/twitter_social.png" alt=""></a></li>
                            </ul>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-8 p-5">
                        <form action="../employee-mail.php" method="post" class="row">
                          <h3 class="sub-heading mb-5">Post a JOB</h3>
                          <div class="col-md-12 px-3">
                            <input required name="name" type="text" class="form-control" placeholder="Name" aria-label="Name">
                          </div>
                          <div class="col-md-6 px-3">
                              <input required name="email" type="text" class="form-control" placeholder="Official Email" aria-label="Official Email">
                          </div>
                          <div class="col-md-6 px-3">
                              <input required name="mobile" type="text" class="form-control" placeholder="Phone" aria-label="Phone">
                          </div>
                          <div class="col-md-12 px-3">
                              <select name="option" class="form-select form-control" placeholder="Position Looking for" aria-label="Default select example">
                                  <option value="1">One</option>
                                  <option value="2">Two</option>
                                  <option value="3">Three</option>
                                </select>
                          </div>
                          <div class="col-md-12 px-3 upload_file ">
                            <span class="upload_icon"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-upload" viewBox="0 0 16 16"> <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"/> <path d="M7.646 1.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8.5 2.707V11.5a.5.5 0 0 1-1 0V2.707L5.354 4.854a.5.5 0 1 1-.708-.708l3-3z"/> </svg></span>
                            <input type="text"  class="form-control" placeholder="Please Upload PNG, JPEG, PDF only (File Size : Max 5 MB)">
                            <input required type="file" id="myfile" name="myfile" class="form-control" placeholder="Company" aria-label="Company">
                          </div>
                          <div class="col-md-12">
                            <textarea required name="message" class="form-control" id="comments" placeholder="Comments" rows="3"></textarea>
                          </div>
                          <div class="d-flex justify-content-center">
                            <button type="submit" class="btn-custom">Submit</button>
                          </div>
                        </form>
                        <button type="button" class="close" data-bs-dismiss="modal">
                          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
                            <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                            <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
                          </svg>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section class="section">
        <div class="container">
          <div class="row">
            <h2 class="heading text-center">Over 600 Clients Globally Trust Us </br>With Their Talent Assessment</h2>
            <p class="para text-center mb-50">Hear what our clients have to say about our virtual talent assessment tools</p>
          </div>
        </div>
        <div class="container">
          <div id="client_slider" class="owl-carousel">
            <div class="card_box">
              <h2 class="text-start sub-heading mb-20">Brisk Mind has been one of our Assessment Partners for the Last 6 Years now. They provide their insights and expertise to us for doing Assessments on a PAN India level </h2>
              <h3 class="text-end">Apparel Made Ups &</br>
                Home Furnishing Sector Skill Council</h3>
            </div>
            <div class="card_box">
              <h2 class="text-start sub-heading mb-20">Brisk Mind has been one of our Assessment Partners for the Last 6 Years now. They provide their insights and expertise to us for doing Assessments on a PAN India level </h2>
              <h3 class="text-end">Apparel Made Ups &</br>
                Home Furnishing Sector Skill Council</h3>
            </div>
            <div class="card_box">
              <h2 class="text-start sub-heading mb-20">Brisk Mind has been one of our Assessment Partners for the Last 6 Years now. They provide their insights and expertise to us for doing Assessments on a PAN India level </h2>
              <h3 class="text-end">Apparel Made Ups &</br>
                Home Furnishing Sector Skill Council</h3>
            </div>
          </div>
        </div>
      </section>
      <?php include 'common/client-form.php';?>
    </main>
    <?php include 'common/footer.php';?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="<?php echo BASE_PATH; ?>assets/js/owl.carousel.min.js" type="text/javascript"></script>
    <script>
        $('#client_slider').owlCarousel({
          margin: 10,
          autoHeight: true,
          nav: false,
          navigation: true,
          loop: true,
          autoplay: true,
          slideBy: 1,
          dotsEach: true,
          dots: true,
          //   autoWidth:true,
          responsive: {
            360: {
              items: 1,
            },
            600: {
              items: 1,
            },
            1120: {
              items: 1,
            },
            1480: {
              items: 1,
            },
            1850: {
              items: 1,
            }
          }
        });
    </script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
      AOS.init();
    </script>
    <script src="<?php echo BASE_PATH; ?>assets/js/main.js"></script>
  </body>
</html>
