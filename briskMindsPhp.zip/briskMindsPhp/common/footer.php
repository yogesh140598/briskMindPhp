<footer class="">
      <div class="container">
        <div class="row d-flex">
          <div class="col-md-3 mb-20">
            <div class="footer_logo">
              <a href="#">
                  <img src="<?php echo BASE_PATH; ?>assets/images/brisk_logo.png" alt="">
              </a>
            </div>
            <div class="para">Brisk Mind Pvt. Ltd. has been founded by alumni of IIM, IIT and NRI’s with rich experience in the field of education, assessment as well as technology. </div>
          </div>
          <div class="col-md-3 mb-20">
            <h3 class="footer-heading">
              Newsletter
            </h3>
            <p class="para">Stay updated with our latest trends.</p>
            <div class="submit_arrow">
              <form action="<?php echo BASE_PATH; ?>newsletter-mail.php" method="post">
                <input type="text" name="email" aria-label="Enter Email Address" place-holder="Enter Email Address">
                <button type="submit" name="submit"><img src="<?php echo BASE_PATH; ?>assets/images/submit-arrow.png" alt=""></button>
              </form>
            </div>
            <ul class="social_icon">
              <li><img src="<?php echo BASE_PATH; ?>assets/images/Facebook_social.png" width="20" height="auto" alt=""></li>
              <li><img src="<?php echo BASE_PATH; ?>assets/images/whatsapp_social.png" width="20" height="auto" alt=""></li>
              <li><img src="<?php echo BASE_PATH; ?>assets/images/twitter_social.png" width="20" height="auto" alt=""></li>
              <li><img src="<?php echo BASE_PATH; ?>assets/images/insta_social.png" width="20" height="auto" alt=""></li>
            </ul>
          </div>
          <div class="col-md-3 mb-20">
            <h3 class="footer-heading">Quick Links</h3>
            <p ><a class="para" href="#">Candidate</a></p>
              <p ><a class="para" href="#">Employer</a></p>
              <p ><a class="para" href="#">Psychometric Tests</a></p>
              <p ><a class="para" href="#">Programming Tests</a></p>
              <p ><a class="para" href="#">Aptitude Tests</a></p>
              <p ><a class="para" href="#">Vocational Skills Assessment</a></p>
          </div>
          <div class="col-md-3 mb-20">
            <h3 class="footer-heading">Contact Us</h3>
            <!-- <li><a href="mailto:operations@briskmind.in">operations@briskmind.in</a></li>
                <li><span>+91 9899991388</span></li> -->
            <p class="para">Phone: +91 9899991388</p>
            <p><a class="para" href="mailto:operations@briskmind.in">Email: operations@briskmind.in</a></p>
            <p class="para">Address: 
              Plot No. 17 & 18, Anand Industrial Estate, Mohan Nagar, Ghaziabad, Uttar Pradesh 201007</p>
          </div>
          <div class="col-md-12">
            <p class="copyright">Copyright © 2022 All rights reserved | www.briskmind.com</p>
          </div>
        </div>
      </div>
    </footer>