<section class="section form_bg">
      <div class="container ">
        <div class="row d-flex justify-content-center">
          <div class="form_box col-md-10">
            <h2 class="sub-heading text-center mb-50">Trusted by More Than 600 Clients Worldwide</h2>
            
            <form action="<?php echo BASE_PATH; ?>mail.php" method="post">
              <div class="row d-flex justify-content-around">
                <div class="col-md-4">
                  <div class="row d-flex flex-column px-4">
                    <h3>Want Solution For</h3>
                    <div class="form-check">
                      <input class="form-check-input" type="radio" name="radio" value="organization" checked>Organization
                    </div>
                    <div class="form-check mb-70 m-mb-2">
                      <input class="form-check-input" type="radio" name="radio" value="Myself">Myself
                      <a class="sub-heading" href="mailto:operations@briskmind.in">operations@briskmind.in</a>
                    </div>
                    <div class="form_card mx-auto">
                      <div class="form_logo">
                        <img src="<?php echo BASE_PATH; ?>assets/images/form_logo.png" width="87" height="auto" alt="">
                      </div>
                      <p class="para">+91 9899991388</p>
                    </div>
                  </div>
                </div>
                <div class="col-md-7">
                  <div class="row">
                      <div class="col-md-6 px-3">
                        <label for="name" class="form-label">Name</label>
                        <input required type="text" name="name" class="form-control" placeholder="Name" aria-label="Name">
                      </div>
                      <div class="col-md-6 px-3">
                        <label for="mobile" class="form-label">Mobile</label>
                        <input required type="text" name="mobile" class="form-control" placeholder="Mobile" aria-label="Mobile" min="10" max="10">
                      </div>
                      <div class="col-md-6 px-3">
                        <label for="email" class="form-label">Official Email</label>
                        <input required type="email" name="email" class="form-control" placeholder="Official Email" aria-label="Official Email">
                      </div>
                      <div class="col-md-6 px-3">
                        <label for="company" class="form-label">Company</label>
                        <input required type="text" name="company" class="form-control" placeholder="Company" aria-label="Company">
                      </div>
                      <div class="col-md-12">
                        <label for="comments" class="form-label">Comments</label>
                        <textarea class="form-control" name="message" id="comments" min="10" max="1500" placeholder="Comments" rows="3"></textarea>
                      </div>
                      <div>
                        <button type="submit" name="submit" class="btn-custom">Submit</button>
                      </div>
                    </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>