<?php
// define('BASE_PATH', 'http://localhost/briskMindsPhp/');
// define('BASE_PATH', 'http://localhost:81/briskMindsPhp/');
define('BASE_PATH', 'http://briskmind.in/'); //live site
//  $url_path = "http://localhost:81/briskMindsPhp/";
// define("BASE_PATH",$url_path);

?>