<?php
define('BASE_PATH', 'http://localhost/briskMindsPhp/');

// define('BASE_PATH', 'http://localhost:81/briskMindsPhp/');
// define('BASE_PATH', 'http://localhost/briskMindsPhp/');

//  $url_path = "http://localhost:81/briskMindsPhp/";
// define("BASE_PATH",$url_path);

?>