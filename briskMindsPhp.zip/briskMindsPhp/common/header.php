
<header class="header">
      <div class="top_nav w-100">
        <div class="container">
          <div class="row d-flex align-items-center">
            <div class="col-md-12 justify-content-end">
              <ul class="right_menu">
                <li><a href="mailto:operations@briskmind.in">operations@briskmind.in</a></li>
                <li><span>+91 9899991388</span></li>
                <li class="icons"><a href="#"><img src="<?php echo BASE_PATH; ?>assets/images/whatsapp_icon.png" width="20" height="auto" alt="whatsapp"></a></li>
                <li class="icons"><a href="#"><img src="<?php echo BASE_PATH; ?>assets/images/Pinterest.png" width="20" height="auto" alt="Pinterest"></a></li>
                <li class="icons"><a href="#"><img src="<?php echo BASE_PATH; ?>assets/images/Instagram.png" width="20" height="auto" alt="Instagram"></a></li>
                <li class="icons"><a href="#"><img src="<?php echo BASE_PATH; ?>assets/images/Twitter.png" width="20" height="auto" alt="Twitter"></a></li>
                <li class="icons"><a href="#"><img src="<?php echo BASE_PATH; ?>assets/images/Facebook.png" width="20" height="auto" alt="Facebook"></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div class="header_bottom">
        <div class="container w-100">
          <div class="row d-flex align-items-center">
            <nav class="navbar navbar-expand-lg ">
                <div class="col-md-3">
                  <div class="header_logo">
                    <a class="navbar-brand" href="<?php echo BASE_PATH; ?>"><img src="<?php echo BASE_PATH; ?>assets/images/header_logo.png" height="auto" width="130" alt=""></a>
                  </div>
                </div>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon">
                    <img class="img-fluid" src="<?php echo BASE_PATH; ?>assets/images/menu-icon.svg" alt="">
                  </span>
                </button>
                <div class="collapse navbar-collapse col-md-9 justify-content-end" id="navbarSupportedContent">
                  <ul class="navbar-nav header_menu d-flex align-items-center justify-content-between">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo BASE_PATH; ?>">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo BASE_PATH; ?>about">About us</a>
                    </li>
                    <li class="nav-item dropdown has-megamenu">
                      <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Services</a>
                      <div class="dropdown-menu megamenu" role="menu">
                        <div class="row">
                          <ul class="d-flex justify-content-between navbar-nav p-5">
                            <li class="nav-item">
                              <a class="nav-link" href="<?php echo BASE_PATH; ?>service/talent-assessment"><span><img src="<?php echo BASE_PATH; ?>assets/images/assessment-logo.svg" alt=""></span>Talent Assessment</a>
                              <div class="nav-link-content">
                                <p class="para">Skill Assessment</p>
                                <p class="para">Corporate Assessment</p>
                                <p class="para">Government Exams</p>
                                <p class="para">School Exams</p>
                                <p class="para">Coaching Institutions</p>
                                <p class="para">College Exams</p>
                              </div>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" href="<?php echo BASE_PATH; ?>service/talent-acquisition"><span><img src="<?php echo BASE_PATH; ?>assets/images/acquisition-logo.svg" alt=""></span>Talent Acquisition </a>
                              <div class="nav-link-content">
                                <p class="para">Bulk Hiring</p>
                                <p class="para">Management Hiring</p>
                                <p class="para">Payroll Management</p>
                                <p class="para">Compliance Management</p>
                              </div>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" href="<?php echo BASE_PATH; ?>service/talent-development"><span><img src="<?php echo BASE_PATH; ?>assets/images/development-logo.svg" alt=""></span>Talent Development</a>
                              <div class="nav-link-content">
                                <p class="para">Leadership Development</p>
                                <p class="para">Sales & Services</p>
                                <p class="para">Team Building & Outbound</p>
                                <p class="para">Comunication development Training</p>
                                <p class="para">Personal Effectiveness Training</p>
                              </div>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" href="<?php echo BASE_PATH; ?>service/background-verification"><span><img src="<?php echo BASE_PATH; ?>assets/images/verification-logo.svg" alt=""></span>Background Verification</a>
                              <div class="nav-link-content">
                                <p class="para">Employement Verification</p>
                                <p class="para">Address Verification</p>
                                <p class="para">Police Verification</p>
                                <p class="para">Reference Check</p>
                              </div>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" href="<?php echo BASE_PATH; ?>service/consulting"><span><img src="<?php echo BASE_PATH; ?>assets/images/consulting-logo.svg" alt=""></span>Consulting</a>
                              <div class="nav-link-content">
                                <p class="para">Government Sector</p>
                                <p class="para">Private Sector</p>
                                <p class="para">MSME Schemes</p>
                              </div>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo BASE_PATH; ?>career">Career</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo BASE_PATH; ?>contact">Contact us</a>
                    </li>
                    <li>
                      <button class="btn-custom text-light"> Join Now</button>
                    </li>
                  </ul>
                </div>
            </nav>
          </div>
        </div>
      </div>
    </header>
    <div class="header_gap"></div>