<?php include 'common/config.php';?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <link rel="stylesheet" type="text/css" href="<?php echo BASE_PATH; ?>assets/css/owl.carousel.min.css" />
    <?php include 'common/library.php';?>
    <title>Background Verification</title>
  </head>
  <body class="background-verification">
    <?php include 'common/header.php';?>
    <main class="background_vector">
      <section class="banner_inside">
          <div class="container h-100">
            <div class="row d-flex m-flex-column align-items-center h-100">
              <div class="col-md-6">
                <figure class="m-show hide">
                  <img class="img-fluid" src="<?php echo BASE_PATH; ?>assets/images/talent_industry.webp" width="520" height="auto" alt="Global Leader">
                </figure>
                <h2 class="heading">Briskmind:</h2>
                <h2 class="heading mb-5">Advantages of Industry specific verification approach</h2>
                <p class="para mb-3">Cutting-edge authentication products and alternate data analysis for your business. Building trust through data.</p>
                <div class="yellow-line mb-5"></div>
                <button class="btn-custom">Get Started</button>
              </div>
              <div class="col-md-6">
                <figure class="d-flex justify-content-end ">
                    <img class="m-hide show img-fluid" src="<?php echo BASE_PATH; ?>assets/images/talent_industry.webp" width="600" height="auto" alt="Global Leader">
                </figure>
              </div>
            </div>
          </div>
        </section>
      <section class="section">
          <div class="container">
              <div class="row">
                  <div class="col-md-10 text-center mx-auto">
                      <h2 class="heading">Industry specific tailored Products</h2>
                      <p class="para mb-50">Our verification technology is for everyone. We help onboard employees of telecom, IT, manufacturing, healthcare, banking, consulting and retail industries as well as the on-demand economy – that requires blue-collared employees to be verified and onboarded at speed and scale.</p>
                  </div>
                  <div class="col-md-3 skill-box" data-aos="flip-left"  data-aos-duration="1000">
                      <div>
                          <img src="<?php echo BASE_PATH; ?>assets/images/embrace-remote.webp" alt="">
                      </div>
                      <div class="skill-box-content">
                          <h3 class="sub-heading">Embrace remote, contactless and real-time identity verification</h3>
                      </div>
                  </div>
                  <div class="col-md-3 skill-box" data-aos="flip-right"  data-aos-duration="1000">
                      <div>
                          <img src="<?php echo BASE_PATH; ?>assets/images/reduce-operational.webp" alt="">
                      </div>
                      <div class="skill-box-content">
                          <h3 class="sub-heading">Reduce operational costs by up to 70% and onboarding time by 90%</h3>
                      </div>
                  </div>
                  <div class="col-md-3 skill-box" data-aos="flip-left"  data-aos-duration="1000">
                      <div>
                          <img src="<?php echo BASE_PATH; ?>assets/images/catch-identify.webp" alt="">
                      </div>
                      <div class="skill-box-content">
                          <h3 class="sub-heading">Catch identity-thefts and frauds with solid background checks</h3>
                      </div>
                  </div>
                  <div class="col-md-3 skill-box" data-aos="flip-right"  data-aos-duration="1000">
                      <div>
                          <img src="<?php echo BASE_PATH; ?>assets/images/actionable-business.webp" alt="">
                      </div>
                      <div class="skill-box-content">
                          <h3 class="sub-heading">Get actionable business insights to invest safely in the new economy</h3>
                      </div>
                  </div>
              </div>
          </div>
      </section>
      <section class="section">
          <div class="container">
            <div class="text-center mx-auto mb-50">
              <h2 class="heading">Key Checks for Employee Background Verification</h2>
              <p class="para">Whatever the Development program you are looking for, Briskmind has the right solution to help you make wise Talent Development decisions </p>
            </div>
            <ul class="d-flex justify-content-between background_card_list">
              <li class="background_card" data-aos="flip-right"  data-aos-duration="1000">
                  <div class="mb-5">
                    <img src="<?php echo BASE_PATH; ?>assets/images/identity-check.svg" alt="">
                  </div>
                <h3 class="sub-heading">Identity Check</h3>
              </li>
              <li class="background_card" data-aos="flip-left"  data-aos-duration="1000">
                  <div class="mb-5">
                      <img src="<?php echo BASE_PATH; ?>assets/images/address-verify.svg" alt="">
                  </div>
                  <h3 class="sub-heading">Address Verification</h3>
              </li>
              <li class="background_card" data-aos="flip-right"  data-aos-duration="1000">
                <div class="mb-5">
                  <img src="<?php echo BASE_PATH; ?>assets/images/education-check.svg" alt="">
                </div>
                <h3 class="sub-heading">Education Check</h3>
              </li>
              <li class="background_card" data-aos="flip-left"  data-aos-duration="1000">
                <div class="mb-5">
                  <img src="<?php echo BASE_PATH; ?>assets/images/reference-check.svg" alt="">
                </div>
                <h3 class="sub-heading">Reference Check</h3>
              </li>
              <li class="background_card" data-aos="flip-right"  data-aos-duration="1000">
                <div class="mb-5">
                  <img src="<?php echo BASE_PATH; ?>assets/images/criminal-record.svg" alt="">
                </div>
                <h3 class="sub-heading">Criminal Record Check</h3>
              </li>
              <li class="background_card" data-aos="flip-left"  data-aos-duration="1000">
                <div class="mb-5">
                  <img src="<?php echo BASE_PATH; ?>assets/images/employee-verify.svg" alt="">
                </div>
                <h3 class="sub-heading">Employment Verification</h3>
              </li>
              <li class="background_card" data-aos="flip-right"  data-aos-duration="1000">
                <div class="mb-5">
                  <img src="<?php echo BASE_PATH; ?>assets/images/drug-test.svg" alt="">
                </div>
                <h3 class="sub-heading">Drug Abuse Test</h3>
              </li>
              <li class="background_card" data-aos="flip-left"  data-aos-duration="1000">
                <div class="mb-5">
                  <img src="<?php echo BASE_PATH; ?>assets/images/international-background-check.svg" alt="">
                </div>
                <h3 class="sub-heading">International Background Checks</h3>
              </li>
            </ul>
            <div class="row d-flex justify-content-between mb-5 d-none">
              <div class="col col-sm-6 col-md-3">
                <div class="background_card">
                    <div class="mb-5">
                        <img src="<?php echo BASE_PATH; ?>assets/images/identity-check.svg" alt="">
                    </div>
                    <h3 class="sub-heading">Identity Check</h3>
                </div>
              </div>
              <div class="col col-sm-6 col-md-3">
                  <div class="background_card">
                      <div class="mb-5">
                          <img src="<?php echo BASE_PATH; ?>assets/images/address-verify.svg" alt="">
                      </div>
                      <h3 class="sub-heading">Address Verification</h3>
                  </div>
              </div>
              <div class="col col-sm-6 col-md-3">
                  <div class="background_card">
                      <div class="mb-5">
                          <img src="<?php echo BASE_PATH; ?>assets/images/education-check.svg" alt="">
                      </div>
                      <h3 class="sub-heading">Education Check</h3>
                  </div>
              </div>
              <div class="col col-sm-6 col-md-3">
                  <div class="background_card">
                      <div class="mb-5">
                          <img src="<?php echo BASE_PATH; ?>assets/images/reference-check.svg" alt="">
                      </div>
                      <h3 class="sub-heading">Reference Check</h3>
                  </div>
              </div>
            </div>
            <div class="row d-flex justify-content-between d-none"> 
                <div class="col col-sm-6 col-md-3">
                    <div class="background_card">
                        <div class="mb-5">
                            <img src="<?php echo BASE_PATH; ?>assets/images/criminal-record.svg" alt="">
                        </div>
                        <h3 class="sub-heading">Criminal Record Check</h3>
                    </div>
                </div>
                <div class="col col-sm-6 col-md-3">
                    <div class="background_card">
                        <div class="mb-5">
                            <img src="<?php echo BASE_PATH; ?>assets/images/employee-verify.svg" alt="">
                        </div>
                        <h3 class="sub-heading">Employment Verification</h3>
                    </div>
                </div>
                <div class="col col-sm-6 col-md-3">
                    <div class="background_card">
                        <div class="mb-5">
                            <img src="<?php echo BASE_PATH; ?>assets/images/drug-test.svg" alt="">
                        </div>
                        <h3 class="sub-heading">Drug Abuse Test</h3>
                    </div>
                </div>
                <div class="col col-sm-6 col-md-3">
                    <div class="background_card">
                        <div class="mb-5">
                            <img src="<?php echo BASE_PATH; ?>assets/images/international-background-check.svg" alt="">
                        </div>
                        <h3 class="sub-heading">International Background Checks</h3>
                    </div>
                </div>
            </div>
          </div>
      </section>
      <section class="section">
        <div class="container">
          <div class="row">
            <h2 class="heading text-center">Our work speaks volumes but it’s better to hear</br> it from clients</h2>
            <p class="para text-center mb-50">Over the last 15 years, we have been the pioneers and thought leaders in background checks space. Our technology-driven products have helped small, medium and large organisations in India and abroad. With over 1500+ clients, we have established a portfolio comprising some of the biggest technology, insurance, on-demand, manufacturing and banking organisations.</p>
          </div>
        </div>
        <div class="container">
          <div id="client_slider" class="owl-carousel">
            <div class="card_box">
              <h2 class="text-start sub-heading mb-20">Brisk Mind has been one of our Assessment Partners for the Last 6 Years now. They provide their insights and expertise to us for doing Assessments on a PAN India level </h2>
              <h3 class="text-end">Apparel Made Ups &</br>
                Home Furnishing Sector Skill Council</h3>
            </div>
            <div class="card_box">
              <h2 class="text-start sub-heading mb-20">Brisk Mind has been one of our Assessment Partners for the Last 6 Years now. They provide their insights and expertise to us for doing Assessments on a PAN India level </h2>
              <h3 class="text-end">Apparel Made Ups &</br>
                Home Furnishing Sector Skill Council</h3>
            </div>
            <div class="card_box">
              <h2 class="text-start sub-heading mb-20">Brisk Mind has been one of our Assessment Partners for the Last 6 Years now. They provide their insights and expertise to us for doing Assessments on a PAN India level </h2>
              <h3 class="text-end">Apparel Made Ups &</br>
                Home Furnishing Sector Skill Council</h3>
            </div>
          </div>
        </div>
      </section>
      <?php include 'common/client-form.php';?>
    </main>
    <?php include 'common/footer.php';?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="<?php echo BASE_PATH; ?>assets/js/owl.carousel.min.js" type="text/javascript"></script>
    <script>
        $('#client_slider').owlCarousel({
          margin: 10,
          autoHeight: true,
          nav: true,
          navigation: true,
          loop: true,
          autoplay: true,
          slideBy: 1,
          dotsEach: true,
          dots: true,
          //   autoWidth:true,
          responsive: {
            360: {
              items: 1,
            },
            600: {
              items: 1,
            },
            1120: {
              items: 1,
            },
            1480: {
              items: 1,
            },
            1850: {
              items: 1,
            }
          }
        });
    </script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
      AOS.init();
    </script>
    <script src="<?php echo BASE_PATH; ?>assets/js/main.js"></script>
  </body>
</html>
